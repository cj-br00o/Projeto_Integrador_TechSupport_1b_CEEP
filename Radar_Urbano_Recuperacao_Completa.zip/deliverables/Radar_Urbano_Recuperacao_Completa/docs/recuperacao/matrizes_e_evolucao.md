# Matrizes e Registro de Evolução

## Convergência DS + IA

DS registra usuários, ocorrências, categorias, localização, status, equipes e histórico. A IA utiliza descrição, imagem, coordenadas e histórico para validar o relato, resumir, sugerir categoria e prioridade e indicar possíveis duplicidades. Os resultados relevantes retornam ao banco para auditoria, filtros e indicadores, preservando a validação humana da prefeitura.

## Padronização Banco × CSV

- Nomes adotados em `snake_case`.
- Chaves permanecem inteiras no banco; o CSV apresenta categorias e status por nomes legíveis.
- Latitude e longitude são separadas e validadas.
- Prioridade usa o domínio: baixa, média, alta e crítica.
- A massa contém somente dados fictícios.

## Evolução

1. Nomes divergentes foram padronizados entre banco e CSV.
2. Categoria e status tornaram-se domínios controlados com chaves estrangeiras.
3. As saídas relevantes da IA ganharam destino persistente e auditável.
4. A localização foi separada em latitude e longitude.
5. O teste passou a exigir contagem e identificação verificáveis.
6. A decisão administrativa permaneceu humana; a IA atua como apoio.
