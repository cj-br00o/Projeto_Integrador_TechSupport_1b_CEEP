# DER — Radar Urbano

```mermaid
erDiagram
    USUARIO ||--o{ OCORRENCIA : registra
    USUARIO ||--o{ HISTORICO_STATUS : altera
    CATEGORIA ||--o{ OCORRENCIA : classifica
    STATUS_OCORRENCIA ||--o{ OCORRENCIA : define
    STATUS_OCORRENCIA ||--o{ HISTORICO_STATUS : registra
    OCORRENCIA ||--o{ ATENDIMENTO : recebe
    OCORRENCIA o|--o{ OCORRENCIA : duplica
    OCORRENCIA ||--o{ HISTORICO_STATUS : possui
    EQUIPE ||--o{ ATENDIMENTO : executa
```

## Cardinalidades principais

- Um usuário pode registrar várias ocorrências; cada ocorrência possui um autor.
- Uma categoria e um status podem estar associados a várias ocorrências.
- Uma ocorrência pode receber vários atendimentos e eventos de histórico.
- Uma equipe pode executar vários atendimentos.
- Uma ocorrência pode apontar para outra como possível duplicata.
