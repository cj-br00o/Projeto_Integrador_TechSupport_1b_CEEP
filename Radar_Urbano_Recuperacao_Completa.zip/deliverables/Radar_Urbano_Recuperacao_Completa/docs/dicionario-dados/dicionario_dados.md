# Dicionário de Dados — Radar Urbano

## usuario

| Campo | Tipo | Regra | Finalidade |
|---|---|---|---|
| id_usuario | BIGSERIAL | PK | Identificador interno |
| nome | VARCHAR(120) | NOT NULL | Identificação do usuário |
| email | VARCHAR(160) | NOT NULL, UNIQUE | Acesso e contato |
| perfil | VARCHAR(20) | cidadão, prefeitura, equipe ou administrador | Controle de acesso |
| criado_em | TIMESTAMPTZ | padrão: data atual | Auditoria |

## categoria

| Campo | Tipo | Regra | Finalidade |
|---|---|---|---|
| id_categoria | SMALLSERIAL | PK | Identificador da categoria |
| nome | VARCHAR(80) | NOT NULL, UNIQUE | Domínio controlado |
| descricao | VARCHAR(255) | opcional | Explicação da categoria |

## status_ocorrencia

| Campo | Tipo | Regra | Finalidade |
|---|---|---|---|
| id_status | SMALLSERIAL | PK | Identificador do status |
| nome | VARCHAR(30) | NOT NULL, UNIQUE | Etapa do atendimento |

## ocorrencia

| Campo | Tipo | Regra | Finalidade |
|---|---|---|---|
| id_ocorrencia | BIGSERIAL | PK | Protocolo da ocorrência |
| id_usuario | BIGINT | FK, NOT NULL | Autor do relato |
| id_categoria | SMALLINT | FK, opcional até validação | Categoria validada |
| id_status | SMALLINT | FK, NOT NULL | Estado atual |
| descricao | TEXT | NOT NULL, 10 a 2000 caracteres | Relato do problema |
| latitude | NUMERIC(9,6) | -90 a 90 | Localização |
| longitude | NUMERIC(9,6) | -180 a 180 | Localização |
| foto_url | TEXT | opcional | Evidência visual |
| prioridade | VARCHAR(10) | baixa, média, alta ou crítica | Priorização |
| resumo_ia | TEXT | opcional | Síntese produzida pela IA |
| valido_ia | BOOLEAN | opcional | Indicação de validade |
| id_duplicada_de | BIGINT | FK autorreferente, opcional | Ocorrência semelhante |
| criado_em | TIMESTAMPTZ | padrão: data atual | Auditoria |
| atualizado_em | TIMESTAMPTZ | padrão: data atual | Auditoria |

## equipe

| Campo | Tipo | Regra | Finalidade |
|---|---|---|---|
| id_equipe | BIGSERIAL | PK | Identificador da equipe |
| nome | VARCHAR(100) | NOT NULL, UNIQUE | Equipe responsável |
| especialidade | VARCHAR(100) | NOT NULL | Tipo de atendimento |

## atendimento

| Campo | Tipo | Regra | Finalidade |
|---|---|---|---|
| id_atendimento | BIGSERIAL | PK | Identificador do atendimento |
| id_ocorrencia | BIGINT | FK, NOT NULL | Ocorrência atendida |
| id_equipe | BIGINT | FK, NOT NULL | Equipe designada |
| inicio_em | TIMESTAMPTZ | opcional | Início do serviço |
| fim_em | TIMESTAMPTZ | opcional e posterior ao início | Encerramento |
| observacao | TEXT | opcional | Registro operacional |

## historico_status

| Campo | Tipo | Regra | Finalidade |
|---|---|---|---|
| id_historico | BIGSERIAL | PK | Identificador do evento |
| id_ocorrencia | BIGINT | FK, NOT NULL | Ocorrência alterada |
| id_status | SMALLINT | FK, NOT NULL | Novo status |
| alterado_por | BIGINT | FK, NOT NULL | Responsável pela alteração |
| observacao | TEXT | opcional | Justificativa |
| alterado_em | TIMESTAMPTZ | padrão: data atual | Auditoria |
