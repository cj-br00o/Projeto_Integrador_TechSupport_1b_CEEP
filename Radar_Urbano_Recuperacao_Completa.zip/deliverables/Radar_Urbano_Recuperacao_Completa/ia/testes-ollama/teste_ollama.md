# Teste Verificável no Ollama

## Arquivo

`data/csv/radar_urbano_ocorrencias_teste.csv`

## Prompt

> Analise somente os dados do CSV fornecido. Conte as ocorrências cuja prioridade seja alta ou crítica. Informe o total e, para cada ocorrência encontrada, apresente ID, categoria, prioridade e status. Não invente informações e não considere qualquer fonte externa.

## Resultado calculado diretamente no CSV

Total: **5 ocorrências**.

| ID | Categoria | Prioridade | Status |
|---:|---|---|---|
| 3 | Trânsito | crítica | Em atendimento |
| 7 | Arborização | alta | Encaminhada |
| 11 | Drenagem | crítica | Em atendimento |
| 14 | Infraestrutura | alta | Em análise |
| 18 | Infraestrutura | crítica | Encaminhada |

## Registro da execução real

- Modelo do Ollama: **[preencher após executar]**
- Data e hora: **[preencher após executar]**
- Resposta obtida: **[colar a resposta]**
- Conferência: ☐ correta ☐ parcialmente correta ☐ incorreta
- Evidência: **[inserir captura ou arquivo de saída]**

A execução deve ser feita no computador da equipe, pois este pacote não possui acesso à instalação local do Ollama.
