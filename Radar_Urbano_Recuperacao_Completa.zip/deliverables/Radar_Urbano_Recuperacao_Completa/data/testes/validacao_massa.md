# Validação da Massa de Testes

- Total de registros: **20**.
- IDs únicos: **20**, sem duplicação.
- Prioridades aceitas: baixa, média, alta e crítica.
- Coordenadas dentro das faixas válidas.
- Ocorrências de prioridade alta ou crítica: **5**.

| ID | Categoria | Prioridade | Status |
|---:|---|---|---|
| 3 | Trânsito | critica | Em atendimento |
| 7 | Arborização | alta | Encaminhada |
| 11 | Drenagem | critica | Em atendimento |
| 14 | Infraestrutura | alta | Em análise |
| 18 | Infraestrutura | critica | Encaminhada |

Resultado verificável esperado: IDs **3, 7, 11, 14 e 18**.
