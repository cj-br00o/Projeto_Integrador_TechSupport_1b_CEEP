# Radar Urbano — Recuperação DS + IA

Pacote acadêmico de validação e convergência dos dados do projeto Radar Urbano.

## Conteúdo

- `docs/dicionario-dados/dicionario_dados.md`: entidades, atributos, regras e finalidade.
- `docs/der/der_radar_urbano.md`: DER em Mermaid, editável no GitHub.
- `database/ddl/schema.sql`: estrutura PostgreSQL com PK, FK, restrições e índices.
- `data/csv/radar_urbano_ocorrencias_teste.csv`: 20 ocorrências fictícias e verificáveis.
- `data/testes/validacao_massa.md`: conferência da massa de testes.
- `ia/testes-ollama/teste_ollama.md`: prompt, procedimento e campos para registrar a execução.
- `docs/recuperacao/matrizes_e_evolucao.md`: síntese da convergência e das decisões.
- `Caderno_Recuperacao_Radar_Urbano_REVISADO.docx`: caderno revisado.

## Observação de ética e privacidade

Todos os dados da massa de teste são fictícios. O repositório não deve conter senhas, tokens, chaves de API ou dados pessoais reais.
