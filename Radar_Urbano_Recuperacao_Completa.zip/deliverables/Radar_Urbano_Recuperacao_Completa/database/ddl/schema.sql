BEGIN;

CREATE TABLE usuario (
  id_usuario BIGSERIAL PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  perfil VARCHAR(20) NOT NULL CHECK (perfil IN ('cidadao','prefeitura','equipe','administrador')),
  criado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categoria (
  id_categoria SMALLSERIAL PRIMARY KEY,
  nome VARCHAR(80) NOT NULL UNIQUE,
  descricao VARCHAR(255)
);

CREATE TABLE status_ocorrencia (
  id_status SMALLSERIAL PRIMARY KEY,
  nome VARCHAR(30) NOT NULL UNIQUE CHECK (nome IN ('Recebida','Em análise','Encaminhada','Em atendimento','Resolvida'))
);

CREATE TABLE equipe (
  id_equipe BIGSERIAL PRIMARY KEY,
  nome VARCHAR(100) NOT NULL UNIQUE,
  especialidade VARCHAR(100) NOT NULL
);

CREATE TABLE ocorrencia (
  id_ocorrencia BIGSERIAL PRIMARY KEY,
  id_usuario BIGINT NOT NULL REFERENCES usuario(id_usuario),
  id_categoria SMALLINT REFERENCES categoria(id_categoria),
  id_status SMALLINT NOT NULL REFERENCES status_ocorrencia(id_status),
  descricao TEXT NOT NULL CHECK (char_length(descricao) BETWEEN 10 AND 2000),
  latitude NUMERIC(9,6) NOT NULL CHECK (latitude BETWEEN -90 AND 90),
  longitude NUMERIC(9,6) NOT NULL CHECK (longitude BETWEEN -180 AND 180),
  foto_url TEXT,
  prioridade VARCHAR(10) NOT NULL CHECK (prioridade IN ('baixa','media','alta','critica')),
  resumo_ia TEXT,
  valido_ia BOOLEAN,
  id_duplicada_de BIGINT REFERENCES ocorrencia(id_ocorrencia),
  criado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK (id_duplicada_de IS NULL OR id_duplicada_de <> id_ocorrencia)
);

CREATE TABLE atendimento (
  id_atendimento BIGSERIAL PRIMARY KEY,
  id_ocorrencia BIGINT NOT NULL REFERENCES ocorrencia(id_ocorrencia) ON DELETE CASCADE,
  id_equipe BIGINT NOT NULL REFERENCES equipe(id_equipe),
  inicio_em TIMESTAMPTZ,
  fim_em TIMESTAMPTZ,
  observacao TEXT,
  CHECK (fim_em IS NULL OR inicio_em IS NULL OR fim_em >= inicio_em)
);

CREATE TABLE historico_status (
  id_historico BIGSERIAL PRIMARY KEY,
  id_ocorrencia BIGINT NOT NULL REFERENCES ocorrencia(id_ocorrencia) ON DELETE CASCADE,
  id_status SMALLINT NOT NULL REFERENCES status_ocorrencia(id_status),
  alterado_por BIGINT NOT NULL REFERENCES usuario(id_usuario),
  observacao TEXT,
  alterado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_ocorrencia_status ON ocorrencia(id_status);
CREATE INDEX idx_ocorrencia_categoria ON ocorrencia(id_categoria);
CREATE INDEX idx_ocorrencia_prioridade ON ocorrencia(prioridade);
CREATE INDEX idx_ocorrencia_localizacao ON ocorrencia(latitude, longitude);
CREATE INDEX idx_historico_ocorrencia ON historico_status(id_ocorrencia, alterado_em);

COMMIT;
