# Abrir o Radar Urbano local

Na pasta atual, execute:

```bash
bash iniciar_radar.sh
```

Abra **http://127.0.0.1:8000/**.
O comando inicia o PostgreSQL privado e o sistema completo (frontend + API).

Crie uma conta na tela de entrada e faça login para registrar e acompanhar solicitações.
Para gestão, crie um administrador local com `radar_urbano_backend_ds_ia/.venv/bin/python radar_urbano_backend_ds_ia/gerenciar.py criar-gestor` e entre com essa conta.

Documentação de uso e testes: [README do sistema](radar_urbano_backend_ds_ia/README.md).
As versões anteriores foram preservadas. GitHub, Classroom e Supabase não foram alterados.
