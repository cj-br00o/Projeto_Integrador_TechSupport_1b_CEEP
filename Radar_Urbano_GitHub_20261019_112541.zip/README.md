# Radar Urbano

Sistema acadêmico local para registro e acompanhamento de problemas urbanos, com frontend do cidadão, central de gestão e backend FastAPI.

## Versão atual

O sistema funcional está em **radar_urbano_backend_ds_ia/**. Consulte seu README para configuração, uso e testes.

No notebook já preparado, execute na raiz:

```bash
bash iniciar_radar.sh
```

Abra http://127.0.0.1:8000/ . A documentação da API está em http://127.0.0.1:8000/docs.

Em outra máquina, siga o preparo descrito em radar_urbano_backend_ds_ia/README.md. O banco e o .env do notebook não estão neste pacote; configure um ambiente local novo.

## Conteúdo preservado

- radar_urbano_backend_ds_ia/: sistema atual, testes, contratos, coleção Postman e evidências reais.
- Radar_Urbano_Modulo_7/ e Radar_Urbano_Pacote_Definitivo/: versões anteriores e materiais do projeto.
- backend/, database/ e documentacao/: código, CSVs e análises anteriores.
- README_ORIGINAL_RAIZ.md: README anterior da raiz, preservado sem alterações.

As massas CSV acadêmicas/sintéticas não representam ocorrências reais da prefeitura. O sistema não se conecta ao Supabase e não executa Ollama.

O pacote não contém .env, senhas locais, bancos, .venv, node_modules ou histórico .git. Há .env.example e dependências fixadas para reprodução.

Extraia este ZIP e envie seu conteúdo ao repositório. O ZIP foi preparado localmente; nada foi enviado automaticamente ao GitHub, Classroom ou Supabase.
