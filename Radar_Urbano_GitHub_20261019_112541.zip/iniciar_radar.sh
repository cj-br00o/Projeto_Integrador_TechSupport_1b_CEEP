#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/radar_urbano_backend_ds_ia"
bash postgres.sh iniciar
.venv/bin/python gerenciar.py conferir-banco
.venv/bin/python scripts/api_local.py reiniciar
echo 'Radar Urbano: http://127.0.0.1:8000/'
echo 'Para parar: cd radar_urbano_backend_ds_ia && .venv/bin/python scripts/api_local.py parar'
