#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [ -d instance/pgdata ]; then bash postgres.sh iniciar; fi
.venv/bin/python gerenciar.py conferir-banco
.venv/bin/python scripts/api_local.py reiniciar
echo 'Abra o Radar Urbano: http://127.0.0.1:8000/'
echo 'Para parar: .venv/bin/python scripts/api_local.py parar'
