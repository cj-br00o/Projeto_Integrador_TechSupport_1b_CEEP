"""Comandos locais: init-db, criar-gestor e conferir-banco. Sem serviço remoto."""
import argparse
import getpass
from pathlib import Path
from sqlalchemy import select, inspect, text
from sqlalchemy.engine import make_url
from sqlalchemy.orm import sessionmaker
from config import Settings
from database import Base, criar_engine
from models import Categoria, StatusOcorrencia, Usuario, Credencial, Preferencia
from schemas import Cadastro
from security import password_hash
from pydantic import ValidationError
from sqlalchemy.exc import IntegrityError, OperationalError

CATEGORIAS = [('INFRAESTRUTURA', 'Infraestrutura'), ('ILUMINACAO', 'Iluminação'), ('TRANSITO', 'Trânsito'), ('ARBORIZACAO', 'Arborização'), ('DRENAGEM', 'Drenagem'), ('CONSERVACAO', 'Conservação'), ('LIMPEZA_URBANA', 'Limpeza urbana'), ('SANEAMENTO', 'Saneamento')]
STATUS = [('RECEBIDA', 'Recebida', False), ('EM_ANALISE', 'Em análise', False), ('ENCAMINHADA', 'Encaminhada', False), ('EM_ATENDIMENTO', 'Em atendimento', False), ('RESOLVIDA', 'Resolvida', True)]


def inicializar(engine):
    inspector = inspect(engine)
    existing = set(inspector.get_table_names())
    for name in existing & set(Base.metadata.tables):
        expected = set(Base.metadata.tables[name].columns.keys())
        actual = {c['name'] for c in inspector.get_columns(name)}
        if expected != actual:
            raise RuntimeError(f'Tabela {name} incompatível. Use um banco local novo; não há migração automática.')
    Base.metadata.create_all(engine)
    with sessionmaker(bind=engine)() as db:
        for code, name in CATEGORIAS:
            if not db.scalar(select(Categoria).where(Categoria.codigo == code)):
                db.add(Categoria(codigo=code, nome=name))
        for order, (code, name, final) in enumerate(STATUS, 1):
            if not db.scalar(select(StatusOcorrencia).where(StatusOcorrencia.codigo == code)):
                db.add(StatusOcorrencia(codigo=code, nome=name, ordem=order, status_final=final))
        db.commit()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('comando', choices=['init-db', 'criar-gestor', 'conferir-banco'])
    args = parser.parse_args()
    engine = criar_engine(Settings.from_env().database_url)
    if engine.dialect.name == 'sqlite' and engine.url.database != ':memory:':
        Path(engine.url.database).parent.mkdir(parents=True, exist_ok=True)
    try:
        if args.comando == 'init-db':
            inicializar(engine)
            print('Banco local inicializado. Nenhuma pessoa ou ocorrência de demonstração criada.')
        elif args.comando == 'conferir-banco':
            with engine.connect() as connection:
                connection.execute(text('SELECT 1'))
            print('Conexão local OK. Tabelas:', ', '.join(inspect(engine).get_table_names()))
        else:
            data = Cadastro(nome=input('Nome: '), email=input('E-mail local: '), senha=getpass.getpass('Senha: '))
            if data.senha != getpass.getpass('Confirme a senha: '):
                raise ValueError('Senhas diferentes.')
            with sessionmaker(bind=engine)() as db:
                user = Usuario(nome=data.nome, email=data.email, perfil='ADMINISTRADOR')
                db.add(user)
                db.flush()
                db.add(Credencial(id_usuario=user.id_usuario, senha_hash=password_hash(data.senha)))
                db.add(Preferencia(id_usuario=user.id_usuario))
                db.commit()
            print('Administrador local criado.')
    finally:
        engine.dispose()


if __name__ == '__main__':
    try:
        main()
    except ValidationError as error:
        for item in error.errors():
            print('.'.join(map(str,item['loc'])) + ': ' + item['msg'])
        raise SystemExit(1)
    except IntegrityError:
        print('Registro já existe ou os cadastros de referência conflitam. Confira o banco local.')
        raise SystemExit(1)
    except OperationalError:
        print('Banco local indisponível. Confira a instalação e a configuração.')
        raise SystemExit(1)
    except (ValueError, RuntimeError):
        print('Configuração ou dados inválidos. Use um banco local novo e confira os campos e a confirmação da senha.')
        raise SystemExit(1)
