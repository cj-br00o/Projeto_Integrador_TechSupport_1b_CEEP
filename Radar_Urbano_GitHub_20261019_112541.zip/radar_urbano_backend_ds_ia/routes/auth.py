import secrets
from datetime import timedelta
from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy import select, delete
from sqlalchemy.orm import Session
from database import get_db
from models import Usuario, Credencial, Sessao, Preferencia
from schemas import Cadastro, Login, PerfilUpdate, SenhaUpdate, PreferenciasUpdate, DadosUsuario, updates
from security import current_user, password_hash, password_matches, digest, now
from services.serializers import serialize
from fastapi import HTTPException
from schemas import LoginResponse

router = APIRouter(tags=['Conta do cidadão'])


@router.post('/auth/cadastro', status_code=201, response_model=DadosUsuario)
def cadastro(data: Cadastro, db: Session = Depends(get_db)):
    user = Usuario(nome=data.nome, email=data.email, perfil='CIDADAO')
    db.add(user)
    db.flush()
    db.add(Credencial(id_usuario=user.id_usuario, senha_hash=password_hash(data.senha)))
    db.add(Preferencia(id_usuario=user.id_usuario))
    db.commit()
    db.refresh(user)
    return {'dados': serialize(user)}


@router.post('/auth/login', response_model=LoginResponse)
def login(data: Login, request: Request, db: Session = Depends(get_db)):
    user = db.scalar(select(Usuario).where(Usuario.email == data.email))
    credential = db.get(Credencial, user.id_usuario) if user else None
    match = password_matches(data.senha, credential.senha_hash if credential else request.app.state.dummy_hash)
    if not user or not user.ativo or not credential or not match:
        raise HTTPException(401, 'E-mail ou senha inválidos.')
    token = secrets.token_urlsafe(32)
    expiry = now() + timedelta(hours=request.app.state.settings.token_hours)
    db.execute(delete(Sessao).where(Sessao.expira_em <= now()))
    db.add(Sessao(token_hash=digest(token), id_usuario=user.id_usuario, expira_em=expiry))
    db.commit()
    return {'dados': {'access_token': token, 'token_type': 'Bearer', 'expira_em': expiry.isoformat(), 'usuario': serialize(user)}}


@router.post('/auth/logout', status_code=204)
def logout(request: Request, user=Depends(current_user), db: Session = Depends(get_db)):
    token = request.headers['authorization'].split(' ', 1)[1]
    db.execute(delete(Sessao).where(Sessao.token_hash == digest(token)))
    db.commit()
    return Response(status_code=204)


@router.get('/perfil', response_model=DadosUsuario)
def perfil(user=Depends(current_user)):
    return {'dados': serialize(user)}


@router.patch('/perfil', response_model=DadosUsuario)
def editar_perfil(data: PerfilUpdate, user=Depends(current_user), db: Session = Depends(get_db)):
    for name, value in updates(data).items():
        setattr(user, name, value)
    db.commit()
    return {'dados': serialize(user)}


@router.put('/perfil/senha')
def mudar_senha(data: SenhaUpdate, user=Depends(current_user), db: Session = Depends(get_db)):
    credential = db.get(Credencial, user.id_usuario)
    if not credential or not password_matches(data.senha_atual, credential.senha_hash):
        raise HTTPException(401, 'Senha atual inválida.')
    credential.senha_hash = password_hash(data.nova_senha)
    db.execute(delete(Sessao).where(Sessao.id_usuario == user.id_usuario))
    db.commit()
    return {'dados': {'mensagem': 'Senha alterada. Entre novamente.'}}


def preference(db, user):
    row = db.get(Preferencia, user.id_usuario)
    if not row:
        row = Preferencia(id_usuario=user.id_usuario)
        db.add(row)
        db.flush()
    return row


@router.get('/perfil/preferencias')
def preferencias(user=Depends(current_user), db: Session = Depends(get_db)):
    row = preference(db, user)
    db.commit()
    return {'dados': serialize(row)}


@router.patch('/perfil/preferencias')
def editar_preferencias(data: PreferenciasUpdate, user=Depends(current_user), db: Session = Depends(get_db)):
    row = preference(db, user)
    for name, value in updates(data).items():
        setattr(row, name, value)
    db.commit()
    return {'dados': serialize(row)}
