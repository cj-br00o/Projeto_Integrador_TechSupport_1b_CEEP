from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from database import get_db
from models import Ocorrencia, StatusOcorrencia, Categoria
from security import current_user, gestor
import math

router = APIRouter(tags=['Mapa e indicadores de gestão'])


@router.get('/mapa')
def mapa(bbox: str | None = None, id_categoria: int | None = Query(None, gt=0), db: Session = Depends(get_db)):
    stmt = select(Ocorrencia).join(StatusOcorrencia).where(StatusOcorrencia.status_final.is_(False))
    if bbox:
        try:
            west, south, east, north = map(float, bbox.split(','))
            if not all(math.isfinite(v) for v in (west, south, east, north)) or not (-180 <= west <= east <= 180 and -90 <= south <= north <= 90):
                raise ValueError()
        except ValueError:
            raise HTTPException(422, 'bbox: informe oeste,sul,leste,norte válidos.')
        stmt = stmt.where(Ocorrencia.longitude.between(west, east), Ocorrencia.latitude.between(south, north))
    if id_categoria:
        stmt = stmt.where(Ocorrencia.id_categoria == id_categoria)
    rows = list(db.scalars(stmt.order_by(Ocorrencia.id_ocorrencia.desc()).limit(501)))
    return {'type': 'FeatureCollection', 'features': [
        {'type': 'Feature', 'geometry': {'type': 'Point', 'coordinates': [round(float(r.longitude), 3), round(float(r.latitude), 3)]},
         'properties': {'id_ocorrencia': r.id_ocorrencia, 'categoria': r.categoria.nome if r.categoria else None,
                        'status': r.status.nome, 'status_codigo': r.status.codigo}} for r in rows[:500]],
        'meta': {'limite': 500, 'truncado': len(rows) > 500, 'localizacao': 'aproximada'}}


@router.get('/painel/cidadao')
def painel(user=Depends(current_user), db: Session = Depends(get_db)):
    rows = db.execute(select(StatusOcorrencia.codigo, func.count()).join(Ocorrencia).where(Ocorrencia.id_usuario == user.id_usuario).group_by(StatusOcorrencia.codigo))
    counts = dict(rows.all())
    return {'dados': {'total': sum(counts.values()), 'por_status': counts}}


@router.get('/indicadores')
def indicadores(user=Depends(gestor), db: Session = Depends(get_db)):
    rows = db.execute(select(Categoria.nome, func.count()).join(Ocorrencia).group_by(Categoria.nome))
    statuses = db.execute(select(StatusOcorrencia.codigo, func.count()).join(Ocorrencia).group_by(StatusOcorrencia.codigo))
    return {'dados': {'total_ocorrencias': db.scalar(select(func.count()).select_from(Ocorrencia)),
                      'por_categoria': [{'categoria': k, 'quantidade': v} for k, v in rows], 'por_status': dict(statuses.all()),
                      'fonte': 'banco local; não é o CSV acadêmico'}}
