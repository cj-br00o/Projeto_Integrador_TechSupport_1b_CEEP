from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select, func
from sqlalchemy.orm import Session, selectinload
from database import get_db
from models import Ocorrencia, Categoria, StatusOcorrencia, HistoricoStatus, Equipe, Atendimento, AnaliseIA
from schemas import OcorrenciaCreate, OcorrenciaUpdate, DadosOcorrencia, StatusUpdate, PrioridadeUpdate, AtendimentoCreate, AtendimentoEnd, updates
from security import current_user, gestor, record, access, STAFF, now
from services.serializers import serialize
from schemas import ListaOcorrencias

router = APIRouter(tags=['Ocorrências e relacionamentos'])
TRANSITIONS = {'RECEBIDA': {'EM_ANALISE'}, 'EM_ANALISE': {'ENCAMINHADA'}, 'ENCAMINHADA': {'EM_ATENDIMENTO', 'EM_ANALISE'}, 'EM_ATENDIMENTO': {'RESOLVIDA', 'EM_ANALISE'}, 'RESOLVIDA': set()}


def category(db, ident):
    row = record(db, Categoria, ident)
    if not row.ativo:
        raise HTTPException(409, 'Categoria inativa.')
    return row


@router.post('/ocorrencias', status_code=201, response_model=DadosOcorrencia)
def nova_ocorrencia(data: OcorrenciaCreate, user=Depends(current_user), db: Session = Depends(get_db)):
    cat = category(db, data.id_categoria)
    status = db.scalar(select(StatusOcorrencia).where(StatusOcorrencia.codigo == 'RECEBIDA'))
    if not status:
        raise HTTPException(503, 'Inicialize o banco local antes de cadastrar ocorrências.')
    row = Ocorrencia(**data.model_dump(), protocolo='RU-'+uuid4().hex[:17].upper(), id_usuario=user.id_usuario,
                     id_status=status.id_status, prioridade='MEDIA')
    db.add(row)
    db.flush()
    db.add(HistoricoStatus(id_ocorrencia=row.id_ocorrencia, id_status=status.id_status,
                          id_usuario_responsavel=user.id_usuario, observacao='Solicitação registrada.'))
    db.commit()
    db.refresh(row)
    return {'dados': serialize(row)}


@router.get('/ocorrencias', response_model=ListaOcorrencias)
def ocorrencias(pagina: int = Query(1, ge=1), limite: int = Query(20, ge=1, le=100),
                id_categoria: int | None = Query(None, gt=0), id_status: int | None = Query(None, gt=0),
                busca: str | None = Query(None, max_length=120), escopo: str = Query('minhas', pattern='^(minhas|todas)$'),
                user=Depends(current_user), db: Session = Depends(get_db)):
    stmt = select(Ocorrencia)
    if user.perfil not in STAFF or escopo != 'todas':
        stmt = stmt.where(Ocorrencia.id_usuario == user.id_usuario)
    if id_categoria:
        stmt = stmt.where(Ocorrencia.id_categoria == id_categoria)
    if id_status:
        stmt = stmt.where(Ocorrencia.id_status == id_status)
    if busca:
        stmt = stmt.where(Ocorrencia.protocolo.contains(busca, autoescape=True) | Ocorrencia.descricao.contains(busca, autoescape=True))
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    stmt = stmt.options(selectinload(Ocorrencia.categoria), selectinload(Ocorrencia.status))
    rows = db.scalars(stmt.order_by(Ocorrencia.criado_em.desc(), Ocorrencia.id_ocorrencia.desc()).offset((pagina-1)*limite).limit(limite))
    return {'dados': [serialize(r) for r in rows], 'paginacao': {'pagina': pagina, 'limite': limite, 'total': total}}


@router.get('/ocorrencias/{id_ocorrencia}', response_model=DadosOcorrencia)
def detalhes(id_ocorrencia: int, user=Depends(current_user), db: Session = Depends(get_db)):
    return {'dados': serialize(access(record(db, Ocorrencia, id_ocorrencia), user))}


@router.patch('/ocorrencias/{id_ocorrencia}', response_model=DadosOcorrencia)
def editar(id_ocorrencia: int, data: OcorrenciaUpdate, user=Depends(current_user), db: Session = Depends(get_db)):
    row = access(record(db, Ocorrencia, id_ocorrencia), user)
    if row.status.codigo != 'RECEBIDA':
        raise HTTPException(409, 'Só é possível editar antes da análise.')
    values = updates(data)
    if 'id_categoria' in values:
        category(db, values['id_categoria'])
    for name, value in values.items():
        setattr(row, name, value)
    row.atualizado_em = now()
    db.commit()
    db.expire(row)
    return {'dados': serialize(row)}


@router.patch('/ocorrencias/{id_ocorrencia}/status', response_model=DadosOcorrencia)
def status_update(id_ocorrencia: int, data: StatusUpdate, user=Depends(gestor), db: Session = Depends(get_db)):
    row = record(db, Ocorrencia, id_ocorrencia, lock=True)
    if data.codigo not in TRANSITIONS[row.status.codigo]:
        raise HTTPException(409, 'Transição de status não permitida.')
    if data.codigo == 'RESOLVIDA':
        finished = db.scalar(select(Atendimento.id_atendimento).where(Atendimento.id_ocorrencia == id_ocorrencia, Atendimento.fim_em.is_not(None)))
        if not finished:
            raise HTTPException(409, 'Finalize o atendimento antes de resolver a ocorrência.')
    status = db.scalar(select(StatusOcorrencia).where(StatusOcorrencia.codigo == data.codigo))
    if not status:
        raise HTTPException(404, 'Status não encontrado.')
    row.id_status, row.atualizado_em = status.id_status, now()
    db.add(HistoricoStatus(id_ocorrencia=id_ocorrencia, id_status=status.id_status,
                          id_usuario_responsavel=user.id_usuario, observacao=data.observacao))
    db.commit()
    db.expire(row)
    return {'dados': serialize(row)}


@router.patch('/ocorrencias/{id_ocorrencia}/prioridade', response_model=DadosOcorrencia)
def prioridade(id_ocorrencia: int, data: PrioridadeUpdate, user=Depends(gestor), db: Session = Depends(get_db)):
    row = record(db, Ocorrencia, id_ocorrencia)
    row.prioridade, row.atualizado_em = data.prioridade, now()
    db.commit()
    return {'dados': serialize(row)}


@router.get('/ocorrencias/{id_ocorrencia}/historico')
def historico(id_ocorrencia: int, pagina: int = Query(1, ge=1), limite: int = Query(20, ge=1, le=100), user=Depends(current_user), db: Session = Depends(get_db)):
    access(record(db, Ocorrencia, id_ocorrencia), user)
    stmt = select(HistoricoStatus, StatusOcorrencia.nome).join(StatusOcorrencia).where(HistoricoStatus.id_ocorrencia == id_ocorrencia)
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.execute(stmt.order_by(HistoricoStatus.alterado_em, HistoricoStatus.id_historico).offset((pagina-1)*limite).limit(limite))
    return {'dados': [dict(serialize(r), status=name) for r, name in rows], 'paginacao': {'pagina': pagina, 'limite': limite, 'total': total}}


@router.get('/ocorrencias/{id_ocorrencia}/analises')
def analises(id_ocorrencia: int, pagina: int = Query(1, ge=1), limite: int = Query(20, ge=1, le=100), user=Depends(gestor), db: Session = Depends(get_db)):
    record(db, Ocorrencia, id_ocorrencia)
    stmt = select(AnaliseIA).where(AnaliseIA.id_ocorrencia == id_ocorrencia)
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.order_by(AnaliseIA.analisado_em.desc(), AnaliseIA.id_analise.desc()).offset((pagina-1)*limite).limit(limite))
    return {'dados': [serialize(r) for r in rows], 'paginacao': {'pagina': pagina, 'limite': limite, 'total': total}}


@router.post('/ocorrencias/{id_ocorrencia}/atendimentos', status_code=201)
def criar_atendimento(id_ocorrencia: int, data: AtendimentoCreate, user=Depends(gestor), db: Session = Depends(get_db)):
    # Serializa a verificação e inserção por ocorrência no PostgreSQL.
    row = record(db, Ocorrencia, id_ocorrencia, lock=True)
    if row.status.status_final:
        raise HTTPException(409, 'Ocorrência encerrada.')
    team = record(db, Equipe, data.id_equipe)
    if not team.ativa:
        raise HTTPException(409, 'Equipe inativa.')
    if db.scalar(select(Atendimento.id_atendimento).where(Atendimento.id_ocorrencia == id_ocorrencia, Atendimento.fim_em.is_(None))):
        raise HTTPException(409, 'Já existe atendimento em aberto.')
    service = Atendimento(**data.model_dump(), id_ocorrencia=id_ocorrencia, inicio_em=now())
    db.add(service)
    db.commit()
    return {'dados': serialize(service)}


@router.get('/ocorrencias/{id_ocorrencia}/atendimentos')
def atendimentos(id_ocorrencia: int, pagina: int = Query(1, ge=1), limite: int = Query(20, ge=1, le=100), user=Depends(current_user), db: Session = Depends(get_db)):
    access(record(db, Ocorrencia, id_ocorrencia), user)
    stmt = select(Atendimento, Equipe.nome).join(Equipe).where(Atendimento.id_ocorrencia == id_ocorrencia)
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.execute(stmt.order_by(Atendimento.id_atendimento).offset((pagina-1)*limite).limit(limite))
    return {'dados': [dict(serialize(r), equipe=name) for r, name in rows], 'paginacao': {'pagina': pagina, 'limite': limite, 'total': total}}


@router.patch('/atendimentos/{id_atendimento}/concluir')
def concluir(id_atendimento: int, data: AtendimentoEnd, user=Depends(gestor), db: Session = Depends(get_db)):
    row = record(db, Atendimento, id_atendimento)
    if row.fim_em:
        raise HTTPException(409, 'Atendimento já finalizado.')
    row.fim_em = now()
    if data.observacao:
        row.observacao = data.observacao
    db.commit()
    return {'dados': serialize(row)}
