"""Rotas de IA leem somente CSV. Não importam database, models ou get_db."""
from fastapi import APIRouter, Request, HTTPException
import pandas as pd
from analise import ler_dados, resumo, por_categoria, por_data, qualidade
from schemas import ResumoAnalise, CategoriaAnalise, DataAnalise

router = APIRouter(tags=['Ciência de dados com CSV'])


def carregar(request):
    try:
        return ler_dados(request.app.state.settings.csv_path)
    except (OSError, UnicodeError):
        raise HTTPException(503, 'CSV indisponível. Confira CSV_PATH.')
    except (ValueError, pd.errors.ParserError) as exc:
        raise HTTPException(422, 'CSV inválido: ' + str(exc))


@router.get('/analise/resumo', response_model=ResumoAnalise)
def resumo_get(request: Request):
    return resumo(carregar(request))


@router.get('/analise/categorias', response_model=list[CategoriaAnalise])
def categorias_get(request: Request):
    return por_categoria(carregar(request))


@router.get('/analise/datas', response_model=list[DataAnalise])
def datas_get(request: Request):
    return por_data(carregar(request))


@router.get('/analise/qualidade')
def qualidade_get(request: Request):
    return qualidade(carregar(request))
