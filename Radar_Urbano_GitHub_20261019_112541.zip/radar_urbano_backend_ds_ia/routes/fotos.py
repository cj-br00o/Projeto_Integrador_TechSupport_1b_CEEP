from pathlib import Path
from uuid import uuid4
from fastapi import APIRouter, Depends, UploadFile, File, Request, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from PIL import Image, UnidentifiedImageError
from database import get_db
from models import FotoOcorrencia, Ocorrencia
from security import current_user, record, access
from services.serializers import serialize
import io

router = APIRouter(tags=['Fotos privadas'])


@router.get('/ocorrencias/{id_ocorrencia}/fotos')
def fotos(id_ocorrencia: int, user=Depends(current_user), db: Session = Depends(get_db)):
    access(record(db, Ocorrencia, id_ocorrencia), user)
    return {'dados': [serialize(r) for r in db.scalars(select(FotoOcorrencia).where(FotoOcorrencia.id_ocorrencia == id_ocorrencia))]}


@router.post('/ocorrencias/{id_ocorrencia}/fotos', status_code=201)
def foto_upload(id_ocorrencia: int, request: Request, arquivo: UploadFile = File(...), user=Depends(current_user), db: Session = Depends(get_db)):
    access(record(db, Ocorrencia, id_ocorrencia, lock=True), user)
    count = db.scalar(select(func.count()).select_from(FotoOcorrencia).where(FotoOcorrencia.id_ocorrencia == id_ocorrencia))
    if count >= 5:
        raise HTTPException(409, 'Limite de cinco fotos.')
    raw = arquivo.file.read(6*1024*1024+1)
    if len(raw) > 6*1024*1024:
        raise HTTPException(413, 'Foto acima de 6 MiB.')
    try:
        image = Image.open(io.BytesIO(raw))
        if image.format not in ('JPEG', 'PNG', 'WEBP') or image.width * image.height > 16000000:
            raise ValueError()
        image.load()
        image = image.convert('RGB')
        image.thumbnail((2048, 2048))
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError):
        raise HTTPException(422, 'Imagem inválida. Use JPEG, PNG ou WebP de até 16 megapixels.')
    directory = request.app.state.settings.upload_dir
    directory.mkdir(parents=True, exist_ok=True)
    name = uuid4().hex + '.jpg'
    path = directory / name
    image.save(path, 'JPEG', quality=85)  # Remove EXIF; não há diretório público de uploads.
    row = FotoOcorrencia(id_ocorrencia=id_ocorrencia, url_arquivo=name)
    try:
        db.add(row)
        db.flush()
        row.url_arquivo = f'/api/v1/fotos/{row.id_foto}/arquivo?nome={name}'
        db.commit()
    except Exception:
        path.unlink(missing_ok=True)
        raise
    return {'dados': serialize(row)}


@router.get('/fotos/{id_foto}/arquivo')
def foto_arquivo(id_foto: int, request: Request, user=Depends(current_user), db: Session = Depends(get_db)):
    row = record(db, FotoOcorrencia, id_foto)
    access(record(db, Ocorrencia, row.id_ocorrencia), user)
    name = row.url_arquivo.split('?nome=', 1)[-1]
    if Path(name).name != name:
        raise HTTPException(404, 'Arquivo não encontrado.')
    path = request.app.state.settings.upload_dir / name
    if not path.is_file():
        raise HTTPException(404, 'Arquivo não encontrado.')
    return FileResponse(path, media_type='image/jpeg', headers={'Cache-Control': 'private, no-store'})
