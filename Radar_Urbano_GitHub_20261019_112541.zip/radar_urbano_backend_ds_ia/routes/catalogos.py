from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from database import get_db
from models import Categoria, Equipe, Usuario, StatusOcorrencia
from schemas import CategoriaCreate, CategoriaUpdate, EquipeCreate, EquipeUpdate, DadosCategoria, ListaCategorias, updates
from security import gestor, record
from services.serializers import serialize

router = APIRouter(tags=['Cadastros e chaves primárias'])


@router.get('/categorias', response_model=ListaCategorias)
def categorias(pagina: int = Query(1, ge=1), limite: int = Query(20, ge=1, le=100), db: Session = Depends(get_db)):
    stmt = select(Categoria).where(Categoria.ativo.is_(True))
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.order_by(Categoria.nome, Categoria.id_categoria).offset((pagina-1)*limite).limit(limite))
    return {'dados': [serialize(r) for r in rows], 'paginacao': {'pagina': pagina, 'limite': limite, 'total': total}}


@router.post('/categorias', status_code=201, response_model=DadosCategoria)
def nova_categoria(data: CategoriaCreate, user=Depends(gestor), db: Session = Depends(get_db)):
    row = Categoria(**data.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return {'dados': serialize(row)}


@router.patch('/categorias/{id_categoria}', response_model=DadosCategoria)
def categoria_update(id_categoria: int, data: CategoriaUpdate, user=Depends(gestor), db: Session = Depends(get_db)):
    row = record(db, Categoria, id_categoria)
    for name, value in updates(data).items():
        setattr(row, name, value)
    db.commit()
    return {'dados': serialize(row)}


@router.get('/status')
def status(db: Session = Depends(get_db)):
    return {'dados': [serialize(r) for r in db.scalars(select(StatusOcorrencia).order_by(StatusOcorrencia.ordem))]}


@router.get('/equipes')
def equipes(pagina: int = Query(1, ge=1), limite: int = Query(20, ge=1, le=100), user=Depends(gestor), db: Session = Depends(get_db)):
    rows = db.scalars(select(Equipe).order_by(Equipe.nome, Equipe.id_equipe).offset((pagina-1)*limite).limit(limite))
    total = db.scalar(select(func.count()).select_from(Equipe))
    return {'dados': [serialize(r) for r in rows], 'paginacao': {'pagina': pagina, 'limite': limite, 'total': total}}


@router.post('/equipes', status_code=201)
def nova_equipe(data: EquipeCreate, user=Depends(gestor), db: Session = Depends(get_db)):
    row = Equipe(**data.model_dump())
    db.add(row)
    db.commit()
    return {'dados': serialize(row)}


@router.patch('/equipes/{id_equipe}')
def equipe_update(id_equipe: int, data: EquipeUpdate, user=Depends(gestor), db: Session = Depends(get_db)):
    row = record(db, Equipe, id_equipe)
    for name, value in updates(data).items():
        setattr(row, name, value)
    db.commit()
    return {'dados': serialize(row)}


@router.get('/usuarios')
def usuarios(pagina: int = Query(1, ge=1), limite: int = Query(20, ge=1, le=100), user=Depends(gestor), db: Session = Depends(get_db)):
    if user.perfil != 'ADMINISTRADOR':
        raise HTTPException(403, 'Apenas administrador.')
    rows = db.scalars(select(Usuario).order_by(Usuario.id_usuario).offset((pagina-1)*limite).limit(limite))
    return {'dados': [serialize(r) for r in rows], 'paginacao': {'pagina': pagina, 'limite': limite, 'total': db.scalar(select(func.count()).select_from(Usuario))}}
