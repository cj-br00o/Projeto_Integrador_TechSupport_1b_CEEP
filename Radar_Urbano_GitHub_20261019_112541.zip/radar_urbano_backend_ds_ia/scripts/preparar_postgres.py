"""Cria somente o banco exclusivo do cluster privado já inicializado."""
import secrets
import sys
from pathlib import Path
import psycopg
from psycopg import sql

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    target = ROOT / '.env'
    if target.exists():
        print('.env existente preservado; nenhuma conta ou banco alterado.')
        return
    password = secrets.token_urlsafe(36)
    # Socket privado do cluster criado para este projeto, sem credenciais herdadas.
    with psycopg.connect(host='/tmp/radar-pg-1001', port=55432, user='radar_local', dbname='postgres', autocommit=True) as conn:
        if conn.execute("SELECT 1 FROM pg_roles WHERE rolname='radar_app'").fetchone():
            raise RuntimeError('Conta já existe. Não será substituída.')
        if conn.execute("SELECT 1 FROM pg_database WHERE datname='radar_urbano_local'").fetchone():
            raise RuntimeError('Banco já existe. Não será substituído.')
        conn.execute(sql.SQL('CREATE ROLE radar_app LOGIN PASSWORD {}').format(sql.Literal(password)))
        conn.execute('CREATE DATABASE radar_urbano_local OWNER radar_app')
    with target.open('x') as file:
        file.write(f'DATABASE_URL=postgresql+psycopg://radar_app:{password}@127.0.0.1:55432/radar_urbano_local\n')
        file.write('CSV_PATH=database/ocorrencias.csv\nCORS_ORIGINS=http://localhost:5173,http://127.0.0.1:5173,http://localhost:5500,http://127.0.0.1:5500\n')
    target.chmod(0o600)
    print('Conta nova sem superusuário e banco exclusivo criados; .env privado salvo sem imprimir senha.')


if __name__ == '__main__':
    main()
