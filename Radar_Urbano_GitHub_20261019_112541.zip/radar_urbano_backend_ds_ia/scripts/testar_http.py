"""Exercita HTTP real em processo separado, sempre em banco temporário local."""
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]


def run():
    report = []
    with tempfile.TemporaryDirectory(prefix='radar-http-') as temp:
        env = dict(os.environ, DATABASE_URL='sqlite:///' + str(Path(temp) / 'http.db'))
        subprocess.run([sys.executable, 'gerenciar.py', 'init-db'], cwd=ROOT, env=env, check=True, capture_output=True)
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0))
            port = sock.getsockname()[1]
        server = subprocess.Popen([sys.executable, '-m', 'uvicorn', 'main:app', '--host', '127.0.0.1', '--port', str(port)], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        base = f'http://127.0.0.1:{port}/api/v1'

        def request(method, path, data=None, token=None, expected=200):
            headers = {'Content-Type': 'application/json'}
            if token:
                headers['Authorization'] = 'Bearer ' + token
            req = Request(base + path, data=json.dumps(data).encode() if data is not None else None, headers=headers, method=method)
            try:
                with urlopen(req, timeout=5) as response:
                    code, payload = response.status, response.read()
            except HTTPError as exc:
                code, payload = exc.code, exc.read()
            assert code == expected, (method, path, code, payload)
            result = json.loads(payload) if payload else None
            # Não gravar token nem senha no relatório de execução.
            report.append({'metodo': method, 'rota': path, 'status': code, 'esperado': expected, 'resultado': 'OK'})
            return result

        try:
            deadline = time.monotonic() + 20
            while True:
                try:
                    request('GET', '/saude')
                    break
                except (URLError, TimeoutError):
                    if time.monotonic() > deadline:
                        raise RuntimeError('Servidor não iniciou no prazo.')
                    time.sleep(.1)
            data = {'nome': 'Cidadão HTTP de teste', 'email': 'http@example.test', 'senha': 'TesteTemporario123!'}
            request('POST', '/auth/cadastro', data, expected=201)
            login = request('POST', '/auth/login', {'email': data['email'], 'senha': data['senha']})
            token = login['dados']['access_token']
            categories = request('GET', '/categorias')['dados']
            row = request('POST', '/ocorrencias', {'id_categoria': categories[0]['id_categoria'], 'descricao': 'Buraco na via pública em teste local.', 'latitude': -23.42, 'longitude': -51.93}, token, 201)['dados']
            request('GET', '/ocorrencias', token=token)
            request('GET', f'/ocorrencias/{row["id_ocorrencia"]}/historico', token=token)
            request('GET', '/mapa')
            request('GET', '/ocorrencias/'+str(row['id_ocorrencia']), expected=401)
            for endpoint in ['resumo', 'categorias', 'datas', 'qualidade']:
                analysis = request('GET', '/analise/'+endpoint)
                output = ROOT / 'evidencias' / 'json' / (endpoint+'.json')
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(json.dumps(analysis,ensure_ascii=False,indent=2,allow_nan=False))
            request('GET', '/perfil', token=token)
            request('GET', '/equipes', token=token, expected=403)
            request('POST', '/ocorrencias', {'id_categoria': 999999, 'descricao': 'Relacionamento inexistente em teste.', 'latitude': -23.4, 'longitude': -51.9}, token=token, expected=404)
            request('POST', '/auth/logout', token=token, expected=204)
            request('GET', '/perfil', token=token, expected=401)
        finally:
            server.terminate()
            try:
                server.wait(timeout=5)
            except subprocess.TimeoutExpired:
                server.kill()
                server.wait()
    destination = ROOT / 'evidencias' / 'http_local.json'
    destination.parent.mkdir(exist_ok=True)
    destination.write_text(json.dumps({'ambiente': 'local temporário, FastAPI/Uvicorn/SQLite', 'requisicoes': report}, ensure_ascii=False, indent=2))
    print(f'{len(report)} requisições HTTP verificadas; processo encerrado e banco temporário removido.')


if __name__ == '__main__':
    run()
