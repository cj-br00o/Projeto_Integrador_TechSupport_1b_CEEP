"""Conferência independente: biblioteca padrão, sem usar Pandas para os cálculos."""
from collections import Counter
import csv
from datetime import datetime
from pathlib import Path
import json
import statistics
import sys
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from analise import CSV_PADRAO, ler_dados, resumo, por_categoria, por_data


def conferir():
    with CSV_PADRAO.open(encoding='utf-8', newline='') as file:
        rows = list(csv.DictReader(file))
    seconds = []
    per_category, per_day = Counter(), Counter()
    urgent = 0
    for row in rows:
        created = datetime.fromisoformat(row['criado_em'].replace('Z', '+00:00'))
        per_category[row['categoria_codigo'] or 'SEM_CATEGORIA'] += 1
        per_day[created.astimezone(ZoneInfo('America/Sao_Paulo')).date().isoformat()] += 1
        urgent += row['prioridade'] in ('ALTA', 'CRITICA')
        if row['analisado_em']:
            analyzed = datetime.fromisoformat(row['analisado_em'].replace('Z', '+00:00'))
            seconds.append((analyzed-created).total_seconds())
    df = ler_dados()
    result = resumo(df)
    assert result['total_ocorrencias'] == len({r['id_ocorrencia'] for r in rows})
    assert result['tempo_analise_soma_min'] == round(sum(seconds)/60, 2)
    assert result['tempo_analise_media_min'] == round(statistics.mean(seconds)/60, 2)
    assert result['tempo_analise_mediana_min'] == round(statistics.median(seconds)/60, 2)
    assert result['ocorrencias_urgentes'] == urgent
    assert {r['categoria_codigo']:r['total_ocorrencias'] for r in por_categoria(df)} == dict(per_category)
    assert {r['data']:r['total_ocorrencias'] for r in por_data(df)} == dict(per_day)
    for group in (por_categoria(df), por_data(df)):
        assert sum(r['total_ocorrencias'] for r in group) == result['total_ocorrencias']
        assert round(sum(r['tempo_analise_soma_min'] for r in group), 2) == result['tempo_analise_soma_min']
    category_rows = [r for r in rows if r['categoria_codigo']=='INFRAESTRUTURA']
    samples = []
    for row in category_rows:
        start = datetime.fromisoformat(row['criado_em'])
        end = datetime.fromisoformat(row['analisado_em'])
        samples.append({'id_ocorrencia':int(row['id_ocorrencia']), 'criado_em':row['criado_em'], 'analisado_em':row['analisado_em'], 'diferenca_segundos':(end-start).total_seconds(), 'tempo_min':(end-start).total_seconds()/60})
    return {'resultado':'OK', 'metodo':'csv.DictReader + datetime + statistics; comparação independente com Pandas',
            'registro_individual':samples[0], 'grupo_conferido':{'categoria_codigo':'INFRAESTRUTURA','registros':samples,'contagem':len(samples),'soma_tempos_min':sum(r['tempo_min'] for r in samples)},
            'reconciliacao':{'linhas':len(rows),'ocorrencias_distintas':len({r['id_ocorrencia'] for r in rows}),'soma_grupos_categoria':sum(per_category.values()),'soma_grupos_data':sum(per_day.values()),'soma_tempos_min':sum(seconds)/60,'media_min':statistics.mean(seconds)/60,'mediana_min':statistics.median(seconds)/60,'urgentes':urgent},
            'limite':'Tempos até análise registrada; não são tempos de resolução do serviço.'}


if __name__ == '__main__':
    result = conferir()
    path = ROOT/'evidencias/conferencia_calculos.json'
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
    print('Cálculos conferidos independentemente; totais reconciliados.')
