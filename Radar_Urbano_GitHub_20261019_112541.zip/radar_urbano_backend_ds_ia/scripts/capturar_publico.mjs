// Captura somente telas públicas do sistema principal, sem conta ou credenciais.
import {chromium} from '@playwright/test';
import {mkdir,writeFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
const out=resolve('evidencias','frontend_abertura_'+new Date().toISOString().replace(/[:.]/g,'-'));
await mkdir(out,{recursive:true});
const browser=await chromium.launch({channel:'chrome',headless:true});
try{
  const page=await browser.newPage({viewport:{width:390,height:844},locale:'pt-BR'});
  await page.goto('http://127.0.0.1:8000/#/mapa');
  await page.getByRole('heading',{name:'Mapa de ocorrências',exact:true}).waitFor();
  let tileState='base carregada';
  try{
    await page.waitForFunction(()=>{
      const el=document.querySelector('#public-map');
      if(!el)return false;
      const b=el.getBoundingClientRect();
      const tiles=[...el.querySelectorAll('.leaflet-tile')].filter(tile=>{const r=tile.getBoundingClientRect();return r.right>b.left&&r.left<b.right&&r.bottom>b.top&&r.top<b.bottom;});
      return tiles.length>0&&tiles.every(img=>img.complete&&img.naturalWidth>0&&getComputedStyle(img).opacity==='1');
    },null,{timeout:20000});
  }catch{tileState='base de ruas não terminou de carregar no prazo; controles e lista permanecem disponíveis';}
  await page.screenshot({path:join(out,'mapa-publico-mobile.png'),fullPage:true});
  const report={url:page.url(),navegador:await browser.version(),escopo:'tela pública, sem login',mapa:tileState,
    imagens:await page.locator('#public-map .leaflet-tile').evaluateAll(images=>({total:images.length,carregadas:images.filter(img=>img.complete&&img.naturalWidth>0).length}))};
  await writeFile(join(out,'resultado.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify(report));
  console.log(out);
}finally{await browser.close();}
