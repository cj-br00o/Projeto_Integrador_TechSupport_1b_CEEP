"""HTTP real, PostgreSQL descartável próprio, concorrência e reinício da API.

Nunca usa o banco operacional para os cadastros de teste. Senhas/tokens ficam
somente na memória; cada execução produz uma pasta nova de evidências.
"""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import io
import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import tempfile
import time
from uuid import uuid4
from zoneinfo import ZoneInfo

import httpx
from PIL import Image
import psycopg
from psycopg import sql

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from config import Settings
from database import criar_engine
from gerenciar import inicializar
from models import Usuario, Credencial
from security import password_hash
from sqlalchemy.engine import make_url
from sqlalchemy.orm import Session
from scripts.conferir_calculos import conferir


def sanitized(value):
    if isinstance(value, dict):
        return {k: sanitized(v) for k, v in value.items() if k not in {'access_token', 'senha', 'senha_hash', 'token_hash'}}
    if isinstance(value, list):
        return [sanitized(v) for v in value]
    return value


def main():
    stamp = datetime.now(ZoneInfo('America/Sao_Paulo')).strftime('%Y%m%d_%H%M%S_%f')
    out = ROOT / 'evidencias' / ('notebook_http_' + stamp)
    out.mkdir(parents=True)
    name = 'radar_test_' + uuid4().hex
    operational = make_url(Settings.from_env().database_url)
    if operational.drivername != 'postgresql+psycopg' or operational.host != '127.0.0.1' or operational.port != 55432:
        raise RuntimeError('Este roteiro exige o cluster privado preparado no notebook, porta 55432.')
    db_url = operational.set(database=name).render_as_string(hide_password=False)
    admin = psycopg.connect(host='/tmp/radar-pg-1001', port=55432, user='radar_local', dbname='postgres', autocommit=True)
    admin.execute(sql.SQL('CREATE DATABASE {} OWNER radar_app').format(sql.Identifier(name)))
    report = {'inicio': datetime.now(ZoneInfo('America/Sao_Paulo')).isoformat(), 'banco': 'PostgreSQL 16 local, banco descartável exclusivo', 'requisicoes': []}
    server = None
    engine = criar_engine(db_url)
    password = secrets.token_urlsafe(24)
    try:
        inicializar(engine)
        with Session(engine) as session:
            user = Usuario(nome='Gestão fictícia de teste', email='gestor@example.test', perfil='ADMINISTRADOR')
            session.add(user)
            session.flush()
            session.add(Credencial(id_usuario=user.id_usuario, senha_hash=password_hash(password)))
            session.commit()
        with tempfile.TemporaryDirectory(prefix='radar-uploads-') as temp:
            with socket.socket() as sock:
                sock.bind(('127.0.0.1', 0))
                port = sock.getsockname()[1]
            env = dict(os.environ, DATABASE_URL=db_url, UPLOAD_DIR=temp)
            base = f'http://127.0.0.1:{port}'
            logfile = (out/'uvicorn.log').open('w')

            def start():
                process = subprocess.Popen([sys.executable, '-m', 'uvicorn', 'main:app', '--host', '127.0.0.1', '--port', str(port)], cwd=ROOT, env=env, stdout=logfile, stderr=logfile)
                try:
                    for _ in range(100):
                        if process.poll() is not None:
                            raise RuntimeError('Uvicorn encerrou; consulte o log.')
                        try:
                            if httpx.get(base+'/api/v1/saude', timeout=1).status_code == 200:
                                return process
                        except httpx.TransportError:
                            pass
                        time.sleep(.1)
                    raise RuntimeError('API não iniciou no prazo.')
                except BaseException:
                    process.terminate()
                    process.wait(timeout=10)
                    raise

            def request(method, path, expected=200, token=None, **kwargs):
                headers = kwargs.pop('headers', {})
                if token:
                    headers['Authorization'] = 'Bearer ' + token
                response = httpx.request(method, base+path, headers=headers, timeout=20, **kwargs)
                assert response.status_code == expected, (method, path, response.status_code, sanitized(response.text[:1000]))
                if response.headers.get('content-type', '').startswith('application/json'):
                    data = response.json()
                    result = sanitized(data)
                else:
                    data = None
                    result = {'bytes': len(response.content), 'content_type': response.headers.get('content-type')}
                report['requisicoes'].append({'metodo': method, 'rota': path, 'status': response.status_code, 'resposta': result})
                return data

            server = start()
            request('GET', '/docs')
            contract = request('GET', '/openapi.json')
            (out/'openapi.json').write_text(json.dumps(contract, ensure_ascii=False, indent=2))
            assert request('GET', '/api/v1/saude')['dados']['banco'] == 'postgresql'
            request('GET', '/api/v1/perfil', 401)
            citizen = {'nome': 'Cidadão fictício HTTP', 'email': 'cidadao@example.test', 'senha': password}
            request('POST', '/api/v1/auth/cadastro', 422, json=dict(citizen, perfil='ADMINISTRADOR'))
            request('POST', '/api/v1/auth/cadastro', 201, json=citizen)
            request('POST', '/api/v1/auth/cadastro', 409, json=citizen)
            request('POST', '/api/v1/auth/login', 401, json={'email': citizen['email'], 'senha': 'invalida'})
            token = request('POST', '/api/v1/auth/login', json={'email': citizen['email'], 'senha': password})['dados']['access_token']
            staff = request('POST', '/api/v1/auth/login', json={'email': 'gestor@example.test', 'senha': password})['dados']['access_token']
            category = {'codigo': 'TESTE_HTTP', 'nome': 'Categoria fictícia HTTP'}
            request('POST', '/api/v1/categorias', 401, json=category)
            request('POST', '/api/v1/categorias', 403, token=token, json=category)
            cat = request('POST', '/api/v1/categorias', 201, token=staff, json=category)['dados']
            request('POST', '/api/v1/categorias', 409, token=staff, json=category)
            cats = request('GET', '/api/v1/categorias?limite=100')
            assert any(r['id_categoria'] == cat['id_categoria'] for r in cats['dados'])
            request('GET', '/api/v1/categorias?pagina=0', 422)
            payload = {'id_categoria': cat['id_categoria'], 'descricao': 'Buraco fictício para validar o backend local.', 'latitude': -23.42, 'longitude': -51.93}
            request('POST', '/api/v1/ocorrencias', 401, json=payload)
            request('POST', '/api/v1/ocorrencias', 404, token=token, json=dict(payload, id_categoria=999999))
            request('POST', '/api/v1/ocorrencias', 422, token=token, json=dict(payload, latitude=91))
            row = request('POST', '/api/v1/ocorrencias', 201, token=token, json=payload)['dados']
            assert row['categoria'] == cat['nome'] and row['status_codigo'] == 'RECEBIDA'
            path = f'/api/v1/ocorrencias/{row["id_ocorrencia"]}'
            assert request('GET', '/api/v1/ocorrencias', token=token)['paginacao']['total'] == 1
            request('GET', path, token=token)
            request('GET', path+'/historico', token=token)
            other_data = dict(citizen, email='outro@example.test')
            request('POST', '/api/v1/auth/cadastro', 201, json=other_data)
            other = request('POST', '/api/v1/auth/login', json={'email': other_data['email'], 'senha': password})['dados']['access_token']
            for suffix in ('', '/historico', '/atendimentos', '/fotos'):
                request('GET', path+suffix, 404, token=other)
            assert request('GET', '/api/v1/ocorrencias?escopo=todas', token=other)['paginacao']['total'] == 0
            request('PATCH', path, 404, token=other, json={'descricao': 'Alteração proibida de outro cidadão.'})
            request('PATCH', path+'/status', 403, token=token, json={'codigo': 'EM_ANALISE'})
            request('PATCH', path+'/status', 409, token=staff, json={'codigo': 'RESOLVIDA'})
            request('PATCH', path+'/status', token=staff, json={'codigo': 'EM_ANALISE'})
            team = request('POST', '/api/v1/equipes', 201, token=staff, json={'nome': 'Equipe fictícia HTTP', 'especialidade': 'Manutenção'})['dados']
            request('POST', path+'/atendimentos', 404, token=staff, json={'id_equipe': 999999})

            def concurrent_service(_):
                return httpx.post(base+path+'/atendimentos', headers={'Authorization': 'Bearer '+staff}, json={'id_equipe': team['id_equipe']}, timeout=20)

            with ThreadPoolExecutor(max_workers=2) as pool:
                responses = list(pool.map(concurrent_service, range(2)))
            assert sorted(r.status_code for r in responses) == [201, 409]
            report['concorrencia_atendimentos'] = sorted(r.status_code for r in responses)
            service = next(r.json()['dados'] for r in responses if r.status_code == 201)
            request('GET', path+'/atendimentos', token=token)
            for code in ('ENCAMINHADA', 'EM_ATENDIMENTO'):
                request('PATCH', path+'/status', token=staff, json={'codigo': code})
            request('PATCH', f'/api/v1/atendimentos/{service["id_atendimento"]}/concluir', token=staff, json={})
            request('PATCH', path+'/status', token=staff, json={'codigo': 'RESOLVIDA'})
            assert request('GET', path+'/historico', token=token)['paginacao']['total'] == 5
            image = io.BytesIO()
            Image.new('RGB', (20, 20), 'blue').save(image, format='PNG')
            raw = image.getvalue()
            request('POST', path+'/fotos', 422, token=token, files={'arquivo': ('invalida.png', b'nao e imagem', 'image/png')})

            def concurrent_photo(_):
                return httpx.post(base+path+'/fotos', headers={'Authorization': 'Bearer '+token}, files={'arquivo': ('foto.png', raw, 'image/png')}, timeout=20)

            with ThreadPoolExecutor(max_workers=6) as pool:
                responses = list(pool.map(concurrent_photo, range(6)))
            assert sorted(r.status_code for r in responses) == [201]*5+[409]
            report['concorrencia_fotos'] = sorted(r.status_code for r in responses)
            photo_url = next(r.json()['dados']['url_arquivo'] for r in responses if r.status_code == 201)
            request('GET', photo_url, token=token)
            request('GET', photo_url, 401)
            request('GET', photo_url, 404, token=other)
            assert len(request('GET', path+'/fotos', token=token)['dados']) == 5
            for route in ('perfil', 'perfil/preferencias', 'painel/cidadao'):
                request('GET', '/api/v1/'+route, token=token)
            request('PATCH', '/api/v1/perfil', token=token, json={'nome': 'Nome fictício atualizado'})
            request('GET', '/api/v1/indicadores', token=staff)
            request('GET', '/api/v1/mapa')
            for endpoint in ('resumo', 'categorias', 'datas', 'qualidade'):
                analysis = request('GET', '/api/v1/analise/'+endpoint)
                (out/(endpoint+'.json')).write_text(json.dumps(analysis, ensure_ascii=False, indent=2, allow_nan=False))
            allowed = httpx.options(base+'/api/v1/categorias', headers={'Origin': 'http://localhost:5173', 'Access-Control-Request-Method': 'POST'})
            denied = httpx.options(base+'/api/v1/categorias', headers={'Origin': 'https://origem.example', 'Access-Control-Request-Method': 'POST'})
            assert allowed.headers.get('access-control-allow-origin') == 'http://localhost:5173'
            assert denied.status_code == 400 and 'access-control-allow-origin' not in denied.headers
            report['cors'] = {'origem_local': allowed.status_code, 'origem_externa': denied.status_code}
            before = request('GET', path, token=token)['dados']
            server.terminate()
            server.wait(timeout=10)
            server = start()
            after = request('GET', path, token=token)['dados']
            assert before == after
            assert request('GET', path+'/historico', token=token)['paginacao']['total'] == 5
            request('GET', photo_url, token=token)
            report['persistencia_apos_reinicio_api'] = {'resultado': 'OK', 'id_ocorrencia': after['id_ocorrencia'], 'protocolo': after['protocolo'], 'registro_identico': before == after, 'historico_eventos': 5, 'foto_e_sessao_preservadas': True}
            request('POST', '/api/v1/auth/logout', 204, token=token)
            request('GET', '/api/v1/perfil', 401, token=token)
            server.terminate()
            server.wait(timeout=10)
            server = None
            logfile.close()
        report['conferencia_independente'] = conferir()
        report['resultado'] = 'OK'
    finally:
        if server and server.poll() is None:
            server.terminate()
            server.wait(timeout=10)
        engine.dispose()
        # Exclusão limitada ao nome aleatório criado neste processo.
        admin.execute(sql.SQL('DROP DATABASE {} WITH (FORCE)').format(sql.Identifier(name)))
        admin.close()
        report['banco_de_teste_removido'] = True
        (out/'http.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False))
    print(f'{len(report["requisicoes"])} requisições HTTP verificadas; concorrência e persistência OK. Evidências: {out.name}')


if __name__ == '__main__':
    main()
