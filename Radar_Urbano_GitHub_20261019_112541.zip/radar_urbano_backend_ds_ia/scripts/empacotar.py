"""Pacote de entrega por lista permitida, sem bancos, credenciais ou venv."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    out = ROOT.parent/'entrega_local'
    out.mkdir(exist_ok=True)
    target = out/('Radar_Urbano_Sistema_Local_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.zip')
    allowed_dirs = {'routes', 'services', 'tests', 'scripts', 'docs', 'postman', '.vscode', 'frontend'}
    allowed_files = {'README.md', '.env.example', '.gitignore', 'pytest.ini', 'requirements.txt',
                     'requirements-dev.txt', 'requirements-lock.txt', 'Radar_Urbano.code-workspace',
                     'package.json', 'package-lock.json', 'playwright.config.js'}
    verified = []
    for folder in (ROOT/'evidencias').glob('frontend_cliente_*'):
        summary = folder/'resultado.json'
        if summary.exists():
            result = json.loads(summary.read_text())
            if result.get('resultado') == 'OK' and result.get('persistencia_apos_reinicio_api'):
                verified.append(folder.name)
    latest_frontend = max(verified, default='')
    latest_public = max((folder.name for folder in (ROOT/'evidencias').glob('frontend_abertura_*')
                         if (folder/'resultado.json').exists()), default='')
    chosen = []
    for p in ROOT.rglob('*'):
        if not p.is_file():
            continue
        rel = p.relative_to(ROOT)
        if any(s in {'__pycache__', '.venv', '.pytest_cache', 'instance', '.git', 'node_modules', 'test-results', 'playwright-report', 'resultados'} for s in rel.parts):
            continue
        if p.suffix in {'.db', '.sqlite', '.pyc', '.bundle'} or p.name == '.env':
            continue
        keep = (len(rel.parts) == 1 and (p.name in allowed_files or p.suffix in {'.py', '.sh', '.bat'}))
        keep |= rel.parts[0] in allowed_dirs
        keep |= str(rel) in {'database/ocorrencias.csv', 'database/schema_postgresql_local.sql'}
        keep |= rel.parts[0] == 'evidencias' and len(rel.parts)>1 and rel.parts[1].startswith('notebook')
        if rel.parts[0] == 'evidencias' and len(rel.parts)>1:
            keep |= rel.parts[1] == latest_frontend
            keep |= rel.parts[1] == latest_public
        # Os documentos antigos e o histórico importado permanecem no disco original.
        if p.name == 'README_ORIGINAL_ZIP.md':
            keep = False
        if keep:
            chosen.append(p)
    from sqlalchemy.engine import make_url
    from dotenv import dotenv_values
    url = dotenv_values(ROOT/'.env').get('DATABASE_URL')
    password = make_url(url).password if url else None
    manifest = {}
    for p in chosen:
        content = p.read_bytes()
        if password and password.encode() in content:
            raise RuntimeError('Credencial local encontrada: empacotamento interrompido.')
        manifest[p.relative_to(ROOT).as_posix()] = hashlib.sha256(content).hexdigest()
    collection = json.loads((ROOT/'postman/Radar_Urbano_DS_IA.postman_collection.json').read_text())
    assert all(not v.get('value') for v in collection['variable'] if v['key'] in {'senha', 'token', 'senha_gestor', 'token_gestor'})
    with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED) as archive:
        for p in sorted(chosen):
            archive.write(p, 'radar_urbano_backend_ds_ia/'+p.relative_to(ROOT).as_posix())
        archive.writestr('radar_urbano_backend_ds_ia/MANIFESTO_SHA256.json', json.dumps(manifest, ensure_ascii=False, indent=2))
        starter = ROOT.parent/'iniciar_radar.sh'
        if starter.exists():
            archive.write(starter, 'iniciar_radar.sh')
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        assert not any('/.env' == n[-5:] or '/instance/' in n or '/.venv/' in n or n.endswith('.bundle') for n in archive.namelist())
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    target.with_suffix('.sha256').write_text(digest+'  '+target.name+'\n')
    print(f'{len(chosen)} arquivos; ZIP íntegro e sem credenciais locais: {target}')


if __name__ == '__main__':
    main()
