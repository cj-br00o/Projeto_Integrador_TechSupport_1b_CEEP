"""Teste do cliente real em navegador isolado e PostgreSQL temporário exclusivo.

Não altera o banco operacional. Senhas e tokens não são salvos em relatório,
capturas, trace ou vídeo. Requer npm ci para as dependências de desenvolvimento.
"""
from datetime import datetime
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import secrets
import time
from uuid import uuid4
from zoneinfo import ZoneInfo

import httpx
import psycopg
from psycopg import sql
from sqlalchemy.engine import make_url

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from config import Settings
from database import criar_engine
from gerenciar import inicializar
from models import Usuario, Credencial
from sqlalchemy.orm import Session
from security import password_hash
from PIL import Image


def main():
    stamp = datetime.now(ZoneInfo('America/Sao_Paulo')).strftime('%Y%m%d_%H%M%S_%f')
    out = ROOT/'evidencias'/('frontend_cliente_'+stamp)
    out.mkdir(parents=True)
    db_name = 'radar_test_web_'+uuid4().hex
    url = make_url(Settings.from_env().database_url)
    if url.drivername != 'postgresql+psycopg' or url.host != '127.0.0.1' or url.port != 55432:
        raise RuntimeError('Use somente o cluster privado local preparado para este projeto.')
    admin = psycopg.connect(host='/tmp/radar-pg-1001', port=55432, user='radar_local', dbname='postgres', autocommit=True)
    admin.execute(sql.SQL('CREATE DATABASE {} OWNER radar_app').format(sql.Identifier(db_name)))
    engine = criar_engine(url.set(database=db_name).render_as_string(hide_password=False))
    server = None
    report = {'instante': datetime.now(ZoneInfo('America/Sao_Paulo')).isoformat(),
              'escopo': 'fluxos reais do frontend e módulos cliente em Chrome isolado; acessibilidade automatizada',
              'banco': 'PostgreSQL 16 local descartável', 'resultado': 'não concluído'}
    try:
        inicializar(engine)
        staff_password = secrets.token_urlsafe(24)
        with Session(engine) as session:
            user = Usuario(nome='Gestão de teste', email='gestao.ui@example.test', perfil='ADMINISTRADOR')
            session.add(user)
            session.flush()
            session.add(Credencial(id_usuario=user.id_usuario, senha_hash=password_hash(staff_password)))
            session.commit()
        with tempfile.TemporaryDirectory(prefix='radar-web-uploads-') as temp:
            photo = Path(temp)/'foto-teste.png'
            Image.new('RGB', (48, 48), '#278d37').save(photo, 'PNG')
            with socket.socket() as sock:
                sock.bind(('127.0.0.1', 0))
                port = sock.getsockname()[1]
            base = f'http://127.0.0.1:{port}'
            env = dict(os.environ, DATABASE_URL=url.set(database=db_name).render_as_string(hide_password=False),
                       UPLOAD_DIR=temp, RADAR_TEST_BASE_URL=base, RADAR_TEST_ISOLATED='1', RADAR_TEST_OUTPUT=str(out/'resultados'),
                       RADAR_TEST_EVIDENCE=str(out), RADAR_TEST_STAFF_PASSWORD=staff_password,
                       RADAR_TEST_IMAGE=str(photo), RADAR_PERSIST_EMAIL=f'persist-{uuid4().hex}@example.test',
                       RADAR_PERSIST_PASSWORD=secrets.token_urlsafe(24))
            with (out/'uvicorn.log').open('w') as log:
                def start_server():
                    process = subprocess.Popen([sys.executable, '-m', 'uvicorn', 'main:app', '--host', '127.0.0.1', '--port', str(port)], cwd=ROOT, env=env, stdout=log, stderr=log)
                    try:
                        for _ in range(100):
                            if process.poll() is not None:
                                raise RuntimeError('API de teste encerrou; veja o log da execução.')
                            try:
                                if httpx.get(base+'/api/v1/saude', timeout=1).status_code == 200:
                                    return process
                            except httpx.TransportError:
                                pass
                            time.sleep(.1)
                        raise RuntimeError('API de teste não iniciou.')
                    except BaseException:
                        process.terminate()
                        process.wait(timeout=10)
                        raise
                server = start_server()
                with (out/'playwright.txt').open('w') as output:
                    result = subprocess.run(['node', 'node_modules/@playwright/test/cli.js', 'test'],
                                            cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=240)
                report['codigo_saida'] = result.returncode
                if result.returncode:
                    raise RuntimeError('Teste do cliente falhou; consulte playwright.txt.')
                for phase in ('antes', 'depois'):
                    if phase == 'depois':
                        server.terminate()
                        server.wait(timeout=10)
                        server = start_server()
                    phase_env = dict(env, RADAR_TEST_PHASE=phase)
                    with (out/f'persistencia_{phase}.txt').open('w') as output:
                        result = subprocess.run(['node', 'node_modules/@playwright/test/cli.js', 'test', 'persist.spec.js'],
                                                cwd=ROOT, env=phase_env, stdout=output, stderr=subprocess.STDOUT, timeout=90)
                    if result.returncode:
                        raise RuntimeError(f'Teste de persistência falhou na fase {phase}. Consulte o log dessa fase.')
                report['persistencia_apos_reinicio_api'] = 'OK: cadastro, login, ocorrência, histórico e foto consultados pela interface após reiniciar Uvicorn'
                report['resultado'] = 'OK'
    finally:
        if server and server.poll() is None:
            server.terminate()
            server.wait(timeout=10)
        engine.dispose()
        admin.execute(sql.SQL('DROP DATABASE {} WITH (FORCE)').format(sql.Identifier(db_name)))
        admin.close()
        report['banco_temporario_removido'] = True
        (out/'resultado.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print('Telas, acessibilidade e persistência no Chrome/PostgreSQL verificadas. Evidência:', out.name)


if __name__ == '__main__':
    main()
