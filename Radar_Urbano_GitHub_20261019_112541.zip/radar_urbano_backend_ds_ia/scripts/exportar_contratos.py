"""Exporta contratos e DDL de documentação sem abrir conexão de banco."""
import json
from pathlib import Path
import sys
from sqlalchemy.schema import CreateTable, CreateIndex
from sqlalchemy.dialects import postgresql

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from main import app
from database import Base
from gerenciar import CATEGORIAS, STATUS


def main():
    contract=app.openapi()
    (ROOT/'docs/openapi.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2))
    routes=[{'caminho':path,'metodo':method.upper(),'descricao':config.get('summary','')}
            for path,data in contract['paths'].items() for method,config in data.items() if method in ('get','post','put','patch','delete')]
    (ROOT/'docs/rotas.json').write_text(json.dumps(routes,ensure_ascii=False,indent=2))
    dialect=postgresql.dialect()
    ddl=['-- Radar Urbano: esquema de referência para PostgreSQL LOCAL NOVO.', '-- Não executar no Supabase ou em banco de terceiros. Não é migração.', 'BEGIN;']
    dictionary=['# Dicionário dos models locais','', 'Nove entidades originais e três extensões de autenticação/preferência.','']
    for table in Base.metadata.sorted_tables:
        ddl.append(str(CreateTable(table).compile(dialect=dialect)).strip()+';')
        for index in sorted(table.indexes,key=lambda i:i.name):
            ddl.append(str(CreateIndex(index).compile(dialect=dialect))+';')
        dictionary += ['## '+table.name,'','| Campo | Tipo PostgreSQL | Permite nulo | Chave |','|---|---|---|---|']
        for c in table.columns:
            key='PK' if c.primary_key else ''
            if c.unique:key+=' UQ'
            for fk in c.foreign_keys:key+=' FK → '+fk.target_fullname
            dictionary.append(f'| {c.name} | {c.type.compile(dialect=dialect)} | {"sim" if c.nullable else "não"} | {key.strip()} |')
        dictionary.append('')
    ddl.append('COMMIT;')
    (ROOT/'database/schema_postgresql_local.sql').write_text('\n\n'.join(ddl)+'\n')
    (ROOT/'docs/DICIONARIO_BANCO.md').write_text('\n'.join(dictionary))
    canonical=json.loads((ROOT/'docs/modelo_canonico_original.json').read_text())
    checks=[]
    for table in canonical['tables']:
        expected={f['name'] for f in table['fields']}
        actual=set(Base.metadata.tables[table['name']].columns.keys())
        assert expected==actual,table['name']
        checks.append({'tabela':table['name'],'colunas_compativeis':True,'total_colunas':len(actual)})
    assert {c[0] for c in CATEGORIAS}==set(canonical['domains']['categoria_codigo'])
    assert {c[0] for c in STATUS}==set(canonical['domains']['status_codigo'])
    (ROOT/'evidencias/compatibilidade_modelo.json').write_text(json.dumps({'resultado':'OK','criterio':'nomes físicos e códigos de domínio; não é teste de migração','tabelas':checks,'novas_tabelas':['credencial_local','sessao_local','preferencia_local']},ensure_ascii=False,indent=2))
    print(f'{len(routes)} combinações de rota e método; nove tabelas autorais conferidas.')


if __name__=='__main__':main()
