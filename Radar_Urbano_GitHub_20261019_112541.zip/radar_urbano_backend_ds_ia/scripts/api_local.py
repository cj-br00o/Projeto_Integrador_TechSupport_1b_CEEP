"""Inicia/para somente o Uvicorn deste projeto usando PID e identidade verificados."""
import argparse
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import httpx

ROOT = Path(__file__).resolve().parents[1]
STATE = ROOT / 'instance'
PIDFILE = STATE / 'uvicorn.pid'


def running():
    if not PIDFILE.exists():
        return None
    pid = int(PIDFILE.read_text())
    proc = Path('/proc') / str(pid)
    try:
        command = (proc/'cmdline').read_bytes().split(b'\0')
        cwd = (proc/'cwd').resolve()
        if cwd == ROOT and b'uvicorn' in command and b'main:app' in command:
            return pid
    except (FileNotFoundError, ProcessLookupError):
        pass
    return None


def stop():
    pid = running()
    if pid:
        os.kill(pid, signal.SIGTERM)
        for _ in range(100):
            if not running():
                print('API deste projeto encerrada. Dados preservados.')
                return
            time.sleep(.1)
        raise RuntimeError('Processo não encerrou; verifique instance/uvicorn.log.')
    print('API deste projeto já está parada.')


def start():
    if running():
        print('API já está em execução em http://127.0.0.1:8000/docs')
        return
    STATE.mkdir(exist_ok=True)
    with (STATE/'uvicorn.log').open('a') as log:
        process = subprocess.Popen([sys.executable, '-m', 'uvicorn', 'main:app', '--host', '127.0.0.1', '--port', '8000'], cwd=ROOT, stdout=log, stderr=log, start_new_session=True)
    PIDFILE.write_text(str(process.pid))
    for _ in range(100):
        if process.poll() is not None:
            raise RuntimeError('API não iniciou. Veja instance/uvicorn.log; confira se a porta está ocupada.')
        try:
            if httpx.get('http://127.0.0.1:8000/api/v1/saude', timeout=1).status_code == 200:
                print('API em execução: http://127.0.0.1:8000/docs')
                return
        except httpx.TransportError:
            pass
        time.sleep(.1)
    process.terminate()
    raise RuntimeError('API não ficou saudável; confira o banco local.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('acao', choices=['iniciar', 'parar', 'reiniciar', 'status'])
    action = parser.parse_args().acao
    if action in ('parar', 'reiniciar'):
        stop()
    if action in ('iniciar', 'reiniciar'):
        start()
    if action == 'status':
        print('API em execução' if running() else 'API parada')
