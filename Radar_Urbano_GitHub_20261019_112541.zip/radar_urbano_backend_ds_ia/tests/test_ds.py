import io
from datetime import timedelta
import pytest
from PIL import Image
from sqlalchemy import select, func
from sqlalchemy.exc import IntegrityError
from config import validar_banco_local
from models import Credencial, Sessao, Ocorrencia, HistoricoStatus
from gerenciar import inicializar
from security import now
from conftest import login

BASE = '/api/v1'


def test_docs_openapi_and_model_schemas(client):
    assert client.get('/docs').status_code == 200
    contract = client.get('/openapi.json').json()
    assert 'OcorrenciaCreate' in contract['components']['schemas']
    assert '/api/v1/categorias' in contract['paths']
    assert len(contract['paths']) >= 25
    assert client.get(BASE+'/saude').json()['dados']['banco'] == 'sqlite'


def test_pk_then_fk_and_readable_category(client, admin, user, app):
    category = client.post(BASE+'/categorias', headers=admin, json={'codigo': 'TESTE_LOCAL', 'nome': 'Categoria local de teste'})
    assert category.status_code == 201
    ident = category.json()['dados']['id_categoria']
    assert ident > 0
    assert any(r['id_categoria'] == ident for r in client.get(BASE+'/categorias').json()['dados'])
    payload = {'id_categoria': ident, 'descricao': 'Ocorrência com categoria relacionada.', 'latitude': -23.4, 'longitude': -51.9}
    response = client.post(BASE+'/ocorrencias', headers=user, json=payload)
    assert response.status_code == 201
    assert response.json()['dados']['categoria'] == 'Categoria local de teste'
    assert client.get(BASE+'/ocorrencias', headers=user).json()['dados'][0]['categoria'] == 'Categoria local de teste'
    payload['id_categoria'] = 999999
    assert client.post(BASE+'/ocorrencias', headers=user, json=payload).status_code == 404
    with app.state.session_factory() as db:
        assert db.scalar(select(func.count()).select_from(Ocorrencia)) == 1
        assert db.scalar(select(func.count()).select_from(HistoricoStatus)) == 1


def test_registration_permissions_and_no_password_leak(client, user, app):
    payload = {'nome': 'Teste', 'email': 'outro@example.test', 'senha': 'SenhaTeste123!', 'perfil': 'ADMINISTRADOR'}
    response = client.post(BASE+'/auth/cadastro', json=payload)
    assert response.status_code == 422
    assert 'SenhaTeste123!' not in response.text
    assert client.get(BASE+'/perfil', headers=user).json()['dados']['perfil'] == 'CIDADAO'
    assert client.get(BASE+'/perfil').status_code == 401
    assert client.get(BASE+'/usuarios', headers=user).status_code == 403
    assert client.post(BASE+'/categorias', headers=user, json={'codigo': 'ABC', 'nome': 'Teste'}).status_code == 403
    with app.state.session_factory() as db:
        assert db.scalar(select(Credencial)).senha_hash != 'SenhaTeste123!'


def test_duplicate_and_inactive_catalog(client, admin, user):
    payload = {'codigo': 'NOVO', 'nome': 'Nova categoria'}
    result = client.post(BASE+'/categorias', headers=admin, json=payload).json()['dados']
    assert client.post(BASE+'/categorias', headers=admin, json=payload).status_code == 409
    assert client.patch(f'{BASE}/categorias/{result["id_categoria"]}', headers=admin, json={'ativo': False}).status_code == 200
    assert client.post(BASE+'/ocorrencias', headers=user, json={'id_categoria': result['id_categoria'], 'descricao': 'Descrição de categoria inativa.', 'latitude': 0, 'longitude': 0}).status_code == 409


@pytest.mark.parametrize('key,value', [('latitude', 91), ('longitude', -181), ('latitude', True), ('descricao', 'curta'), ('id_categoria', True), ('id_categoria', 0), ('id_usuario', 1), ('prioridade', 'CRITICA')])
def test_invalid_occurrence(client, user, key, value):
    payload = {'id_categoria': 1, 'descricao': 'Buraco na pista em teste local.', 'latitude': -23.4, 'longitude': -51.9}
    payload[key] = value
    assert client.post(BASE+'/ocorrencias', headers=user, json=payload).status_code == 422


def test_ownership_filters_and_profile(client, user, occurrence):
    ident = occurrence['id_ocorrencia']
    other = login(client, 'outra@example.test')
    assert client.get(f'{BASE}/ocorrencias/{ident}', headers=other).status_code == 404
    assert client.get(f'{BASE}/ocorrencias/{ident}/historico', headers=other).status_code == 404
    assert client.get(BASE+'/ocorrencias?escopo=todas', headers=other).json()['paginacao']['total'] == 0
    assert client.get(BASE+'/ocorrencias?pagina=0', headers=user).status_code == 422
    assert client.patch(BASE+'/perfil', headers=user, json={'nome': 'Nome corrigido'}).json()['dados']['nome'] == 'Nome corrigido'
    assert client.patch(BASE+'/perfil', headers=user, json={'perfil': 'ADMINISTRADOR'}).status_code == 422
    assert client.patch(BASE+'/perfil/preferencias', headers=user, json={'alto_contraste': True}).json()['dados']['alto_contraste'] is True
    assert client.patch(BASE+'/perfil/preferencias', headers=user, json={'notificacoes': 'false'}).status_code == 422


def test_status_team_and_service(client, admin, user, occurrence):
    ident = occurrence['id_ocorrencia']
    path = f'{BASE}/ocorrencias/{ident}/status'
    assert client.patch(path, headers=user, json={'codigo': 'EM_ANALISE'}).status_code == 403
    assert client.patch(path, headers=admin, json={'codigo': 'RESOLVIDA'}).status_code == 409
    assert client.patch(path, headers=admin, json={'codigo': 'EM_ANALISE'}).status_code == 200
    assert client.patch(f'{BASE}/ocorrencias/{ident}', headers=user, json={'descricao': 'Alteração fora do prazo permitido.'}).status_code == 409
    team = client.post(BASE+'/equipes', headers=admin, json={'nome': 'Equipe Teste', 'especialidade': 'Manutenção'}).json()['dados']['id_equipe']
    assert client.post(f'{BASE}/ocorrencias/{ident}/atendimentos', headers=admin, json={'id_equipe': 99999}).status_code == 404
    service = client.post(f'{BASE}/ocorrencias/{ident}/atendimentos', headers=admin, json={'id_equipe': team}).json()['dados']['id_atendimento']
    assert client.post(f'{BASE}/ocorrencias/{ident}/atendimentos', headers=admin, json={'id_equipe': team}).status_code == 409
    for code in ('ENCAMINHADA', 'EM_ATENDIMENTO'):
        assert client.patch(path, headers=admin, json={'codigo': code}).status_code == 200
    assert client.patch(path, headers=admin, json={'codigo': 'RESOLVIDA'}).status_code == 409
    assert client.patch(f'{BASE}/atendimentos/{service}/concluir', headers=admin, json={}).status_code == 200
    assert client.patch(path, headers=admin, json={'codigo': 'RESOLVIDA'}).status_code == 200
    assert len(client.get(f'{BASE}/ocorrencias/{ident}/historico', headers=user).json()['dados']) == 5
    assert client.get(BASE+'/mapa').json()['features'] == []


def test_private_photos_and_map(client, user, occurrence):
    ident = occurrence['id_ocorrencia']
    stream = io.BytesIO()
    Image.new('RGB', (30, 30), 'green').save(stream, 'PNG')
    response = client.post(f'{BASE}/ocorrencias/{ident}/fotos', headers=user, files={'arquivo': ('../../foto.png', stream.getvalue(), 'image/png')})
    assert response.status_code == 201
    url = response.json()['dados']['url_arquivo']
    assert client.get(url, headers=user).headers['content-type'] == 'image/jpeg'
    assert client.get(url).status_code == 401
    other = login(client, 'foto.outro@example.test')
    assert client.get(url, headers=other).status_code == 404
    assert client.post(f'{BASE}/ocorrencias/{ident}/fotos', headers=user, files={'arquivo': ('fake.png', b'fake')}).status_code == 422
    point = client.get(BASE+'/mapa').json()['features'][0]
    assert 'descricao' not in point['properties'] and 'id_usuario' not in point['properties']
    assert client.get(BASE+'/mapa?bbox=erro').status_code == 422


def test_logout_expiry_and_password_revocation(client, user, app):
    assert client.post(BASE+'/auth/logout', headers=user).status_code == 204
    assert client.get(BASE+'/perfil', headers=user).status_code == 401
    headers = login(client)
    with app.state.session_factory() as db:
        session = db.scalar(select(Sessao))
        session.expira_em = now()-timedelta(minutes=1)
        db.commit()
    assert client.get(BASE+'/perfil', headers=headers).status_code == 401
    headers = login(client)
    assert client.put(BASE+'/perfil/senha', headers=headers, json={'senha_atual': 'SenhaTeste123!', 'nova_senha': 'NovaSenhaTeste123!'}).status_code == 200
    assert client.get(BASE+'/perfil', headers=headers).status_code == 401


def test_fk_seed_and_cors(client, app):
    inicializar(app.state.engine)
    inicializar(app.state.engine)
    with app.state.session_factory() as db:
        db.add(Credencial(id_usuario=999999, senha_hash='x'))
        with pytest.raises(IntegrityError):
            db.commit()
        db.rollback()
    assert client.get(BASE+'/categorias', headers={'Origin': 'http://localhost:5173'}).headers.get('access-control-allow-origin') == 'http://localhost:5173'
    assert 'access-control-allow-origin' not in client.get(BASE+'/categorias', headers={'Origin': 'https://outro.example'}).headers


@pytest.mark.parametrize('url', ['postgresql://a:b@remote.example/db', 'postgresql://a:b@localhost/db?host=remote.example', 'mysql://localhost/db'])
def test_remote_bank_blocked(url):
    with pytest.raises(ValueError):
        validar_banco_local(url)


def test_rate_limit(client, app):
    app.state.settings.auth_limit = 1
    body = {'email': 'naoexiste@example.test', 'senha': 'invalida'}
    assert client.post(BASE+'/auth/login', json=body).status_code == 401
    assert client.post(BASE+'/auth/login', json=body).status_code == 429


def test_blank_names_and_uniform_unknown_route(client, admin):
    assert client.post(BASE+'/categorias', headers=admin, json={'codigo':'VAZIA','nome':'   '}).status_code == 422
    assert client.post(BASE+'/equipes', headers=admin, json={'nome':'   ','especialidade':'Teste'}).status_code == 422
    response=client.get(BASE+'/nao-existe')
    assert response.status_code == 404
    assert 'erro' in response.json()
