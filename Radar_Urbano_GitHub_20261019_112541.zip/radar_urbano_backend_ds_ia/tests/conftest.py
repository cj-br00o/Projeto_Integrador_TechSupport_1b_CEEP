from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from config import Settings, ROOT
from main import create_app
from gerenciar import inicializar
from models import Usuario, Credencial
from security import password_hash


@pytest.fixture
def app(tmp_path):
    settings = Settings(database_url='sqlite:///' + str(tmp_path / 'test.db'), upload_dir=tmp_path/'uploads', auth_limit=500)
    app = create_app(settings)
    inicializar(app.state.engine)
    with app.state.session_factory() as db:
        user = Usuario(nome='Gestor de teste', email='gestor@example.test', perfil='ADMINISTRADOR')
        db.add(user)
        db.flush()
        db.add(Credencial(id_usuario=user.id_usuario, senha_hash=password_hash('SenhaTeste123!')))
        db.commit()
    yield app
    app.state.engine.dispose()


@pytest.fixture
def client(app):
    with TestClient(app) as client:
        yield client


def login(client, email='cidadao@example.test'):
    client.post('/api/v1/auth/cadastro', json={'nome': 'Cidadão de teste', 'email': email, 'senha': 'SenhaTeste123!'})
    response = client.post('/api/v1/auth/login', json={'email': email, 'senha': 'SenhaTeste123!'})
    assert response.status_code == 200, response.text
    return {'Authorization': 'Bearer ' + response.json()['dados']['access_token']}


@pytest.fixture
def user(client):
    return login(client)


@pytest.fixture
def admin(client):
    response = client.post('/api/v1/auth/login', json={'email': 'gestor@example.test', 'senha': 'SenhaTeste123!'})
    assert response.status_code == 200, response.text
    return {'Authorization': 'Bearer ' + response.json()['dados']['access_token']}


@pytest.fixture
def occurrence(client, user):
    category = client.get('/api/v1/categorias').json()['dados'][0]['id_categoria']
    response = client.post('/api/v1/ocorrencias', headers=user, json={'id_categoria': category, 'descricao': 'Lâmpada apagada na via pública.', 'latitude': -23.4205, 'longitude': -51.9333})
    assert response.status_code == 201, response.text
    return response.json()['dados']
