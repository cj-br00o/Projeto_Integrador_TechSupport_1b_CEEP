import test from 'node:test';
import assert from 'node:assert/strict';
import {parseCoordinates, panelCounts, formatDate, validatePhotos} from '../../frontend/js/domain.js';

test('coordenadas rejeitam ausência, infinito e limites inválidos', () => {
  for (const pair of [['', '0'], ['91', '0'], ['0', '-181'], ['Infinity', '1'], ['texto', '2']]) {
    assert.throws(() => parseCoordinates(...pair));
  }
  assert.deepEqual(parseCoordinates('-23,42', '-51.93'), {latitude: -23.42, longitude: -51.93});
  assert.deepEqual(parseCoordinates('0', '0'), {latitude: 0, longitude: 0});
});

test('contagens pertencem ao cidadão e preservam zeros reais', () => {
  assert.deepEqual(panelCounts({total: 8, por_status: {RECEBIDA: 2, EM_ATENDIMENTO: 3, RESOLVIDA: 3}}),
    {total: 8, abertas: 5, emAtendimento: 3, resolvidas: 3});
  assert.equal(panelCounts({total: 0, por_status: {}}).total, 0);
});

test('datas são exibidas no fuso de São Paulo', () => {
  assert.match(formatDate('2026-09-01T01:00:00Z'), /31.*ago.*2026/);
  assert.equal(formatDate('invalida'), 'Data não disponível');
});

test('fotos respeitam formatos, tamanho e quantidade incluindo as já salvas', () => {
  validatePhotos([{type: 'image/png', size: 1024}]);
  assert.throws(() => validatePhotos([{type: 'text/html', size: 2}]));
  assert.throws(() => validatePhotos([{type: 'image/png', size: 7 * 1024 * 1024}]));
  assert.throws(() => validatePhotos([{type: 'image/png', size: 2}], 5));
});
