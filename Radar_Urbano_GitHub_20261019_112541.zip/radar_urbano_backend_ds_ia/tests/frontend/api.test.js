import test, {beforeEach} from 'node:test';
import assert from 'node:assert/strict';

const saved = new Map();
const events = [];
globalThis.window = {
  sessionStorage: {setItem: (k,v) => saved.set(k,v), getItem: k => saved.get(k), removeItem: k => saved.delete(k)},
  dispatchEvent: event => events.push(event.type)
};
const {api, setSession, restoreSession, hasSession, allPages, login, logout, uploadPhoto} = await import('../../frontend/js/api.js');

beforeEach(() => { setSession(null); events.length = 0; });

test('login usa rota real e mantém token somente no armazenamento da aba', async () => {
  globalThis.fetch = async (url, options) => {
    assert.equal(url, '/api/v1/auth/login');
    assert.equal(options.headers.has('Authorization'), false);
    assert.deepEqual(JSON.parse(options.body), {email: 'teste@example.test', senha: 'segredo efêmero de teste'});
    return Response.json({dados: {access_token: 'token-efemero', usuario: {nome: 'Pessoa fictícia'}}});
  };
  assert.equal((await login('teste@example.test', 'segredo efêmero de teste')).nome, 'Pessoa fictícia');
  assert.equal(hasSession(), true);
  assert.equal(restoreSession(), true);
});

test('sessão expirada apaga o token e emite evento para a interface', async () => {
  setSession('efemero');
  globalThis.fetch = async () => Response.json({erro: {mensagem: 'Sessão inválida ou expirada.'}}, {status: 401});
  await assert.rejects(api('/perfil'), error => error.status === 401);
  assert.equal(hasSession(), false);
  assert.deepEqual(events, ['radar:session-expired']);
});

test('erro de rede não é transformado em lista vazia ou sucesso', async () => {
  globalThis.fetch = async () => { throw new TypeError('network'); };
  await assert.rejects(api('/ocorrencias'), /Não foi possível conectar/);
});

test('catálogo percorre páginas usando os totais devolvidos pelo backend', async () => {
  globalThis.fetch = async url => Response.json({dados: [url.includes('pagina=1') ? {id: 1} : {id: 2}], paginacao: {total: 2}});
  assert.deepEqual(await allPages('/categorias'), [{id: 1}, {id: 2}]);
});

test('logout revoga a sessão no backend antes de removê-la da aba', async () => {
  setSession('efemero');
  globalThis.fetch = async (url, options) => {
    assert.equal(url, '/api/v1/auth/logout');
    assert.equal(options.headers.get('Authorization'), 'Bearer efemero');
    return new Response(null, {status: 204});
  };
  await logout();
  assert.equal(hasSession(), false);
});

test('upload usa FormData sem fixar boundary e impede tipos inválidos', async () => {
  globalThis.fetch = async (url, options) => {
    assert.equal(url, '/api/v1/ocorrencias/7/fotos');
    assert.ok(options.body instanceof FormData);
    assert.equal(options.headers.has('Content-Type'), false);
    return Response.json({dados: {id_foto: 1}});
  };
  await uploadPhoto(7, new File(['teste'], 'foto.png', {type: 'image/png'}));
  await assert.rejects(uploadPhoto(7, new File(['teste'], 'arquivo.html', {type: 'text/html'})), /Selecione uma foto/);
});
