def test_cliente_javascript_servido_sem_expor_arquivos_privados(client):
    response = client.get('/assets/js/api.js')
    assert response.status_code == 200
    assert 'javascript' in response.headers['content-type']
    assert 'class ApiError' in response.text
    for path in ('/assets/.env', '/assets/instance/pgdata/PG_VERSION', '/assets/%2e%2e/.env', '/.env'):
        assert client.get(path).status_code == 404


def test_docs_e_api_continuam_acessiveis_com_estaticos(client):
    assert client.get('/docs').status_code == 200
    assert client.get('/api/v1/categorias').status_code == 200
    assert client.get('/assets/js/store.js').status_code == 200


def test_entrada_html_e_protecao_de_conteudo(client):
    response = client.get('/')
    assert response.status_code == 200
    assert response.headers['content-type'].startswith('text/html')
    assert '<html lang="pt-BR">' in response.text
    assert '/assets/js/app.js' in response.text
    assert "script-src 'self'" in response.headers['content-security-policy']
    assert response.headers['x-frame-options'] == 'DENY'
    assert client.get('/assets/styles.css').status_code == 200
    assert client.get('/assets/vendor/leaflet.js').status_code == 200
