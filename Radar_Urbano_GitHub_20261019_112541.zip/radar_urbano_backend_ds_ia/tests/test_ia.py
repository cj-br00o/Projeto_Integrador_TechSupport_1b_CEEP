from datetime import timedelta
import pandas as pd
import pytest
from fastapi.testclient import TestClient
from analise import CSV_PADRAO, ler_dados, resumo, por_categoria, por_data
from config import Settings
from main import create_app


def test_source_counts_and_reconciliation():
    df = ler_dados()
    result = resumo(df)
    assert result['linhas_csv'] == result['total_ocorrencias'] == 20
    assert result['tempo_analise_soma_min'] == 20
    assert result['tempo_analise_media_min'] == result['tempo_analise_mediana_min'] == 1
    assert result['ocorrencias_urgentes'] == 5 and result['percentual_urgentes'] == 25
    assert result['possiveis_duplicidades'] == 1
    for grouped in (por_categoria(df), por_data(df)):
        assert sum(r['total_ocorrencias'] for r in grouped) == 20
        assert sum(r['tempo_analise_soma_min'] for r in grouped) == 20
        assert sum(r['urgentes'] for r in grouped) == 5


def test_nontrivial_mean_median_and_local_dates(tmp_path):
    df = pd.read_csv(CSV_PADRAO).head(3)
    df['criado_em'] = ['2026-09-01T02:59:00Z', '2026-09-01T03:00:00Z', '2026-09-01T04:00:00Z']
    starts = pd.to_datetime(df['criado_em'], utc=True)
    df['analisado_em'] = [(s+timedelta(minutes=m)).isoformat() for s,m in zip(starts,[1,2,9])]
    path = tmp_path/'source.csv'
    df.to_csv(path,index=False)
    data = ler_dados(path)
    r = resumo(data)
    assert r['tempo_analise_media_min'] == 4
    assert r['tempo_analise_mediana_min'] == 2
    assert r['tempo_analise_soma_min'] == 12
    assert [v['data'] for v in por_data(data)] == ['2026-08-31','2026-09-01']


@pytest.mark.parametrize('kind', ['empty','missing_column','missing_required','duplicate_line','duplicate_id','bad_date','no_timezone','infinite','invalid_priority','invalid_category','analysis_before','self_duplicate','unknown_duplicate','orphan_analysis'])
def test_bad_sources_stop_analysis(tmp_path, kind):
    df = pd.read_csv(CSV_PADRAO)
    if kind=='empty': df=df.iloc[0:0]
    elif kind=='missing_column': df=df.drop(columns=['protocolo'])
    elif kind=='missing_required': df.loc[0,'descricao']=None
    elif kind=='duplicate_line': df=pd.concat([df,df.iloc[[0]]],ignore_index=True)
    elif kind=='duplicate_id': df.loc[1,'id_ocorrencia']=df.loc[0,'id_ocorrencia']
    elif kind=='bad_date': df.loc[0,'criado_em']='data errada'
    elif kind=='no_timezone': df.loc[0,'criado_em']='2026-09-01T08:00:00'
    elif kind=='infinite': df.loc[0,'latitude']=float('inf')
    elif kind=='invalid_priority': df.loc[0,'prioridade']='URGENTISSIMA'
    elif kind=='invalid_category': df.loc[0,'categoria_codigo']='INEXISTENTE'
    elif kind=='analysis_before': df.loc[0,'analisado_em']='2026-01-01T00:00:00Z'
    elif kind=='self_duplicate': df.loc[0,'id_ocorrencia_duplicada']=1
    elif kind=='unknown_duplicate': df.loc[0,'id_ocorrencia_duplicada']=99999
    elif kind=='orphan_analysis': df.loc[0,'analisado_em']=None
    path=tmp_path/'invalid.csv';df.to_csv(path,index=False)
    with pytest.raises(ValueError):ler_dados(path)


def test_optional_absences_are_not_fabricated(tmp_path):
    df=pd.read_csv(CSV_PADRAO)
    columns=['analisado_em','resumo','valido','id_categoria_sugerida','prioridade_sugerida','id_ocorrencia_duplicada']
    for c in columns:df[c]=None
    df['categoria_codigo']=None
    path=tmp_path/'optional.csv';df.to_csv(path,index=False)
    data=ler_dados(path);result=resumo(data)
    assert result['sem_analise']==20
    assert result['tempo_analise_media_min'] is None
    assert result['tempo_analise_mediana_min'] is None
    assert result['tempo_analise_soma_min']==0
    assert por_categoria(data)[0]['categoria_codigo']=='SEM_CATEGORIA'


def test_ia_does_not_open_a_database(tmp_path):
    app=create_app(Settings(database_url='sqlite:///'+str(tmp_path/'not_created'/'db.sqlite')))
    def forbidden():raise AssertionError('IA tentou abrir sessão SQL')
    app.state.session_factory=forbidden
    with TestClient(app) as client:
        for path in ['resumo','categorias','datas','qualidade']:
            response=client.get('/api/v1/analise/'+path)
            assert response.status_code==200,response.text
            assert 'NaN' not in response.text and 'Infinity' not in response.text
    assert not (tmp_path/'not_created').exists()


def test_csv_missing_and_invalid_api(tmp_path):
    path=tmp_path/'missing.csv'
    with TestClient(create_app(Settings(csv_path=path))) as client:
        assert client.get('/api/v1/analise/resumo').status_code==503
        path.write_text('coluna\nvalor\n')
        assert client.get('/api/v1/analise/resumo').status_code==422
