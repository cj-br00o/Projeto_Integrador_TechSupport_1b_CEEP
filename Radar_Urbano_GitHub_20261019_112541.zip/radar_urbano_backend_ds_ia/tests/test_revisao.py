from analise import ler_dados, resumo


def test_paginacao_catalogos_historico(client, admin, occurrence, user):
    data = client.get('/api/v1/categorias?pagina=2&limite=3').json()
    assert len(data['dados']) == 3
    assert data['paginacao'] == {'pagina': 2, 'limite': 3, 'total': 8}
    path = f'/api/v1/ocorrencias/{occurrence["id_ocorrencia"]}/historico'
    assert client.get(path+'?pagina=2&limite=1', headers=user).json()['dados'] == []
    assert client.get(path+'?limite=101', headers=user).status_code == 422
    assert client.get('/api/v1/equipes?limite=0', headers=admin).status_code == 422


def test_fotos_nao_representam_historico_ou_total_real():
    source = ler_dados()
    data = resumo(source)
    assert data['ocorrencias_com_foto_referenciada'] == int(source.foto_url.notna().sum())
    assert data['referencias_foto_distintas'] == int(source.foto_url.nunique())
    assert data['total_fotos'] is None
    assert data['eventos_historico'] is None


def test_contrato_login_listagens(client):
    schemas = client.get('/openapi.json').json()['components']['schemas']
    assert 'LoginResponse' in schemas
    assert 'ListaOcorrencias' in schemas
