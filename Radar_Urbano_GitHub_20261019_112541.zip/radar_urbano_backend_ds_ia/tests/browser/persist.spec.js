import {test,expect} from '@playwright/test';

test('dados criados pela interface continuam disponíveis após reiniciar a API',async({page})=>{
  const phase=process.env.RADAR_TEST_PHASE;
  test.skip(process.env.RADAR_TEST_ISOLATED!=='1'||!['antes','depois'].includes(phase),'Etapa específica do roteiro Python de reinício.');
  const email=process.env.RADAR_PERSIST_EMAIL,secret=process.env.RADAR_PERSIST_PASSWORD;
  if(phase==='antes'){
    await page.goto('/#/cadastro');
    await page.getByLabel('Nome completo').fill('Pessoa de Persistência');
    await page.getByLabel('E-mail',{exact:true}).fill(email);
    await page.getByLabel('Senha',{exact:true}).fill(secret);
    await page.getByLabel('Confirmar senha',{exact:true}).fill(secret);
    await page.getByRole('button',{name:'Criar conta',exact:true}).click();
    await expect(page).toHaveURL(/#\/entrar$/);
  }else await page.goto('/#/entrar');
  await page.getByLabel('E-mail',{exact:true}).fill(email);
  await page.getByLabel('Senha',{exact:true}).fill(secret);
  await page.getByRole('button',{name:'Entrar',exact:true}).click();
  await expect(page.getByRole('heading',{name:'Olá, Pessoa'})).toBeVisible();
  if(phase==='antes'){
    await page.goto('/#/nova');
    await page.getByLabel('Categoria do problema').selectOption({label:'Infraestrutura'});
    await page.getByLabel('Descrição do problema').fill('Ocorrência fictícia para comprovar persistência após reinício da API.');
    await page.getByLabel('Latitude',{exact:true}).fill('-23.42');
    await page.getByLabel('Longitude',{exact:true}).fill('-51.93');
    await page.getByLabel('Selecionar fotos do problema').setInputFiles(process.env.RADAR_TEST_IMAGE);
    await page.getByRole('button',{name:'Enviar solicitação',exact:true}).click();
    await expect(page.getByAltText('Foto 1 enviada nesta solicitação')).toBeVisible();
  }else{
    await page.goto('/#/solicitacoes');
    await expect(page.locator('.request-card')).toHaveCount(1);
    await page.getByRole('link',{name:'Ver detalhes',exact:true}).click();
    await expect(page.locator('.detail-description')).toHaveText('Ocorrência fictícia para comprovar persistência após reinício da API.');
    await expect(page.locator('.timeline li')).toHaveCount(1);
    await expect(page.getByAltText('Foto 1 enviada nesta solicitação')).toBeVisible();
  }
});
