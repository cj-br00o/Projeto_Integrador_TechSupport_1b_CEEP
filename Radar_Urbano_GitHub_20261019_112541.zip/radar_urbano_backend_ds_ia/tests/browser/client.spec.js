// Exercita os módulos reais no Chrome isolado, antes da composição visual.
import {test, expect} from '@playwright/test';
import {randomBytes} from 'node:crypto';

test('cliente web persiste cadastro, login, ocorrência e perfil no PostgreSQL', async ({page}) => {
  test.skip(process.env.RADAR_TEST_ISOLATED !== '1', 'Execute pelo roteiro de banco PostgreSQL descartável.');
  const browserErrors = [];
  page.on('pageerror', error => browserErrors.push(error.message));
  await page.goto('/');
  const account = {email: `browser-${randomBytes(8).toString('hex')}@example.test`, password: randomBytes(24).toString('base64url')};
  const created = await page.evaluate(async ({email, password}) => {
    const store = await import('/assets/js/store.js');
    const {api} = await import('/assets/js/api.js');
    const registered = await store.register({nome: 'Pessoa fictícia de integração', email, senha: password});
    const user = await store.login(email, password);
    const {categories} = await store.catalogs();
    const result = await store.createOccurrence({id_categoria: categories[0].id_categoria,
      descricao: 'Relato fictício para validar o cliente web com PostgreSQL local.', latitude: '-23.42', longitude: '-51.93'});
    const profile = await store.saveProfile('Perfil fictício atualizado');
    await store.savePreferences({alto_contraste: true, tamanho_texto: 'GRANDE'});
    const details = await store.occurrenceDetails(result.occurrence.id_ocorrencia);
    const list = await api('/ocorrencias');
    return {registered: registered.id_usuario, loggedIn: user.id_usuario, profile: profile.nome,
      id: result.occurrence.id_ocorrencia, category: details.occurrence.categoria, total: list.paginacao.total,
      history: details.history.length, failures: result.failures.length};
  }, account);
  expect(created.registered).toBe(created.loggedIn);
  expect(created.profile).toBe('Perfil fictício atualizado');
  expect(created.category).toBeTruthy();
  expect(created.total).toBe(1);
  expect(created.history).toBe(1);
  expect(created.failures).toBe(0);
  await page.reload();
  const restored = await page.evaluate(async id => {
    const store = await import('/assets/js/store.js');
    const restored = await store.initializeSession();
    const details = await store.occurrenceDetails(id);
    return {restored, name: store.state.user.nome, contrast: store.state.preferences.alto_contraste, id: details.occurrence.id_ocorrencia};
  }, created.id);
  expect(restored).toEqual({restored: true, name: 'Perfil fictício atualizado', contrast: true, id: created.id});
  const revoked = await page.evaluate(async () => {
    const store = await import('/assets/js/store.js');
    const {api, hasSession} = await import('/assets/js/api.js');
    await store.logout();
    let status;
    try { await api('/perfil'); } catch (error) { status = error.status; }
    return {hasSession: hasSession(), status};
  });
  expect(revoked).toEqual({hasSession: false, status: 401});
  expect(browserErrors).toEqual([]);
});
