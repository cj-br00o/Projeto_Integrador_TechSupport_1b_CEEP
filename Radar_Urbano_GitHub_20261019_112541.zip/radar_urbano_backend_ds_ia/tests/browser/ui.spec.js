import {test, expect} from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import {randomBytes} from 'node:crypto';
import {join} from 'node:path';
import {writeFile} from 'node:fs/promises';

test.setTimeout(120_000);
test.beforeEach(async () => {
  test.skip(process.env.RADAR_TEST_ISOLATED !== '1', 'Execute em banco PostgreSQL descartável pelo roteiro Python.');
});
const password=()=>randomBytes(24).toString('base64url');
const account=()=>({email:`ui-${randomBytes(6).toString('hex')}@example.test`,password:password()});
async function login(page,email,secret){
  await page.goto('/#/entrar');
  await page.getByLabel('E-mail',{exact:true}).fill(email);
  await page.getByLabel('Senha',{exact:true}).fill(secret);
  await page.getByRole('button',{name:'Entrar',exact:true}).click();
}
async function register(page,person){
  await page.goto('/#/cadastro');
  await page.getByLabel('Nome completo').fill('Ana de Teste');
  await page.getByLabel('E-mail',{exact:true}).fill(person.email);
  await page.getByLabel('Senha',{exact:true}).fill(person.password);
  await page.getByLabel('Confirmar senha',{exact:true}).fill(person.password);
  await page.getByRole('button',{name:'Criar conta',exact:true}).click();
  await expect(page).toHaveURL(/#\/entrar$/);
}
async function screenshot(page,name){
  await expect(page.locator('#conteudo')).not.toHaveAttribute('aria-busy','true');
  await expect(page.locator('#toast')).toBeHidden({timeout:10000});
  if(await page.locator('.leaflet-container').count()){
    try{await page.locator('.leaflet-tile-loaded').first().waitFor({state:'visible',timeout:5000});}catch{/* Captura mantém a mensagem de indisponibilidade quando não houver base de ruas. */}
  }
  if(process.env.RADAR_TEST_EVIDENCE)await page.screenshot({path:join(process.env.RADAR_TEST_EVIDENCE,name+'.png'),fullPage:true});
}
async function accessible(page,name){
  const result=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21aa']).analyze();
  if(process.env.RADAR_TEST_EVIDENCE)await writeFile(join(process.env.RADAR_TEST_EVIDENCE,`axe-${name}.json`),JSON.stringify({url:page.url().split('#')[1],violations:result.violations,passes:result.passes.length},null,2));
  expect(result.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.map(n=>n.target)}))).toEqual([]);
}

test('fluxo cidadão e gestão: cadastro, foto, solicitações, mapa, perfil e resolução',async({page,browser})=>{
  const errors=[];
  page.on('pageerror',error=>errors.push(error.message));
  const person=account();
  await page.goto('/#/entrada');
  await expect(page.getByRole('heading',{name:/Uma cidade melhor/})).toBeVisible();
  await accessible(page,'entrada-desktop');
  await screenshot(page,'entrada-desktop');
  await register(page,person);
  await login(page,person.email,person.password);
  await expect(page.getByRole('heading',{name:'Olá, Ana'})).toBeVisible();
  await accessible(page,'inicio-desktop');
  await screenshot(page,'inicio-vazio-desktop');
  await page.getByRole('link',{name:/Informar um problema/}).first().click();
  await page.getByLabel('Categoria do problema').selectOption({label:'Iluminação'});
  await page.getByLabel('Descrição do problema').fill('Lâmpada apagada na via. Relato fictício de teste de integração.');
  await page.getByLabel('Latitude',{exact:true}).fill('-23.4205');
  await page.getByLabel('Longitude',{exact:true}).fill('-51.9333');
  await page.getByLabel('Selecionar fotos do problema').setInputFiles(process.env.RADAR_TEST_IMAGE);
  await accessible(page,'nova-solicitacao');
  await page.getByRole('button',{name:'Enviar solicitação',exact:true}).click();
  await expect(page).toHaveURL(/#\/solicitacao\/\d+$/);
  await expect(page.getByRole('heading',{name:'Iluminação',exact:true})).toBeVisible();
  await expect(page.getByAltText('Foto 1 enviada nesta solicitação')).toBeVisible();
  const detailURL=page.url();
  const protocol=await page.locator('.detail-heading .eyebrow').innerText();
  await screenshot(page,'detalhes-cidadao');
  await page.getByRole('button',{name:'Editar relato',exact:true}).click();
  await page.getByLabel('Descrição',{exact:true}).fill('Lâmpada apagada na via, próximo ao cruzamento. Registro fictício atualizado.');
  await page.getByRole('button',{name:'Salvar relato',exact:true}).click();
  await expect(page.locator('.detail-description')).toContainText('Registro fictício atualizado.');
  await page.goto('/#/solicitacoes');
  await page.getByLabel('Buscar por protocolo ou assunto').fill(protocol.replace(/^Protocolo /i,''));
  await page.getByRole('button',{name:'Buscar',exact:true}).click();
  await expect(page.locator('.request-card')).toHaveCount(1);
  await accessible(page,'solicitacoes-desktop');
  await screenshot(page,'solicitacoes-desktop');
  await page.goto('/#/mapa');
  await expect(page.locator('.map-item').filter({hasText:'Iluminação'}).first()).toBeVisible();
  await page.getByLabel('Categoria',{exact:true}).selectOption({label:'Iluminação'});
  await page.locator('.map-item').first().click();
  await expect(page.locator('#map-selection')).toContainText('Coordenadas aproximadas');
  await accessible(page,'mapa-desktop');
  await screenshot(page,'mapa-desktop');
  await page.goto('/#/perfil');
  await page.getByRole('link',{name:'Editar dados'}).click();
  await page.getByLabel('Nome completo').fill('Ana Atualizada');
  await page.getByRole('button',{name:'Salvar alterações'}).click();
  await expect(page.getByRole('heading',{name:'Ana Atualizada'})).toBeVisible();
  await page.getByRole('button',{name:'Abrir opções de acessibilidade'}).click();
  await page.getByLabel('Alto contraste',{exact:true}).check();
  await page.getByLabel('Tamanho do texto').selectOption('GRANDE');
  await page.getByRole('button',{name:'Salvar preferências',exact:true}).click();
  await expect(page.locator('html')).toHaveClass(/high-contrast/);
  await page.reload();
  await expect(page.getByRole('heading',{name:'Ana Atualizada'})).toBeVisible();
  await expect(page.locator('html')).toHaveClass(/large-text/);
  await accessible(page,'perfil-alto-contraste');
  await page.getByRole('button',{name:'Abrir opções de acessibilidade'}).click();
  await page.getByLabel('Alto contraste',{exact:true}).uncheck();
  await page.getByLabel('Tamanho do texto').selectOption('PADRAO');
  await page.getByRole('button',{name:'Salvar preferências',exact:true}).click();
  await page.setViewportSize({width:390,height:844});
  await accessible(page,'perfil-mobile');
  await screenshot(page,'perfil-mobile');
  await page.goto('/#/inicio');
  await expect(page.getByRole('heading',{name:'Olá, Ana'})).toBeVisible();
  await screenshot(page,'inicio-mobile');
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBe(true);
  await page.goto('/#/solicitacoes');
  await screenshot(page,'solicitacoes-mobile');
  await page.goto('/#/mapa');
  await screenshot(page,'mapa-mobile');
  const adminContext=await browser.newContext({viewport:{width:1366,height:900},locale:'pt-BR'});
  const admin=await adminContext.newPage();
  await login(admin,'gestao.ui@example.test',process.env.RADAR_TEST_STAFF_PASSWORD);
  await expect(admin.getByRole('heading',{name:'Central de gestão'})).toBeVisible();
  await accessible(admin,'gestao-desktop');
  await screenshot(admin,'gestao-desktop');
  await admin.getByRole('link',{name:'Equipes',exact:true}).click();
  await admin.getByLabel('Nome',{exact:true}).fill('Equipe de teste de iluminação');
  await admin.getByLabel('Especialidade').fill('Iluminação pública');
  await admin.getByRole('button',{name:'Cadastrar equipe'}).click();
  await expect(admin.getByRole('cell',{name:'Equipe de teste de iluminação'})).toBeVisible();
  await admin.goto(detailURL);
  await admin.getByLabel('Próxima situação').selectOption('EM_ANALISE');
  await admin.getByRole('button',{name:'Atualizar status',exact:true}).click();
  await expect(admin.locator('.detail-heading .badge')).toHaveText('Em análise');
  await admin.getByLabel('Equipe responsável').selectOption({label:'Equipe de teste de iluminação'});
  await admin.getByRole('button',{name:'Atribuir equipe',exact:true}).click();
  await expect(admin.getByRole('button',{name:'Concluir atendimento',exact:true})).toBeVisible();
  for(const code of ['ENCAMINHADA','EM_ATENDIMENTO']){
    await admin.getByLabel('Próxima situação').selectOption(code);
    await admin.getByRole('button',{name:'Atualizar status',exact:true}).click();
    await expect(admin.locator('.detail-heading .badge')).toHaveText(code==='ENCAMINHADA'?'Encaminhada':'Em atendimento');
  }
  await admin.getByRole('button',{name:'Concluir atendimento',exact:true}).click();
  await expect(admin.locator('#management-controls')).toContainText('Não há atendimentos em aberto.');
  await admin.getByLabel('Próxima situação').selectOption('RESOLVIDA');
  await admin.getByRole('button',{name:'Atualizar status',exact:true}).click();
  await expect(admin.locator('.detail-heading .badge')).toHaveText('Concluída');
  await adminContext.close();
  await page.goto(detailURL);
  await expect(page.locator('.detail-heading .badge')).toHaveText('Concluída');
  await expect(page.locator('.timeline li')).toHaveCount(5);
  await page.goto('/#/perfil');
  await page.getByRole('button',{name:'Sair da conta',exact:true}).click();
  await expect(page).toHaveURL(/#\/entrada$/);
  await login(page,person.email,person.password);
  await expect(page.getByRole('heading',{name:'Olá, Ana'})).toBeVisible();
  await page.goto(detailURL);
  await expect(page.locator('.detail-heading .badge')).toHaveText('Concluída');
  expect(errors).toEqual([]);
});

test('teclado, preferências, segurança da conta e texto de relato sem execução de HTML',async({page})=>{
  const person=account();
  await page.goto('/#/entrada');
  await page.getByRole('link',{name:'Pular para o conteúdo'}).focus();
  await page.keyboard.press('Enter');
  await expect(page.locator('#conteudo')).toBeFocused();
  await expect(page).toHaveURL(/#\/entrada$/);
  await register(page,person);
  await login(page,person.email,person.password);
  await expect(page.getByRole('heading',{name:'Olá, Ana'})).toBeVisible();
  const xss='<img src=x onerror="window.__unsafe=true"> Relato fictício de segurança.';
  const occurrence=await page.evaluate(async descricao=>{const {api}=await import('/assets/js/api.js');return (await api('/ocorrencias',{method:'POST',body:{id_categoria:1,descricao,latitude:-23.42,longitude:-51.93}})).dados;},xss);
  await page.goto('/#/solicitacao/'+occurrence.id_ocorrencia);
  await expect(page.locator('.detail-description')).toHaveText(xss);
  expect(await page.evaluate(()=>window.__unsafe)).toBeUndefined();
  await page.goto('/#/perfil/notificacoes');
  await page.getByLabel('Receber avisos de atualizações quando disponíveis').uncheck();
  await page.getByRole('button',{name:'Salvar alterações'}).click();
  await page.reload();
  await expect(page.getByLabel('Receber avisos de atualizações quando disponíveis')).not.toBeChecked();
  await page.goto('/#/perfil/seguranca');
  const newPassword=password();
  await page.getByLabel('Senha atual',{exact:true}).fill(person.password);
  await page.getByLabel('Nova senha',{exact:true}).fill(newPassword);
  await page.getByLabel('Confirmar nova senha',{exact:true}).fill('confirmacao-incompativel');
  await page.getByRole('button',{name:'Salvar alterações'}).click();
  await expect(page.getByRole('alert')).toContainText('As novas senhas não coincidem');
  await page.getByLabel('Confirmar nova senha',{exact:true}).fill(newPassword);
  await page.getByRole('button',{name:'Salvar alterações'}).click();
  await expect(page).toHaveURL(/#\/entrar$/);
  await login(page,person.email,newPassword);
  await expect(page.getByRole('heading',{name:'Olá, Ana'})).toBeVisible();
  await page.setViewportSize({width:320,height:740});
  for(const path of ['/inicio','/nova','/perfil','/solicitacoes']){
    await page.goto('/#'+path);
    await expect(page.locator('#conteudo')).not.toHaveAttribute('aria-busy','true');
    expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBe(true);
  }
});

test('erros de login, cadastro duplicado, isolamento e mapa sem internet',async({page,browser})=>{
  const first=account();
  await register(page,first);
  await page.goto('/#/cadastro');
  await page.getByLabel('Nome completo').fill('Pessoa duplicada');
  await page.getByLabel('E-mail',{exact:true}).fill(first.email);
  await page.getByLabel('Senha',{exact:true}).fill(first.password);
  await page.getByLabel('Confirmar senha',{exact:true}).fill(first.password);
  await page.getByRole('button',{name:'Criar conta',exact:true}).click();
  await expect(page.getByRole('alert')).toContainText('Registro duplicado');
  await login(page,first.email,'senha-errada-efemera');
  await expect(page.getByRole('alert')).toContainText('E-mail ou senha inválidos');
  await page.getByLabel('Senha',{exact:true}).fill(first.password);
  await page.getByRole('button',{name:'Entrar',exact:true}).click();
  await expect(page.getByRole('heading',{name:'Olá, Ana'})).toBeVisible();
  const result=await page.evaluate(async()=>{const {api}=await import('/assets/js/api.js');const cats=await api('/categorias');return (await api('/ocorrencias',{method:'POST',body:{id_categoria:cats.dados[0].id_categoria,descricao:'Registro privado de teste, não deve ser acessado por outra pessoa.',latitude:-23.42,longitude:-51.93}})).dados;});
  const other=await browser.newContext();
  const second=await other.newPage();
  const next=account();await register(second,next);await login(second,next.email,next.password);
  await second.goto('/#/solicitacao/'+result.id_ocorrencia);
  await expect(second.getByRole('heading',{name:'Não foi possível abrir esta página'})).toBeVisible();
  await expect(second.locator('#conteudo')).not.toContainText(result.descricao);
  await other.close();
  await page.route('https://tile.openstreetmap.org/**',route=>route.abort());
  await page.goto('/#/mapa');
  await expect(page.locator('#map-network')).toContainText('base de ruas está indisponível');
  await expect(page.locator('.map-item').first()).toBeVisible();
});
