"""Cria ambiente do projeto sem alterar Python global, GitHub ou Supabase."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import venv


def main():
    root = Path(__file__).resolve().parent
    os.chdir(root)
    if not (3, 11) <= sys.version_info[:2] < (3, 14):
        raise SystemExit('Use Python 3.11, 3.12 ou 3.13 para os requisitos fixados desta entrega.')
    folder = root / '.venv'
    if not folder.exists():
        venv.EnvBuilder(with_pip=True).create(folder)
    python = folder / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    subprocess.run([str(python), '-m', 'pip', 'install', '-r', 'requirements-lock.txt'], check=True)
    if not (root / '.env').exists():
        shutil.copyfile(root / '.env.example', root / '.env')
    subprocess.run([str(python), 'gerenciar.py', 'init-db'], check=True)
    subprocess.run([str(python), 'analise.py'], check=True)
    print('Pronto. Linux: bash iniciar.sh; Windows: iniciar.bat. Documentação: http://127.0.0.1:8000/docs.')


if __name__ == '__main__':
    main()
