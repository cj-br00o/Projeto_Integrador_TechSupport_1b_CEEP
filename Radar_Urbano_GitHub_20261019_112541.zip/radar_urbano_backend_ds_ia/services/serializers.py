from datetime import datetime, timezone
from decimal import Decimal
from models import Ocorrencia


def serialize(row):
    result = {}
    for col in row.__table__.columns:
        value = getattr(row, col.name)
        if isinstance(value, datetime):
            value = (value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)).isoformat()
        if isinstance(value, Decimal):
            value = float(value)
        result[col.name] = value
    if isinstance(row, Ocorrencia):
        result.update(categoria=row.categoria.nome if row.categoria else None,
                      status=row.status.nome, status_codigo=row.status.codigo)
    return result
