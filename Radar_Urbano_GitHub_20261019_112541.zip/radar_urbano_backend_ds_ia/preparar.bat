@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python preparar.py
) else (
  py -3 preparar.py
)
if errorlevel 1 (
  echo Falha na preparacao. Leia a mensagem acima e o README.
  pause
  exit /b 1
)
pause
