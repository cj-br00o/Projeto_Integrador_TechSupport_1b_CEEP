import hashlib
import secrets
from datetime import datetime, timezone
from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session
from sqlalchemy import SmallInteger, BigInteger
from database import get_db
from models import Usuario, Sessao

STAFF = {'PREFEITURA', 'ADMINISTRADOR'}
bearer = HTTPBearer(auto_error=False)


def now():
    return datetime.now(timezone.utc)


def utc(value):
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


def digest(token):
    return hashlib.sha256(token.encode()).hexdigest()


def password_hash(password):
    salt = secrets.token_hex(16)
    value = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt), n=16384, r=8, p=1, dklen=32)
    return 'scrypt$16384$8$1$' + salt + '$' + value.hex()


def password_matches(password, hashed):
    try:
        scheme, n, r, p, salt, expected = hashed.split('$')
        if (scheme, n, r, p) != ('scrypt', '16384', '8', '1'):
            return False
        actual = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt), n=int(n), r=int(r), p=int(p), dklen=32)
        return secrets.compare_digest(actual.hex(), expected)
    except (ValueError, TypeError):
        return False


def current_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer), db: Session = Depends(get_db)):
    if not credentials or credentials.scheme.lower() != 'bearer' or len(credentials.credentials) > 200:
        raise HTTPException(401, 'Entre na sua conta.')
    session = db.get(Sessao, digest(credentials.credentials))
    if not session or utc(session.expira_em) <= now():
        raise HTTPException(401, 'Sessão inválida ou expirada.')
    user = db.get(Usuario, session.id_usuario)
    if not user or not user.ativo:
        raise HTTPException(401, 'Conta indisponível.')
    return user


def gestor(user: Usuario = Depends(current_user)):
    if user.perfil not in STAFF:
        raise HTTPException(403, 'Ação restrita à gestão municipal.')
    return user


def record(db, model, ident, *, lock=False):
    # Psycopg aplica o tipo SMALLINT ao parâmetro. Um ID inexistente grande
    # deve produzir 404 antes de o PostgreSQL tentar convertê-lo.
    column = next(iter(model.__table__.primary_key.columns))
    maximum = 32767 if isinstance(column.type, SmallInteger) else (2**63-1 if isinstance(column.type, BigInteger) else 2**31-1)
    if not isinstance(ident, int) or ident < 1 or ident > maximum:
        raise HTTPException(404, 'Registro não encontrado.')
    row = db.get(model, ident, with_for_update=lock)
    if row is None:
        raise HTTPException(404, 'Registro não encontrado.')
    return row


def access(row, user):
    if user.perfil not in STAFF and row.id_usuario != user.id_usuario:
        raise HTTPException(404, 'Registro não encontrado.')
    return row
