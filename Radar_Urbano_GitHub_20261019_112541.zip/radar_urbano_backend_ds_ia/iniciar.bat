@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Execute preparar.bat primeiro.
  pause
  exit /b 1
)
echo API em http://127.0.0.1:8000/docs -- Ctrl+C para encerrar.
".venv\Scripts\python.exe" -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload
if errorlevel 1 pause
