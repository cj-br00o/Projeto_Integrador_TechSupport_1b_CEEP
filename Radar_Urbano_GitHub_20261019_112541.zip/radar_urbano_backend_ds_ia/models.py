"""Nove entidades do Radar Urbano e extensões locais de autenticação.

Nomes do negócio preservados em relação ao Módulo 7.
"""

from __future__ import annotations

from datetime import datetime

from decimal import Decimal
from sqlalchemy import BigInteger, Boolean, CheckConstraint, DateTime, ForeignKey, Identity, Integer, Numeric, SmallInteger, String, Text, text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database import Base

small_pk = SmallInteger().with_variant(Integer, "sqlite")
big_pk = BigInteger().with_variant(Integer, "sqlite")


class Categoria(Base):
    __tablename__ = "categoria"

    id_categoria: Mapped[int] = mapped_column(
        small_pk, Identity(always=True), primary_key=True
    )
    codigo: Mapped[str] = mapped_column(String(40), unique=True, nullable=False)
    nome: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    descricao: Mapped[str | None] = mapped_column(String(255))
    ativo: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("true"))


class StatusOcorrencia(Base):
    __tablename__ = "status_ocorrencia"

    id_status: Mapped[int] = mapped_column(
        small_pk, Identity(always=True), primary_key=True
    )
    codigo: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    nome: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    ordem: Mapped[int] = mapped_column(SmallInteger, unique=True, nullable=False)
    status_final: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("false"))
    __table_args__ = (CheckConstraint("ordem > 0"),)


class Equipe(Base):
    __tablename__ = "equipe"

    id_equipe: Mapped[int] = mapped_column(
        big_pk, Identity(always=True), primary_key=True
    )
    nome: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    especialidade: Mapped[str] = mapped_column(String(100), nullable=False)
    ativa: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("true"))
    criado_em: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=text("CURRENT_TIMESTAMP")
    )


class Usuario(Base):
    __tablename__ = 'usuario'
    id_usuario: Mapped[int] = mapped_column(big_pk, Identity(always=True), primary_key=True)
    nome: Mapped[str] = mapped_column(String(120), nullable=False)
    email: Mapped[str] = mapped_column(String(160), unique=True, nullable=False)
    perfil: Mapped[str] = mapped_column(String(20), nullable=False)
    ativo: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text('true'))
    criado_em: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=text('CURRENT_TIMESTAMP'))
    __table_args__ = (CheckConstraint("perfil IN ('CIDADAO','PREFEITURA','EQUIPE','ADMINISTRADOR')"),)


class Ocorrencia(Base):
    __tablename__ = 'ocorrencia'
    id_ocorrencia: Mapped[int] = mapped_column(big_pk, Identity(always=True), primary_key=True)
    protocolo: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    id_usuario: Mapped[int] = mapped_column(ForeignKey('usuario.id_usuario', ondelete='RESTRICT'), nullable=False)
    id_categoria: Mapped[int | None] = mapped_column(ForeignKey('categoria.id_categoria', ondelete='RESTRICT'))
    id_status: Mapped[int] = mapped_column(ForeignKey('status_ocorrencia.id_status', ondelete='RESTRICT'), nullable=False)
    descricao: Mapped[str] = mapped_column(Text, nullable=False)
    latitude: Mapped[Decimal] = mapped_column(Numeric(9,6), nullable=False)
    longitude: Mapped[Decimal] = mapped_column(Numeric(9,6), nullable=False)
    prioridade: Mapped[str] = mapped_column(String(10), nullable=False)
    criado_em: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=text('CURRENT_TIMESTAMP'))
    atualizado_em: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=text('CURRENT_TIMESTAMP'))
    categoria: Mapped[Categoria | None] = relationship()
    usuario: Mapped[Usuario] = relationship()
    status: Mapped[StatusOcorrencia] = relationship()
    __table_args__ = (
        CheckConstraint('length(trim(descricao)) BETWEEN 10 AND 2000'),
        CheckConstraint('latitude BETWEEN -90 AND 90'),
        CheckConstraint('longitude BETWEEN -180 AND 180'),
        CheckConstraint("prioridade IN ('BAIXA','MEDIA','ALTA','CRITICA')"),
        CheckConstraint('atualizado_em >= criado_em'),
    )


class HistoricoStatus(Base):
    __tablename__ = 'historico_status'
    id_historico: Mapped[int] = mapped_column(big_pk, Identity(always=True), primary_key=True)
    id_ocorrencia: Mapped[int] = mapped_column(ForeignKey('ocorrencia.id_ocorrencia', ondelete='CASCADE'), nullable=False)
    id_status: Mapped[int] = mapped_column(ForeignKey('status_ocorrencia.id_status', ondelete='RESTRICT'), nullable=False)
    id_usuario_responsavel: Mapped[int] = mapped_column(ForeignKey('usuario.id_usuario', ondelete='RESTRICT'), nullable=False)
    observacao: Mapped[str | None] = mapped_column(Text)
    alterado_em: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=text('CURRENT_TIMESTAMP'))


class FotoOcorrencia(Base):
    __tablename__ = 'foto_ocorrencia'
    id_foto: Mapped[int] = mapped_column(big_pk, Identity(always=True), primary_key=True)
    id_ocorrencia: Mapped[int] = mapped_column(ForeignKey('ocorrencia.id_ocorrencia', ondelete='CASCADE'), nullable=False, index=True)
    url_arquivo: Mapped[str] = mapped_column(Text, nullable=False)
    criado_em: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=text('CURRENT_TIMESTAMP'), nullable=False)
    __table_args__ = (CheckConstraint('length(trim(url_arquivo)) > 0'),)


class AnaliseIA(Base):
    __tablename__ = 'analise_ia'
    id_analise: Mapped[int] = mapped_column(big_pk, Identity(always=True), primary_key=True)
    id_ocorrencia: Mapped[int] = mapped_column(ForeignKey('ocorrencia.id_ocorrencia', ondelete='CASCADE'), nullable=False, index=True)
    resumo: Mapped[str] = mapped_column(Text, nullable=False)
    valido: Mapped[bool] = mapped_column(Boolean, nullable=False)
    id_categoria_sugerida: Mapped[int | None] = mapped_column(ForeignKey('categoria.id_categoria', ondelete='RESTRICT'))
    prioridade_sugerida: Mapped[str | None] = mapped_column(String(10))
    id_ocorrencia_duplicada: Mapped[int | None] = mapped_column(ForeignKey('ocorrencia.id_ocorrencia', ondelete='RESTRICT'))
    analisado_em: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=text('CURRENT_TIMESTAMP'), nullable=False)
    __table_args__ = (
        CheckConstraint('length(trim(resumo)) > 0'),
        CheckConstraint("prioridade_sugerida IS NULL OR prioridade_sugerida IN ('BAIXA','MEDIA','ALTA','CRITICA')"),
        CheckConstraint('id_ocorrencia_duplicada IS NULL OR id_ocorrencia_duplicada <> id_ocorrencia'),
    )


class Atendimento(Base):
    __tablename__ = 'atendimento'
    id_atendimento: Mapped[int] = mapped_column(big_pk, Identity(always=True), primary_key=True)
    id_ocorrencia: Mapped[int] = mapped_column(ForeignKey('ocorrencia.id_ocorrencia', ondelete='CASCADE'), nullable=False, index=True)
    id_equipe: Mapped[int] = mapped_column(ForeignKey('equipe.id_equipe', ondelete='RESTRICT'), nullable=False, index=True)
    inicio_em: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    fim_em: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    observacao: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (CheckConstraint('fim_em IS NULL OR inicio_em IS NULL OR fim_em >= inicio_em'),)


class Credencial(Base):
    __tablename__ = 'credencial_local'
    id_usuario: Mapped[int] = mapped_column(ForeignKey('usuario.id_usuario', ondelete='CASCADE'), primary_key=True)
    senha_hash: Mapped[str] = mapped_column(String(255), nullable=False)


class Sessao(Base):
    __tablename__ = 'sessao_local'
    token_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    id_usuario: Mapped[int] = mapped_column(ForeignKey('usuario.id_usuario', ondelete='CASCADE'), index=True, nullable=False)
    expira_em: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class Preferencia(Base):
    __tablename__ = 'preferencia_local'
    id_usuario: Mapped[int] = mapped_column(ForeignKey('usuario.id_usuario', ondelete='CASCADE'), primary_key=True)
    notificacoes: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    tamanho_texto: Mapped[str] = mapped_column(String(10), nullable=False, default='PADRAO')
    alto_contraste: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    __table_args__ = (CheckConstraint("tamanho_texto IN ('PADRAO','GRANDE')"),)
