@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Execute preparar.bat primeiro.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pytest -q
if errorlevel 1 (
  pause
  exit /b 1
)
".venv\Scripts\python.exe" scripts\testar_http.py
pause
