"""Diagnóstico sem ler contas, senhas, conexões ou arquivos pessoais."""
import importlib.metadata
import platform
import shutil
import sys

print('Sistema:', platform.system(), platform.release())
print('Python:', platform.python_version())
print('Versão suportada:', (3,11)<=sys.version_info[:2]<(3,14))
print('Ambiente virtual:', sys.prefix!=sys.base_prefix)
print('VS Code no PATH:', bool(shutil.which('code')))
print('Git no PATH:', bool(shutil.which('git')))
for package in ['fastapi','uvicorn','SQLAlchemy','pydantic','pandas','psycopg','pytest']:
    try:print(package,importlib.metadata.version(package))
    except importlib.metadata.PackageNotFoundError:print(package,'não instalado neste interpretador')
