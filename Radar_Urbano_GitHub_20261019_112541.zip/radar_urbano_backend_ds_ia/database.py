"""Engine e sessões por requisição; importar não cria nem migra tabelas."""
from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi import Request
from config import validar_banco_local


class Base(DeclarativeBase):
    pass


def criar_engine(url):
    url = validar_banco_local(url)
    options = {'pool_pre_ping': True}
    if url.startswith('sqlite:'):
        options['connect_args'] = {'check_same_thread': False}
        if url.endswith(':memory:'):
            options['poolclass'] = StaticPool
    engine = create_engine(url, **options)
    if engine.dialect.name == 'sqlite':
        @event.listens_for(engine, 'connect')
        def foreign_keys(connection, _):
            connection.execute('PRAGMA foreign_keys=ON')
    return engine


def get_db(request: Request):
    # Sessões só são abertas nas rotas de gestão. IA não depende desta função.
    with request.app.state.session_factory() as session:
        try:
            yield session
        except Exception:
            session.rollback()
            raise
