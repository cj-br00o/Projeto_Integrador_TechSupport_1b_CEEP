-- Radar Urbano: esquema de referência para PostgreSQL LOCAL NOVO.

-- Não executar no Supabase ou em banco de terceiros. Não é migração.

BEGIN;

CREATE TABLE categoria (
	id_categoria SMALLINT GENERATED ALWAYS AS IDENTITY, 
	codigo VARCHAR(40) NOT NULL, 
	nome VARCHAR(80) NOT NULL, 
	descricao VARCHAR(255), 
	ativo BOOLEAN DEFAULT true NOT NULL, 
	PRIMARY KEY (id_categoria), 
	UNIQUE (codigo), 
	UNIQUE (nome)
);

CREATE TABLE equipe (
	id_equipe BIGINT GENERATED ALWAYS AS IDENTITY, 
	nome VARCHAR(100) NOT NULL, 
	especialidade VARCHAR(100) NOT NULL, 
	ativa BOOLEAN DEFAULT true NOT NULL, 
	criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL, 
	PRIMARY KEY (id_equipe), 
	UNIQUE (nome)
);

CREATE TABLE status_ocorrencia (
	id_status SMALLINT GENERATED ALWAYS AS IDENTITY, 
	codigo VARCHAR(30) NOT NULL, 
	nome VARCHAR(50) NOT NULL, 
	ordem SMALLINT NOT NULL, 
	status_final BOOLEAN DEFAULT false NOT NULL, 
	PRIMARY KEY (id_status), 
	CHECK (ordem > 0), 
	UNIQUE (codigo), 
	UNIQUE (nome), 
	UNIQUE (ordem)
);

CREATE TABLE usuario (
	id_usuario BIGINT GENERATED ALWAYS AS IDENTITY, 
	nome VARCHAR(120) NOT NULL, 
	email VARCHAR(160) NOT NULL, 
	perfil VARCHAR(20) NOT NULL, 
	ativo BOOLEAN DEFAULT true NOT NULL, 
	criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL, 
	PRIMARY KEY (id_usuario), 
	CHECK (perfil IN ('CIDADAO','PREFEITURA','EQUIPE','ADMINISTRADOR')), 
	UNIQUE (email)
);

CREATE TABLE credencial_local (
	id_usuario BIGINT NOT NULL, 
	senha_hash VARCHAR(255) NOT NULL, 
	PRIMARY KEY (id_usuario), 
	FOREIGN KEY(id_usuario) REFERENCES usuario (id_usuario) ON DELETE CASCADE
);

CREATE TABLE ocorrencia (
	id_ocorrencia BIGINT GENERATED ALWAYS AS IDENTITY, 
	protocolo VARCHAR(20) NOT NULL, 
	id_usuario BIGINT NOT NULL, 
	id_categoria SMALLINT, 
	id_status SMALLINT NOT NULL, 
	descricao TEXT NOT NULL, 
	latitude NUMERIC(9, 6) NOT NULL, 
	longitude NUMERIC(9, 6) NOT NULL, 
	prioridade VARCHAR(10) NOT NULL, 
	criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL, 
	atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL, 
	PRIMARY KEY (id_ocorrencia), 
	CHECK (length(trim(descricao)) BETWEEN 10 AND 2000), 
	CHECK (latitude BETWEEN -90 AND 90), 
	CHECK (longitude BETWEEN -180 AND 180), 
	CHECK (prioridade IN ('BAIXA','MEDIA','ALTA','CRITICA')), 
	CHECK (atualizado_em >= criado_em), 
	UNIQUE (protocolo), 
	FOREIGN KEY(id_usuario) REFERENCES usuario (id_usuario) ON DELETE RESTRICT, 
	FOREIGN KEY(id_categoria) REFERENCES categoria (id_categoria) ON DELETE RESTRICT, 
	FOREIGN KEY(id_status) REFERENCES status_ocorrencia (id_status) ON DELETE RESTRICT
);

CREATE TABLE preferencia_local (
	id_usuario BIGINT NOT NULL, 
	notificacoes BOOLEAN NOT NULL, 
	tamanho_texto VARCHAR(10) NOT NULL, 
	alto_contraste BOOLEAN NOT NULL, 
	PRIMARY KEY (id_usuario), 
	CHECK (tamanho_texto IN ('PADRAO','GRANDE')), 
	FOREIGN KEY(id_usuario) REFERENCES usuario (id_usuario) ON DELETE CASCADE
);

CREATE TABLE sessao_local (
	token_hash VARCHAR(64) NOT NULL, 
	id_usuario BIGINT NOT NULL, 
	expira_em TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (token_hash), 
	FOREIGN KEY(id_usuario) REFERENCES usuario (id_usuario) ON DELETE CASCADE
);

CREATE INDEX ix_sessao_local_id_usuario ON sessao_local (id_usuario);

CREATE TABLE analise_ia (
	id_analise BIGINT GENERATED ALWAYS AS IDENTITY, 
	id_ocorrencia BIGINT NOT NULL, 
	resumo TEXT NOT NULL, 
	valido BOOLEAN NOT NULL, 
	id_categoria_sugerida SMALLINT, 
	prioridade_sugerida VARCHAR(10), 
	id_ocorrencia_duplicada BIGINT, 
	analisado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL, 
	PRIMARY KEY (id_analise), 
	CHECK (length(trim(resumo)) > 0), 
	CHECK (prioridade_sugerida IS NULL OR prioridade_sugerida IN ('BAIXA','MEDIA','ALTA','CRITICA')), 
	CHECK (id_ocorrencia_duplicada IS NULL OR id_ocorrencia_duplicada <> id_ocorrencia), 
	FOREIGN KEY(id_ocorrencia) REFERENCES ocorrencia (id_ocorrencia) ON DELETE CASCADE, 
	FOREIGN KEY(id_categoria_sugerida) REFERENCES categoria (id_categoria) ON DELETE RESTRICT, 
	FOREIGN KEY(id_ocorrencia_duplicada) REFERENCES ocorrencia (id_ocorrencia) ON DELETE RESTRICT
);

CREATE INDEX ix_analise_ia_id_ocorrencia ON analise_ia (id_ocorrencia);

CREATE TABLE atendimento (
	id_atendimento BIGINT GENERATED ALWAYS AS IDENTITY, 
	id_ocorrencia BIGINT NOT NULL, 
	id_equipe BIGINT NOT NULL, 
	inicio_em TIMESTAMP WITH TIME ZONE, 
	fim_em TIMESTAMP WITH TIME ZONE, 
	observacao TEXT, 
	PRIMARY KEY (id_atendimento), 
	CHECK (fim_em IS NULL OR inicio_em IS NULL OR fim_em >= inicio_em), 
	FOREIGN KEY(id_ocorrencia) REFERENCES ocorrencia (id_ocorrencia) ON DELETE CASCADE, 
	FOREIGN KEY(id_equipe) REFERENCES equipe (id_equipe) ON DELETE RESTRICT
);

CREATE INDEX ix_atendimento_id_equipe ON atendimento (id_equipe);

CREATE INDEX ix_atendimento_id_ocorrencia ON atendimento (id_ocorrencia);

CREATE TABLE foto_ocorrencia (
	id_foto BIGINT GENERATED ALWAYS AS IDENTITY, 
	id_ocorrencia BIGINT NOT NULL, 
	url_arquivo TEXT NOT NULL, 
	criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL, 
	PRIMARY KEY (id_foto), 
	CHECK (length(trim(url_arquivo)) > 0), 
	FOREIGN KEY(id_ocorrencia) REFERENCES ocorrencia (id_ocorrencia) ON DELETE CASCADE
);

CREATE INDEX ix_foto_ocorrencia_id_ocorrencia ON foto_ocorrencia (id_ocorrencia);

CREATE TABLE historico_status (
	id_historico BIGINT GENERATED ALWAYS AS IDENTITY, 
	id_ocorrencia BIGINT NOT NULL, 
	id_status SMALLINT NOT NULL, 
	id_usuario_responsavel BIGINT NOT NULL, 
	observacao TEXT, 
	alterado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL, 
	PRIMARY KEY (id_historico), 
	FOREIGN KEY(id_ocorrencia) REFERENCES ocorrencia (id_ocorrencia) ON DELETE CASCADE, 
	FOREIGN KEY(id_status) REFERENCES status_ocorrencia (id_status) ON DELETE RESTRICT, 
	FOREIGN KEY(id_usuario_responsavel) REFERENCES usuario (id_usuario) ON DELETE RESTRICT
);

COMMIT;
