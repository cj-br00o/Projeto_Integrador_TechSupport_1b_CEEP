import {defineConfig} from '@playwright/test';

export default defineConfig({
  testDir: './tests/browser',
  fullyParallel: false,
  workers: 1,
  retries: 0,
  timeout: 45_000,
  reporter: [['list']],
  outputDir: process.env.RADAR_TEST_OUTPUT || 'test-results',
  use: {
    baseURL: process.env.RADAR_TEST_BASE_URL || 'http://127.0.0.1:8000',
    channel: 'chrome',
    headless: true,
    trace: 'off',
    screenshot: 'off',
    video: 'off',
    locale: 'pt-BR',
    timezoneId: 'America/Sao_Paulo'
  }
});
