"""Uma aplicação FastAPI para gestão DS e análise IA; teste em /docs."""
from collections import defaultdict, deque
from contextlib import asynccontextmanager
import time
from fastapi import FastAPI, Request, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError, OperationalError, DataError
from sqlalchemy.orm import sessionmaker
from database import criar_engine, get_db
from config import Settings
from security import password_hash
from fastapi import Depends
from starlette.exceptions import HTTPException as StarletteHTTPException
from schemas import ErroResponse
from routes import auth, catalogos, ocorrencias, mapa, fotos, ia


def create_app(settings=None):
    settings = settings or Settings.from_env()
    engine = criar_engine(settings.database_url)  # Cria engine, não abre conexão nem cria tabelas.

    @asynccontextmanager
    async def lifespan(app):
        yield
        engine.dispose()

    app = FastAPI(title='Radar Urbano DS e IA', version='2.0.0', lifespan=lifespan,
                  responses={code: {'model': ErroResponse} for code in (401,403,404,409,413,422,429,500,503)},
                  description='Gestão em banco local e Ciência de Dados em CSV. Sem acesso ao Supabase.')
    app.state.settings = settings
    app.state.engine = engine
    app.state.session_factory = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    app.state.dummy_hash = password_hash('not-a-real-password')
    app.add_middleware(CORSMiddleware, allow_origins=settings.origins, allow_credentials=False,
                       allow_methods=['GET', 'POST', 'PATCH', 'PUT', 'OPTIONS'], allow_headers=['Authorization', 'Content-Type'])
    for module in (auth, catalogos, ocorrencias, mapa, fotos, ia):
        app.include_router(module.router, prefix='/api/v1')
    frontend = Path(__file__).resolve().parent / 'frontend'
    if frontend.is_dir():
        app.mount('/assets', StaticFiles(directory=frontend), name='frontend-assets')
    attempts = defaultdict(deque)

    @app.middleware('http')
    async def headers_and_limit(request: Request, call_next):
        if request.method == 'POST' and request.url.path in ('/api/v1/auth/login', '/api/v1/auth/cadastro'):
            stamp = time.monotonic()
            for key in list(attempts):
                if not attempts[key] or attempts[key][-1] < stamp-60:
                    del attempts[key]
            queue = attempts[request.client.host if request.client else 'local']
            while queue and queue[0] < stamp-60:
                queue.popleft()
            if len(queue) >= settings.auth_limit:
                return JSONResponse({'erro': {'mensagem': 'Muitas tentativas. Aguarde um minuto.'}}, 429)
            queue.append(stamp)
        response = await call_next(request)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        response.headers['X-Frame-Options'] = 'DENY'
        if request.url.path == '/' or request.url.path.startswith('/assets/'):
            response.headers['Content-Security-Policy'] = (
                "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
                "img-src 'self' blob: data: https://tile.openstreetmap.org; connect-src 'self'; "
                "font-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
            )
        if request.url.path.startswith('/api/'):
            response.headers['Cache-Control'] = 'no-store'
        return response

    @app.exception_handler(StarletteHTTPException)
    async def http_error(request, exc):
        return JSONResponse({'erro': {'mensagem': exc.detail}}, exc.status_code, headers=exc.headers)

    @app.exception_handler(RequestValidationError)
    async def validation_error(request, exc):
        # Não incluir input/ctx: dados de entrada podem conter senhas e tokens.
        errors = [{'campo': '.'.join(map(str, e['loc'])), 'mensagem': e['msg']} for e in exc.errors()]
        return JSONResponse({'erro': {'mensagem': 'Confira os dados enviados.', 'campos': errors}}, 422)

    @app.exception_handler(IntegrityError)
    async def conflict(request, exc):
        return JSONResponse({'erro': {'mensagem': 'Registro duplicado ou relacionamento inválido.'}}, 409)

    @app.exception_handler(OperationalError)
    async def unavailable(request, exc):
        return JSONResponse({'erro': {'mensagem': 'Banco local indisponível. Confira a conexão e execute init-db.'}}, 503)

    @app.exception_handler(DataError)
    async def invalid_storage_value(request, exc):
        return JSONResponse({'erro': {'mensagem': 'Valor fora dos limites permitidos.'}}, 422)

    @app.exception_handler(Exception)
    async def internal_error(request, exc):
        return JSONResponse({'erro': {'mensagem': 'Erro interno. Consulte o terminal da API.'}}, 500)

    @app.get('/', tags=['Diagnóstico'])
    def inicio():
        if (frontend / 'index.html').is_file():
            return FileResponse(frontend / 'index.html', headers={'Cache-Control': 'no-cache'})
        return {'mensagem': 'Radar Urbano DS e IA', 'documentacao': '/docs', 'api': '/api/v1'}

    @app.get('/api/v1/saude', tags=['Diagnóstico'])
    def saude(db=Depends(get_db)):
        db.execute(text('SELECT 1'))
        return {'dados': {'status': 'ok', 'banco': engine.dialect.name, 'ambiente': 'local'}}

    return app


app = create_app()
