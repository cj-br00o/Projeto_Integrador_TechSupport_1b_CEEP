// Funções de apresentação sem dados fictícios e sem dependência do layout.
export const STATUS = [
  ['RECEBIDA', 'Recebida'], ['EM_ANALISE', 'Em análise'],
  ['ENCAMINHADA', 'Encaminhada'], ['EM_ATENDIMENTO', 'Em atendimento'], ['RESOLVIDA', 'Resolvida']
];

export function formatDate(value, includeTime = false) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Data não disponível';
  return new Intl.DateTimeFormat('pt-BR', {
    timeZone: 'America/Sao_Paulo', dateStyle: 'medium', ...(includeTime ? {timeStyle: 'short'} : {})
  }).format(date);
}

export function panelCounts(data) {
  const statuses = data.por_status || {};
  return {total: data.total, abertas: data.total - (statuses.RESOLVIDA || 0),
    emAtendimento: statuses.EM_ATENDIMENTO || 0, resolvidas: statuses.RESOLVIDA || 0};
}

export function parseCoordinates(latitude, longitude) {
  if (!String(latitude).trim() || !String(longitude).trim()) throw new Error('Informe a latitude e a longitude do problema.');
  const lat = Number(String(latitude).replace(',', '.'));
  const lon = Number(String(longitude).replace(',', '.'));
  if (!Number.isFinite(lat) || lat < -90 || lat > 90 || !Number.isFinite(lon) || lon < -180 || lon > 180) {
    throw new Error('Informe coordenadas válidas: latitude entre −90 e 90 e longitude entre −180 e 180.');
  }
  return {latitude: lat, longitude: lon};
}

export function validatePhotos(files, existingCount = 0) {
  if (files.length + existingCount > 5) throw new Error('Cada solicitação permite até cinco fotos.');
  for (const file of files) {
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) throw new Error('Use fotos JPEG, PNG ou WebP.');
    if (file.size > 6 * 1024 * 1024) throw new Error('Cada foto deve ter até 6 MiB.');
  }
}
