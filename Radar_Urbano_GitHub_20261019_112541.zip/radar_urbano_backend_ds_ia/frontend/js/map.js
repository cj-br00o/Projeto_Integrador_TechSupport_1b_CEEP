import {icon} from './ui.js';

export function createMap(element, {features = [], picker = false, onPick, onSelect, mini = false} = {}) {
  if (!window.L || !element) return {destroy() {}, focus() {}, setPoint() {}, map: null};
  const L = window.L;
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const map = L.map(element, {center: [-23.4205, -51.9333], zoom: 14, scrollWheelZoom: false,
    zoomControl: !mini, dragging: !mini, keyboard: !mini, touchZoom: !mini,
    doubleClickZoom: !mini, zoomAnimation: !reduceMotion, fadeAnimation: !reduceMotion});
  element.setAttribute('aria-label', picker ? 'Selecione a localização do problema no mapa ou preencha as coordenadas abaixo' : 'Mapa de ocorrências urbanas em Maringá');
  const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>'
  }).addTo(map);
  let errored = false;
  tiles.on('tileerror', () => {
    if (errored) return;
    errored = true;
    const message = document.querySelector('#map-network');
    if (message) { message.textContent = 'A base de ruas está indisponível. As coordenadas e a lista de registros continuam disponíveis.'; message.hidden = false; }
  });
  const pin = selected => L.divIcon({className: '', html: `<div class="map-pin${selected ? ' selected' : ''}"></div>`, iconSize: [24, 24], iconAnchor: [12, 24]});
  const markers = new Map();
  for (const feature of features) {
    const {coordinates} = feature.geometry;
    const props = feature.properties;
    const marker = L.marker([coordinates[1], coordinates[0]], {icon: pin(false), keyboard: !mini,
      title: `${props.categoria || 'Sem categoria'} — ${props.status}`}).addTo(map);
    const text = document.createElement('span');
    text.textContent = `${props.categoria || 'Sem categoria'} · ${props.status}`;
    marker.bindPopup(text);
    marker.on('click', () => onSelect?.(feature));
    markers.set(props.id_ocorrencia, marker);
  }
  if (features.length) {
    const bounds = L.latLngBounds(features.map(f => [f.geometry.coordinates[1], f.geometry.coordinates[0]]));
    map.fitBounds(bounds.pad(.25), {maxZoom: mini ? 14 : 16, animate: false});
  }
  let locationMarker;
  const setPoint = (lat, lon) => {
    if (locationMarker) map.removeLayer(locationMarker);
    locationMarker = L.marker([lat, lon], {icon: pin(true), title: 'Localização selecionada', keyboard: true}).addTo(map);
    map.setView([lat, lon], Math.max(map.getZoom(), 15), {animate: false});
  };
  if (picker) {
    element.classList.add('map-cursor');
    map.on('click', event => { setPoint(event.latlng.lat, event.latlng.lng); onPick?.(event.latlng.lat, event.latlng.lng); });
  }
  requestAnimationFrame(() => map.invalidateSize());
  return {map, destroy: () => map.remove(), setPoint,
    focus(id) {
      const marker = markers.get(id);
      if (marker) { map.setView(marker.getLatLng(), Math.max(map.getZoom(), 16), {animate: false}); marker.openPopup(); }
    }};
}
