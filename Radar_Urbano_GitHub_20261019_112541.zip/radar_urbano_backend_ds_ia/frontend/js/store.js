import {api, allPages, hasSession, restoreSession, setSession, login as signIn, logout as signOut, uploadPhoto} from './api.js';
import {parseCoordinates, validatePhotos} from './domain.js';

export const state = {user: null, preferences: null, categories: [], statuses: []};

export async function initializeSession() {
  if (!hasSession() && !restoreSession()) return false;
  try {
    const [profile, preferences] = await Promise.all([api('/perfil'), api('/perfil/preferencias')]);
    state.user = profile.dados;
    state.preferences = preferences.dados;
    return true;
  } catch (error) {
    state.user = null;
    state.preferences = null;
    if (error.status === 401) { setSession(null); return false; }
    throw error;
  }
}

export async function login(email, password) {
  state.user = await signIn(email, password);
  state.preferences = (await api('/perfil/preferencias')).dados;
  return state.user;
}

export async function register({nome, email, senha}) {
  // O contrato público não inclui perfil administrativo.
  return (await api('/auth/cadastro', {method: 'POST', body: {nome, email, senha}})).dados;
}

export async function logout() {
  await signOut();
  state.user = null;
  state.preferences = null;
}

export async function catalogs(signal) {
  const [categories, statuses] = await Promise.all([allPages('/categorias', signal), api('/status', {signal})]);
  state.categories = categories;
  state.statuses = statuses.dados;
  return {categories, statuses: statuses.dados};
}

export async function saveProfile(nome) {
  state.user = (await api('/perfil', {method: 'PATCH', body: {nome}})).dados;
  return state.user;
}

export async function savePreferences(values) {
  state.preferences = (await api('/perfil/preferencias', {method: 'PATCH', body: values})).dados;
  return state.preferences;
}

export async function createOccurrence({id_categoria, descricao, latitude, longitude, photos = []}) {
  const coordinates = parseCoordinates(latitude, longitude);
  validatePhotos(photos);
  const created = (await api('/ocorrencias', {method: 'POST', body: {
    id_categoria: Number(id_categoria), descricao: descricao.trim(), ...coordinates
  }})).dados;
  const failures = [];
  let uploaded = 0;
  // A ocorrência é uma gravação real independente dos arquivos. Falha de foto
  // não deve induzir um segundo cadastro da mesma solicitação.
  for (const file of photos) {
    try { await uploadPhoto(created.id_ocorrencia, file); uploaded += 1; }
    catch (error) { failures.push({file: file.name, message: error.message}); }
  }
  return {occurrence: created, uploaded, failures};
}

export async function occurrenceDetails(id, signal) {
  const [occurrence, history, services, photos] = await Promise.all([
    api(`/ocorrencias/${id}`, {signal}), allPages(`/ocorrencias/${id}/historico`, signal),
    allPages(`/ocorrencias/${id}/atendimentos`, signal), api(`/ocorrencias/${id}/fotos`, {signal})
  ]);
  return {occurrence: occurrence.dados, history, services, photos: photos.dados};
}
