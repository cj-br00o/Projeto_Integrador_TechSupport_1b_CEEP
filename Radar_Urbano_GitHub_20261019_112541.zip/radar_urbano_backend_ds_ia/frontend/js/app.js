import {api, allPages, photoObjectURL, uploadPhoto, setSession} from './api.js';
import * as store from './store.js';
import {formatDate, panelCounts, parseCoordinates, validatePhotos} from './domain.js';
import {esc, icon, categoryIcon, statusBadge, notice, empty, toast, formError, formHandler} from './ui.js';
import {createMap} from './map.js';
import {managementPage, managementControls} from './management.js';

const $ = selector => document.querySelector(selector);
let controller, cleanup = [], epoch = 0, pendingRoute = '', successMessage = '';
const staff = () => ['ADMINISTRADOR', 'PREFEITURA'].includes(store.state.user?.perfil);
const currentPath = () => location.hash.replace(/^#/, '') || (store.state.user ? (staff() ? '/gestao' : '/inicio') : '/entrada');
const navigate = path => { if (currentPath() === path && location.hash) render(); else location.hash = path; };
const buttonLink = (path, text, name = 'plus', cls = 'primary') => `<a href="#${path}" class="button ${cls}">${icon(name)}${esc(text)}</a>`;
const fieldsError = '<p class="form-error" role="alert" hidden></p>';
const title = (heading, description, eyebrow = '') => `<div class="page-heading"><div class="location">${icon('pin')}Maringá, PR</div>${eyebrow ? `<p class="eyebrow">${esc(eyebrow)}</p>` : ''}<h1 tabindex="-1">${esc(heading)}</h1><p class="subtitle">${esc(description)}</p></div>`;
const back = (path, text = 'Voltar') => `<a class="back-link" href="#${path}">${icon('chevron')}${esc(text)}</a>`;
const opts = (rows, key, label, selected = '') => rows.map(row => `<option value="${esc(row[key])}" ${String(row[key]) === String(selected) ? 'selected' : ''}>${esc(row[label])}</option>`).join('');

function shell(path) {
  const logged = !!store.state.user;
  const nav = [['/inicio','home','Início'],['/mapa','pin','Mapa'],['/solicitacoes','list','Solicitações'],['/perfil','user','Perfil']];
  const active = route => path === route || (route === '/solicitacoes' && (path.startsWith('/solicitacao/') || path === '/nova'));
  const links = mobile => nav.map(([route, name, label]) => `<a href="#${route}" ${active(route) ? 'aria-current="page"' : ''}>${mobile ? icon(name) : ''}${label}</a>`).join('');
  document.body.classList.toggle('with-nav', logged || path === '/mapa');
  document.body.classList.toggle('management', path.startsWith('/gestao'));
  $('#app').innerHTML = `<header class="site-header"><div class="header-inner"><a class="brand" href="#${logged ? (staff() ? '/gestao' : '/inicio') : '/entrada'}" aria-label="Radar Urbano — página inicial"><img src="/assets/brand.svg" alt="" width="45" height="55"><span><strong>Radar<span>Urbano</span></strong><small>Maringá · PR</small></span></a><nav class="desktop-nav" aria-label="Navegação principal">${logged ? links(false) : '<a href="#/mapa">Mapa público</a><a href="#/entrar">Entrar</a>'}${staff() ? `<a href="#/gestao" ${path.startsWith('/gestao') ? 'aria-current="page"' : ''}>Gestão</a>` : ''}</nav><div class="utilities">${logged ? `<a class="icon-button" href="#/solicitacoes" aria-label="Acompanhar atualizações das solicitações">${icon('bell')}</a>` : ''}<button class="icon-button tint" id="open-access" aria-label="Abrir opções de acessibilidade">${icon('access')}</button></div></div></header><main id="conteudo" class="app-main" tabindex="-1" aria-busy="true"><p role="status">Carregando…</p></main><footer class="site-footer"><strong>Maringá, PR · Radar Urbano</strong>Projeto acadêmico · Serviços urbanos e cidadania</footer>${logged || path === '/mapa' ? `<nav class="mobile-nav" aria-label="Navegação principal no celular">${links(true)}</nav>` : ''}`;
  $('#open-access').addEventListener('click', openAccessibility);
}

function setContent(html, pageTitle) {
  $('#conteudo').innerHTML = html;
  $('#conteudo').removeAttribute('aria-busy');
  document.title = `${pageTitle} · Radar Urbano`;
  $('#conteudo h1')?.focus({preventScroll: true});
  document.querySelectorAll('[data-show-password]').forEach(button => {
    button.addEventListener('click', () => {
      const input = document.getElementById(button.dataset.showPassword);
      const show = input.type === 'password'; input.type = show ? 'text' : 'password';
      button.textContent = show ? 'Ocultar' : 'Mostrar';
      button.setAttribute('aria-label', `${show ? 'Ocultar' : 'Mostrar'} ${input.labels[0]?.textContent || 'senha'}`);
    });
  });
}

function passwordField(id, label, autocomplete, min = 1) {
  return `<div class="field"><label for="${id}">${label}</label><div class="password-wrap"><input id="${id}" name="${id}" type="password" autocomplete="${autocomplete}" minlength="${min}" maxlength="128" required><button type="button" data-show-password="${id}" aria-label="Mostrar ${label.toLowerCase()}">Mostrar</button></div></div>`;
}

function applyPreferences(values) {
  document.documentElement.classList.toggle('high-contrast', !!values?.alto_contraste);
  document.documentElement.classList.toggle('large-text', values?.tamanho_texto === 'GRANDE');
  try { localStorage.setItem('radar-accessibility', JSON.stringify({alto_contraste: !!values?.alto_contraste, tamanho_texto: values?.tamanho_texto || 'PADRAO'})); } catch {}
}

function openAccessibility() {
  const form = $('#access-form');
  form.alto_contraste.checked = document.documentElement.classList.contains('high-contrast');
  form.tamanho_texto.value = document.documentElement.classList.contains('large-text') ? 'GRANDE' : 'PADRAO';
  form.querySelector('.form-error').hidden = true;
  $('#accessibility').showModal();
}

async function entry() {
  setContent(`<section class="landing"><div class="landing-hero"><div><p class="eyebrow">Sua participação faz a diferença</p><h1>Uma cidade melhor.<br><span>Começa com você.</span></h1><p class="subtitle">Viu um problema no seu caminho? Registre com foto e localização e acompanhe cada etapa do atendimento.</p><div class="actions">${buttonLink('/entrar','Entrar na minha conta','user')}${buttonLink('/cadastro','Criar minha conta','plus','')}</div><p class="small-text" style="margin-top:20px">Quer conhecer os registros? <a href="#/mapa">Explore o mapa público</a>.</p></div><div class="city-art" aria-hidden="true"><img src="/assets/brand.svg" alt=""><span class="art-label">Conectando pessoas e cidade</span></div></div><div class="steps"><article class="step"><span class="number">1</span><h2>Informe o problema</h2><p>Escolha a categoria e descreva o que precisa de atenção.</p></article><article class="step"><span class="number">2</span><h2>Mostre onde está</h2><p>Adicione a localização e, se puder, uma fotografia.</p></article><article class="step"><span class="number">3</span><h2>Acompanhe por aqui</h2><p>Consulte o protocolo e o histórico da sua solicitação.</p></article></div>${notice('Ambiente acadêmico local. Os registros não são enviados ao canal oficial da prefeitura.')}</section>`, 'Bem-vindo');
}

async function authPage(register = false) {
  setContent(`<div class="auth-layout"><section class="auth-copy"><div class="large-icon">${icon(register ? 'user' : 'shield')}</div><p class="eyebrow">Radar Urbano · Maringá</p><h1>${register ? 'Faça parte de uma cidade melhor.' : 'Bom ter você por aqui.'}</h1><p>${register ? 'Crie sua conta para informar problemas e acompanhar suas solicitações em um só lugar.' : 'Entre para acompanhar seus registros e continuar cuidando da sua cidade.'}</p>${back('/entrada','Voltar para a entrada')}</section><section class="panel auth-panel" aria-labelledby="auth-title"><h2 id="auth-title">${register ? 'Criar minha conta' : 'Entrar na minha conta'}</h2><p class="small-text">${register ? 'Preencha seus dados para começar.' : 'Use o e-mail e a senha do seu cadastro.'}</p><form id="auth-form" class="stack">${register ? '<div class="field"><label for="nome">Nome completo</label><input id="nome" name="nome" autocomplete="name" minlength="2" maxlength="120" required></div>' : ''}<div class="field"><label for="email">E-mail</label><input id="email" name="email" type="email" autocomplete="email" maxlength="160" required></div>${passwordField('senha','Senha',register ? 'new-password' : 'current-password',register ? 10 : 1)}${register ? '<small class="muted">Use de 10 a 128 caracteres.</small>'+passwordField('confirmacao','Confirmar senha','new-password',10) : ''}${fieldsError}<button class="button primary wide" type="submit">${register ? 'Criar conta' : 'Entrar'}</button></form><p class="auth-note">${register ? 'Já tem cadastro? <a href="#/entrar">Entrar</a>' : 'Ainda não tem cadastro? <a href="#/cadastro">Criar conta</a>'}</p><p class="small-text muted" style="margin:18px 0 0">Ao usar o sistema, consulte as <a href="#/privacidade">informações de privacidade</a>.</p></section></div>`, register ? 'Cadastro' : 'Login');
  const form = $('#auth-form');
  formHandler(form, async data => {
    if (register) {
      if (data.get('senha') !== data.get('confirmacao')) throw new Error('As senhas não coincidem. Confira a confirmação.');
      await store.register({nome: data.get('nome'), email: data.get('email'), senha: data.get('senha')});
      form.reset();
      toast('Conta criada com sucesso. Entre com seu e-mail e senha.');
      navigate('/entrar');
    } else {
      await store.login(data.get('email'), data.get('senha'));
      form.reset(); applyPreferences(store.state.preferences);
      const next = pendingRoute || (staff() ? '/gestao' : '/inicio'); pendingRoute = ''; navigate(next);
    }
  });
}

function categoryFor(row) { return store.state.categories.find(c => c.id_categoria === row.id_categoria)?.codigo; }
function card(row) {
  return `<article class="request-card"><div class="category-symbol">${icon(categoryIcon(categoryFor(row)))}</div><div class="request-content"><h3>${esc(row.categoria || 'Sem categoria')}</h3><p>Protocolo ${esc(row.protocolo)}</p><p class="description">${esc(row.descricao)}</p><p class="small-text">${esc(formatDate(row.criado_em))} · Maringá, PR</p></div><div class="request-aside">${statusBadge(row.status_codigo)}<a class="text-link" href="#/solicitacao/${row.id_ocorrencia}">Ver detalhes ${icon('chevron')}</a></div></article>`;
}

async function home(signal, tick) {
  const [panel, latest, geo] = await Promise.all([api('/painel/cidadao',{signal}), api('/ocorrencias?limite=1',{signal}), api('/mapa',{signal})]);
  if (tick !== epoch) return;
  const counts = panelCounts(panel.dados);
  setContent(`${title(`Olá, ${store.state.user.nome.split(' ')[0]}`, 'Como podemos ajudar sua cidade hoje?')}<div class="action-grid"><a class="action-card primary" href="#/nova"><span class="action-symbol">${icon('camera')}</span><span><strong>Informar um problema</strong><p>Envie uma foto e a localização.</p></span>${icon('chevron')}</a><a class="action-card" href="#/solicitacoes"><span class="action-symbol">${icon('list')}</span><span><strong>Acompanhar solicitações</strong><p>Veja o andamento dos seus registros.</p></span>${icon('chevron')}</a></div><section class="home-summary" aria-label="Resumo das minhas solicitações"><div class="summary-grid">${[['Total de registros',counts.total],['Em aberto',counts.abertas],['Em atendimento',counts.emAtendimento],['Concluídas',counts.resolvidas]].map(([label,n]) => `<div class="stat"><span>${label}</span><strong>${n}</strong></div>`).join('')}</div></section><div class="home-columns"><section><div class="section-heading"><h2>Minha última solicitação</h2><a class="text-link" href="#/solicitacoes">Ver todas ${icon('chevron')}</a></div>${latest.dados.length ? card(latest.dados[0]) : empty('Sua primeira contribuição começa aqui','Você ainda não tem solicitações. Quando registrar um problema, poderá acompanhar por aqui.')}</section><section><div class="section-heading"><h2>Ocorrências na cidade</h2><a class="text-link" href="#/mapa">Ver no mapa ${icon('chevron')}</a></div><div id="home-map" class="mini-map"></div><p class="map-note">${geo.features.length} registros públicos exibidos · Localização aproximada.</p></section></div>`, 'Início');
  const map = createMap($('#home-map'),{features:geo.features,mini:true}); cleanup.push(()=>map.destroy());
}

async function requestsPage(signal, tick) {
  setContent(`${title('Minhas solicitações','Acompanhe cada etapa do atendimento.')}<form id="search-requests" class="toolbar"><div class="search-field"><label for="request-search">Buscar por protocolo ou assunto</label>${icon('search')}<input id="request-search" name="busca" maxlength="120" placeholder="Digite o protocolo ou uma palavra do relato"></div><div class="field filter-select"><label for="status-filter">Situação</label><select id="status-filter" name="id_status"><option value="">Todas as situações</option>${opts(store.state.statuses,'id_status','nome')}</select></div><button class="button" type="submit">Buscar</button></form><div class="actions" style="justify-content:space-between;margin-bottom:18px"><p class="small-text muted" id="request-count" role="status" style="margin:0">Carregando registros…</p>${buttonLink('/nova','Nova solicitação','plus')}</div><div id="request-results"></div><div id="request-pagination"></div>`, 'Solicitações');
  let page = 1, queryEpoch = 0;
  const load = async () => {
    const localTick = ++queryEpoch;
    const data = new FormData($('#search-requests'));
    const params = new URLSearchParams({pagina:String(page),limite:'6'});
    for (const key of ['busca','id_status']) if (data.get(key)) params.set(key,data.get(key));
    try {
      const result = await api('/ocorrencias?'+params,{signal});
      if (tick !== epoch || localTick !== queryEpoch) return;
      $('#request-count').textContent = `${result.paginacao.total} ${result.paginacao.total === 1 ? 'solicitação encontrada' : 'solicitações encontradas'}`;
      $('#request-results').innerHTML = result.dados.length ? `<div class="request-list">${result.dados.map(card).join('')}</div>` : empty('Nenhuma solicitação encontrada','Você pode mudar os filtros ou registrar um novo problema.');
      const pages = Math.max(1,Math.ceil(result.paginacao.total/6));
      $('#request-pagination').innerHTML = pages > 1 ? `<div class="pagination"><button class="button small" id="previous-page" ${page === 1 ? 'disabled' : ''}>Anterior</button><span>Página ${page} de ${pages}</span><button class="button small" id="next-page" ${page === pages ? 'disabled' : ''}>Próxima</button></div>` : '';
      $('#previous-page')?.addEventListener('click',()=>{page--;load();}); $('#next-page')?.addEventListener('click',()=>{page++;load();});
    } catch(error) { if(error.name !== 'AbortError' && tick === epoch) $('#request-results').innerHTML=notice(error.message,'warning'); }
  };
  $('#search-requests').addEventListener('submit',event=>{event.preventDefault();page=1;load();});
  $('#status-filter').addEventListener('change',()=>{page=1;load();});
  await load();
}

function attachGeolocation(button, callback) {
  button?.addEventListener('click',()=>{
    if (!navigator.geolocation) { toast('Seu navegador não oferece localização. Use o mapa ou informe as coordenadas.'); return; }
    button.disabled=true;
    navigator.geolocation.getCurrentPosition(position=>{button.disabled=false;callback(position.coords.latitude,position.coords.longitude);toast('Localização obtida. Confira se corresponde ao problema.');},()=>{button.disabled=false;toast('Não foi possível obter a localização. Você pode indicar no mapa ou preencher as coordenadas.');},{enableHighAccuracy:true,timeout:10000,maximumAge:60000});
  });
}

async function newOccurrence() {
  setContent(`${back('/inicio','Voltar ao início')}${title('Informar um problema','Conte o que aconteceu e indique o local para facilitar o atendimento.')}<div class="report-layout"><form id="report-form" class="panel"><section class="form-section"><div class="form-heading">${icon('list')}<h2>O que precisa de atenção?</h2></div><div class="stack"><div class="field"><label for="id_categoria">Categoria do problema</label><select id="id_categoria" name="id_categoria" required><option value="">Selecione uma categoria</option>${opts(store.state.categories,'id_categoria','nome')}</select></div><div class="field"><label for="descricao">Descrição do problema</label><textarea id="descricao" name="descricao" minlength="10" maxlength="2000" rows="4" placeholder="Descreva a situação e inclua um ponto de referência." required aria-describedby="description-hint"></textarea><small id="description-hint">Entre 10 e 2.000 caracteres. Evite incluir dados pessoais de outras pessoas.</small><small class="counter" id="description-count">0 / 2.000</small></div></div></section><section class="form-section"><div class="form-heading">${icon('pin')}<h2>Onde está o problema?</h2></div><button class="button secondary small" type="button" id="use-location">${icon('target')}Usar minha localização</button><p class="map-note">Clique no mapa ou preencha as coordenadas. Confira o ponto antes de enviar.</p><p id="map-network" class="map-note" hidden></p><div id="location-picker" class="map-picker"></div><div class="grid-2"><div class="field"><label for="latitude">Latitude</label><input id="latitude" name="latitude" inputmode="decimal" placeholder="Ex.: -23.4205" required></div><div class="field"><label for="longitude">Longitude</label><input id="longitude" name="longitude" inputmode="decimal" placeholder="Ex.: -51.9333" required></div></div><p class="map-note" id="location-status" role="status">Nenhum ponto selecionado.</p></section><section class="form-section"><div class="form-heading">${icon('camera')}<h2>Adicione fotos <span class="muted small-text">(opcional)</span></h2></div><div class="upload-hint"><p>Até cinco fotos JPEG, PNG ou WebP. Máximo de 6 MiB e 16 megapixels por foto.</p><label class="sr-only" for="photos">Selecionar fotos do problema</label><input id="photos" name="photos" type="file" accept="image/jpeg,image/png,image/webp" multiple><div id="photo-previews" class="photo-previews"></div></div></section>${fieldsError}<div class="form-footer"><p>Seu registro será salvo e poderá ser acompanhado pelo protocolo.</p><button class="button primary" type="submit">${icon('plus')}Enviar solicitação</button></div></form><aside class="panel tips-panel"><p class="eyebrow">Uma boa informação ajuda</p><h2>Faça seu relato com clareza</h2><ul class="tips"><li>Descreva o problema que você encontrou.</li><li>Indique o local exato e um ponto de referência.</li><li>Se for seguro, registre uma foto do problema.</li><li>Acompanhe as mudanças de status em Solicitações.</li></ul>${notice('Em situações de emergência, procure os canais oficiais de atendimento.')}</aside></div>`, 'Nova solicitação');
  const form=$('#report-form'), urls=[];
  const pick=(lat,lon)=>{form.latitude.value=Number(lat).toFixed(6);form.longitude.value=Number(lon).toFixed(6);$('#location-status').textContent='Ponto selecionado. Confira a localização antes de enviar.';};
  const map=createMap($('#location-picker'),{picker:true,onPick:pick});cleanup.push(()=>{map.destroy();urls.forEach(url=>URL.revokeObjectURL(url));});
  attachGeolocation($('#use-location'),(lat,lon)=>{pick(lat,lon);map.setPoint(lat,lon);});
  form.descricao.addEventListener('input',()=>{$('#description-count').textContent=`${form.descricao.value.length} / 2.000`;});
  for(const name of ['latitude','longitude']) form[name].addEventListener('change',()=>{try{const point=parseCoordinates(form.latitude.value,form.longitude.value);map.setPoint(point.latitude,point.longitude);$('#location-status').textContent='Coordenadas informadas. Confira o ponto no mapa.';}catch{}});
  form.photos.addEventListener('change',()=>{urls.forEach(url=>URL.revokeObjectURL(url));urls.length=0;$('#photo-previews').replaceChildren();try{validatePhotos([...form.photos.files]);for(const file of form.photos.files){const img=document.createElement('img');img.src=URL.createObjectURL(file);urls.push(img.src);img.alt='Prévia da foto selecionada';$('#photo-previews').append(img);}}catch(error){form.photos.value='';formError(form,error);}});
  formHandler(form,async data=>{
    const result=await store.createOccurrence({id_categoria:data.get('id_categoria'),descricao:data.get('descricao'),latitude:data.get('latitude'),longitude:data.get('longitude'),photos:[...form.photos.files]});
    successMessage=result.failures.length ? `Solicitação ${result.occurrence.protocolo} salva. ${result.failures.length} foto(s) não foram enviadas; você pode reenviá-las nos detalhes.` : `Solicitação ${result.occurrence.protocolo} registrada com sucesso.`;
    navigate('/solicitacao/'+result.occurrence.id_ocorrencia);
  });
}

async function detailPage(id, signal, tick) {
  if(!/^\d+$/.test(id)) throw new Error('Solicitação não encontrada.');
  const data=await store.occurrenceDetails(id,signal);if(tick!==epoch)return;
  const row=data.occurrence;
  const success=successMessage;successMessage='';
  setContent(`${back(staff()?'/gestao':'/solicitacoes',staff()?'Voltar à gestão':'Voltar às solicitações')}<div class="page-heading detail-heading"><div class="category-symbol">${icon(categoryIcon(categoryFor(row)))}</div><div><p class="eyebrow">Protocolo ${esc(row.protocolo)}</p><h1 tabindex="-1">${esc(row.categoria||'Solicitação')}</h1></div>${statusBadge(row.status_codigo)}</div>${success?notice(success,'success'):''}<div class="grid-2"><div class="stack"><section class="panel"><h2>Sobre o problema</h2><p class="detail-description">${esc(row.descricao)}</p><dl class="meta-grid"><div><dt>Registrada em</dt><dd>${esc(formatDate(row.criado_em,true))}</dd></div><div><dt>Última atualização</dt><dd>${esc(formatDate(row.atualizado_em,true))}</dd></div><div><dt>Localização informada</dt><dd>${row.latitude.toFixed(6)}, ${row.longitude.toFixed(6)}</dd></div><div><dt>Prioridade</dt><dd>${esc(row.prioridade)}</dd></div></dl>${row.status_codigo==='RECEBIDA'?'<button class="button small" id="edit-occurrence">'+icon('edit')+'Editar relato</button>':''}<div id="edit-occurrence-container"></div></section><section class="panel"><h2>Fotos da solicitação</h2><p class="small-text">Acesso restrito ao dono do registro e à gestão.</p><div id="saved-photos" class="photo-grid">${data.photos.length?'<p role="status">Carregando fotos…</p>':'<p class="small-text muted">Nenhuma foto adicionada.</p>'}</div>${data.photos.length<5?`<form id="add-photo-form" class="stack" style="margin-top:18px"><div class="field"><label for="extra-photo">Adicionar foto</label><input id="extra-photo" name="arquivo" type="file" accept="image/jpeg,image/png,image/webp" required><small>JPEG, PNG ou WebP, até 6 MiB e 16 megapixels.</small></div>${fieldsError}<button class="button secondary" type="submit">${icon('camera')}Enviar foto</button></form>`:'<p class="small-text">Limite de cinco fotos atingido.</p>'}</section></div><div class="stack"><section class="panel"><h2>Histórico de atendimento</h2><ol class="timeline">${data.history.map(event=>`<li><h3>${esc(event.status)}</h3><p>${esc(formatDate(event.alterado_em,true))}</p>${event.observacao?`<p>${esc(event.observacao)}</p>`:''}</li>`).join('')}</ol></section><section class="panel"><h2>Equipe e atendimentos</h2>${data.services.length?data.services.map(service=>`<div class="service-row"><h3>${esc(service.equipe)}</h3><p>${service.fim_em?'Concluído em '+esc(formatDate(service.fim_em,true)):'Atendimento em aberto'}</p>${service.observacao?`<p>${esc(service.observacao)}</p>`:''}</div>`).join(''):'<p class="small-text">Nenhum atendimento atribuído até o momento.</p>'}</section></div></div>${staff()?'<section id="management-controls" style="margin-top:24px"></section>':''}`, 'Detalhes da solicitação');
  if(data.photos.length){const urls=[];cleanup.push(()=>urls.forEach(url=>URL.revokeObjectURL(url)));const photos=await Promise.all(data.photos.map(async(photo,index)=>{try{const url=await photoObjectURL(photo.url_arquivo,signal);urls.push(url);return `<figure><a href="${url}" target="_blank" rel="noopener" aria-label="Abrir foto ${index+1} em tamanho maior"><img src="${url}" alt="Foto ${index+1} enviada nesta solicitação"></a><figcaption>Foto ${index+1}</figcaption></figure>`;}catch(error){if(error.name==='AbortError')return '';return `<p class="small-text">Foto ${index+1} indisponível.</p>`;}}));if(tick===epoch)$('#saved-photos').innerHTML=photos.join('');else urls.forEach(url=>URL.revokeObjectURL(url));}
  formHandler($('#add-photo-form'),async()=>{await uploadPhoto(id,$('#extra-photo').files[0]);toast('Foto adicionada.');render();});
  $('#edit-occurrence')?.addEventListener('click',()=>{
    $('#edit-occurrence-container').innerHTML=`<form id="edit-occurrence-form" class="stack" style="margin-top:18px"><div class="field"><label for="edit-description">Descrição</label><textarea id="edit-description" name="descricao" minlength="10" maxlength="2000" required>${esc(row.descricao)}</textarea></div><div class="field"><label for="edit-category">Categoria</label><select id="edit-category" name="id_categoria" required>${opts(store.state.categories,'id_categoria','nome',row.id_categoria)}</select></div>${fieldsError}<button class="button primary" type="submit">Salvar relato</button></form>`;
    formHandler($('#edit-occurrence-form'),async values=>{await api(`/ocorrencias/${id}`,{method:'PATCH',body:{descricao:values.get('descricao'),id_categoria:Number(values.get('id_categoria'))}});toast('Relato atualizado.');render();});$('#edit-description').focus();
  });
  if(staff()&&tick===epoch)await managementControls($('#management-controls'),data,()=>render());
}

async function mapPage(signal,tick){
  const geo=await api('/mapa',{signal});if(tick!==epoch)return;
  setContent(`${title('Mapa de ocorrências','Veja os registros abertos na cidade.')}<form id="map-search-form" class="toolbar"><div class="search-field"><label for="map-search">Buscar categoria ou situação</label>${icon('search')}<input id="map-search" name="busca" placeholder="Ex.: iluminação, recebida" maxlength="120"></div><div class="field filter-select"><label for="map-category">Categoria</label><select id="map-category"><option value="">Todas as categorias</option>${opts(store.state.categories,'nome','nome')}</select></div><button class="button" type="submit">Filtrar</button></form><p class="map-note">A localização pública é aproximada. Relatos completos e fotos são privados.</p><p id="map-network" class="map-note" role="status" hidden></p><div class="map-layout"><section aria-label="Mapa e localização"><div id="public-map" class="main-map"></div><form id="map-location-form" class="map-location-form"><div class="field"><label for="map-latitude">Ir para latitude</label><input id="map-latitude" name="latitude" inputmode="decimal" placeholder="-23.4205" required></div><div class="field"><label for="map-longitude">Ir para longitude</label><input id="map-longitude" name="longitude" inputmode="decimal" placeholder="-51.9333" required></div><button class="button small" type="submit">Localizar ponto</button><button class="icon-button" id="map-geolocation" type="button" aria-label="Centralizar na minha localização">${icon('target')}</button></form><p class="form-error" id="map-location-error" role="alert" hidden></p></section><section aria-label="Lista acessível de ocorrências"><p id="map-count" class="small-text muted" role="status"></p><div id="map-list" class="map-list"></div><div id="map-selection"></div></section></div><div class="actions" style="margin-top:22px">${buttonLink('/nova','Informar um problema','plus')}${store.state.user?buttonLink('/solicitacoes','Minhas solicitações','list',''):buttonLink('/entrar','Entrar na minha conta','user','')}</div>${geo.meta.truncado?notice('O mapa atingiu o limite de 500 registros públicos. A visualização não representa o total de ocorrências.','warning'):''}`, 'Mapa');
  let map;
  const choose=feature=>{const props=feature.properties;map?.focus(props.id_ocorrencia);document.querySelectorAll('.map-item').forEach(item=>item.setAttribute('aria-pressed',String(Number(item.dataset.point)===props.id_ocorrencia)));$('#map-selection').innerHTML=`<div class="panel" style="margin-top:12px"><h2>${esc(props.categoria||'Sem categoria')}</h2>${statusBadge(props.status_codigo)}<p class="small-text" style="margin:12px 0 0">Coordenadas aproximadas: ${feature.geometry.coordinates[1].toFixed(3)}, ${feature.geometry.coordinates[0].toFixed(3)}. Dados pessoais e fotografias não são públicos.</p></div>`;};
  const load=()=>{const term=$('#map-search').value.trim().toLocaleLowerCase('pt-BR'),category=$('#map-category').value;const features=geo.features.filter(f=>(!category||f.properties.categoria===category)&&(!term||`${f.properties.categoria} ${f.properties.status}`.toLocaleLowerCase('pt-BR').includes(term)));map?.destroy();map=createMap($('#public-map'),{features,onSelect:choose});$('#map-count').textContent=`${features.length} registros públicos nesta visualização`;$('#map-selection').replaceChildren();$('#map-list').innerHTML=features.length?features.map(f=>`<button class="map-item" data-point="${f.properties.id_ocorrencia}" aria-pressed="false"><strong>${esc(f.properties.categoria||'Sem categoria')}</strong><small>Localização aproximada · Maringá</small>${statusBadge(f.properties.status_codigo)}</button>`).join(''):empty('Nenhum registro para exibir','Não há ocorrências abertas que correspondam a esta busca.');document.querySelectorAll('[data-point]').forEach(item=>item.addEventListener('click',()=>choose(features.find(f=>f.properties.id_ocorrencia===Number(item.dataset.point)))));};
  $('#map-search-form').addEventListener('submit',e=>{e.preventDefault();load();});$('#map-category').addEventListener('change',load);
  $('#map-location-form').addEventListener('submit',event=>{event.preventDefault();try{const point=parseCoordinates($('#map-latitude').value,$('#map-longitude').value);map.setPoint(point.latitude,point.longitude);$('#map-location-error').hidden=true;}catch(error){$('#map-location-error').textContent=error.message;$('#map-location-error').hidden=false;}});
  attachGeolocation($('#map-geolocation'),(lat,lon)=>map.setPoint(lat,lon));load();cleanup.push(()=>map?.destroy());
}

async function profilePage(){
  const user=store.state.user;
  setContent(`${title('Meu perfil','Sua conta e suas preferências.')}<section class="panel profile-card"><div class="avatar">${icon('user')}</div><div><h2>${esc(user.nome)}</h2><p>Maringá, PR</p></div><a class="button primary" href="#/perfil/dados">${icon('edit')}Editar dados</a></section><div class="profile-sections"><section><div class="section-heading"><h2>Minha conta</h2></div><div class="menu-group">${menu('/perfil/dados','user','Dados pessoais')}${menu('/perfil/seguranca','lock','Segurança da conta')}${menu('/perfil/notificacoes','bell','Notificações')}</div></section><section><div class="section-heading"><h2>Preferências e ajuda</h2></div><div class="menu-group"><button class="menu-row" id="profile-access">${icon('access')}<span>Acessibilidade<small>Tamanho do texto e contraste</small></span>${icon('chevron')}</button>${menu('/ajuda','help','Ajuda e suporte')}${menu('/privacidade','file','Privacidade e informações de uso')}${staff()?menu('/gestao','chart','Painel de gestão'):''}</div></section></div><button class="button profile-logout" id="logout">${icon('logout')}Sair da conta</button>`, 'Perfil');
  $('#profile-access').addEventListener('click',openAccessibility);$('#logout').addEventListener('click',async event=>{event.currentTarget.disabled=true;try{await store.logout();navigate('/entrada');toast('Você saiu da conta.');}catch(error){event.currentTarget.disabled=false;toast(error.message);}});
}
function menu(path,name,label){return `<a class="menu-row" href="#${path}">${icon(name)}<span>${label}</span>${icon('chevron')}</a>`;}

async function profileSubpage(section){
  const heading={dados:'Dados pessoais',seguranca:'Segurança da conta',notificacoes:'Notificações'}[section];
  if(!heading)throw new Error('Página não encontrada.');
  let body='';
  if(section==='dados')body=`<div class="field"><label for="profile-name">Nome completo</label><input id="profile-name" name="nome" value="${esc(store.state.user.nome)}" minlength="2" maxlength="120" autocomplete="name" required></div><div class="field"><label for="profile-email">E-mail da conta</label><input id="profile-email" type="email" value="${esc(store.state.user.email)}" disabled><small>A edição de e-mail não está disponível nesta versão.</small></div>`;
  if(section==='seguranca')body=passwordField('senha_atual','Senha atual','current-password')+passwordField('nova_senha','Nova senha','new-password',10)+passwordField('confirmacao','Confirmar nova senha','new-password',10)+'<p class="small-text">Ao alterar a senha, todas as sessões serão encerradas. Use de 10 a 128 caracteres.</p>';
  if(section==='notificacoes')body=`<label class="check"><input type="checkbox" name="notificacoes" ${store.state.preferences?.notificacoes?'checked':''}>Receber avisos de atualizações quando disponíveis</label>${notice('Sua preferência é salva. Esta versão não envia e-mails nem notificações push; consulte as atualizações em Solicitações.')}`;
  setContent(`${back('/perfil','Voltar ao perfil')}${title(heading,'Mantenha sua conta do seu jeito.')}<section class="panel" style="max-width:620px"><form id="profile-form" class="stack">${body}${fieldsError}<button class="button primary" type="submit">Salvar alterações</button></form></section>`,heading);
  const form=$('#profile-form');formHandler(form,async values=>{if(section==='dados'){await store.saveProfile(values.get('nome'));toast('Dados atualizados.');navigate('/perfil');}else if(section==='notificacoes'){await store.savePreferences({notificacoes:values.has('notificacoes')});toast('Preferência salva.');}else{if(values.get('nova_senha')!==values.get('confirmacao'))throw new Error('As novas senhas não coincidem.');await api('/perfil/senha',{method:'PUT',body:{senha_atual:values.get('senha_atual'),nova_senha:values.get('nova_senha')}});setSession(null);store.state.user=null;store.state.preferences=null;form.reset();navigate('/entrar');toast('Senha alterada. Entre novamente.');}});
}

async function infoPage(privacy){
  setContent(`${back(store.state.user?'/perfil':'/entrada')}${title(privacy?'Privacidade e informações de uso':'Ajuda e suporte',privacy?'Saiba como seus dados são usados nesta versão.':'Um guia rápido para usar o Radar Urbano.')}<article class="panel legal">${privacy?'<h2>Um projeto acadêmico local</h2><p>O Radar Urbano foi desenvolvido para registrar e acompanhar problemas urbanos em ambiente acadêmico. Ele não substitui os canais oficiais da prefeitura e não encaminha registros para órgãos externos.</p><h2>Dados da sua conta</h2><p>Nome, e-mail, senha protegida por hash, preferências e solicitações são armazenados no banco local. A sessão fica restrita à aba do navegador e pode ser encerrada em Perfil.</p><h2>Informações do mapa</h2><p>O mapa público exibe categoria, situação e localização aproximada das ocorrências abertas. Não revela nome, e-mail, descrição livre ou fotos privadas. A base de ruas OpenStreetMap precisa de internet; seu provedor recebe as requisições dos blocos do mapa.</p><h2>Suas fotografias</h2><p>As imagens são privadas e passam por validação e remoção de metadados. Não envie imagens de documentos ou dados pessoais desnecessários. Nome e e-mail não podem ser alterados por outras pessoas.</p><h2>Atendimento e privacidade</h2><p>Para questões sobre os dados deste ambiente, procure o responsável local pelo projeto. Não há envio de notificações por e-mail nem integração com serviços de IA nesta versão.</p>':'<h2>Como registrar um problema</h2><ol><li>Crie uma conta e entre no sistema.</li><li>Selecione Informar um problema.</li><li>Escolha a categoria e descreva a situação.</li><li>Informe o local no mapa ou por coordenadas. Fotos são opcionais.</li><li>Envie e guarde o protocolo apresentado.</li></ol><h2>Acompanhar o atendimento</h2><p>Em Solicitações, use o protocolo, uma palavra do relato ou o filtro de situação. Nos detalhes, consulte histórico, fotos e equipe. O relato pode ser editado enquanto estiver no status Recebida.</p><h2>Mapa e acessibilidade</h2><p>O mapa público tem uma lista alternativa de registros e controles de zoom. Você pode preencher coordenadas sem usar o mouse. O botão de acessibilidade no cabeçalho permite ajustar contraste e tamanho do texto.</p><h2>Não consegui entrar</h2><p>Confira seu e-mail e senha. Se ainda não tiver conta, use Criar conta. A recuperação de senha por e-mail não está disponível; para um problema de acesso, procure o responsável local pelo projeto.</p>'}</article>`,privacy?'Privacidade':'Ajuda');
}

async function render(){
  controller?.abort();cleanup.forEach(fn=>fn());cleanup=[];controller=new AbortController();const signal=controller.signal,tick=++epoch;
  let path=currentPath();
  const publicRoutes=['/entrada','/entrar','/cadastro','/mapa','/ajuda','/privacidade'];
  if(!store.state.user&&!publicRoutes.includes(path)){pendingRoute=path;path='/entrar';location.hash=path;return;}
  if(path.startsWith('/gestao')&&!staff()){path='/inicio';location.hash=path;return;}
  shell(path);window.scrollTo({top:0,behavior:'instant'});
  try{
    if(store.state.user&&!store.state.categories.length || path==='/mapa')await store.catalogs(signal);
    if(tick!==epoch)return;
    if(path==='/entrada')await entry();
    else if(path==='/entrar'||path==='/cadastro')await authPage(path==='/cadastro');
    else if(path==='/inicio')await home(signal,tick);
    else if(path==='/solicitacoes')await requestsPage(signal,tick);
    else if(path==='/nova')await newOccurrence();
    else if(path.startsWith('/solicitacao/'))await detailPage(path.split('/')[2],signal,tick);
    else if(path==='/mapa')await mapPage(signal,tick);
    else if(path==='/perfil')await profilePage();
    else if(path.startsWith('/perfil/'))await profileSubpage(path.split('/')[2]);
    else if(path==='/ajuda'||path==='/privacidade')await infoPage(path==='/privacidade');
    else if(path.startsWith('/gestao'))await managementPage({path,signal,tick,isCurrent:()=>tick===epoch,setContent,title,navigate,card});
    else setContent(`${title('Página não encontrada','Esse endereço não corresponde a uma tela do Radar Urbano.')}${buttonLink('/inicio','Voltar ao início','home')}`,'Página não encontrada');
  }catch(error){if(error.name==='AbortError'||tick!==epoch)return;setContent(`${title('Não foi possível abrir esta página',error.status===404?'O registro não existe ou não está disponível para sua conta.':error.message)}<div class="actions"><button class="button primary" id="retry-page">Tentar novamente</button>${buttonLink(store.state.user?'/inicio':'/entrada','Voltar ao início','home','')}</div>`,'Não foi possível carregar');$('#retry-page').addEventListener('click',render);}
}

$('#accessibility [data-close-dialog]').addEventListener('click',()=>$('#accessibility').close());
$('.skip-link').addEventListener('click',event=>{event.preventDefault();const main=$('#conteudo');main?.focus();main?.scrollIntoView({block:'start'});});
formHandler($('#access-form'),async data=>{const values={alto_contraste:data.has('alto_contraste'),tamanho_texto:data.get('tamanho_texto')};if(store.state.user)await store.savePreferences(values);applyPreferences(values);$('#accessibility').close();toast('Preferências de acessibilidade atualizadas.');});
window.addEventListener('radar:session-expired',()=>{store.state.user=null;store.state.preferences=null;toast('Sua sessão expirou. Entre novamente.');navigate('/entrar');});
window.addEventListener('hashchange',render);
try{const local=JSON.parse(localStorage.getItem('radar-accessibility')||'null');if(local)applyPreferences(local);}catch{}
try{if(await store.initializeSession())applyPreferences(store.state.preferences);}catch(error){toast(error.message);}
await render();
