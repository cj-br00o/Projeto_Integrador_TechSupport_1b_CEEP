export const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[char]));
const paths = {
 home:'<path d="m3 10 9-7 9 7v11h-6v-7H9v7H3Z"/>',
 pin:'<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
 list:'<rect x="4" y="2" width="16" height="20" rx="3"/><path d="M10 7h6M10 12h6M10 17h6M7 7h.01M7 12h.01M7 17h.01"/>',
 user:'<circle cx="12" cy="7" r="4"/><path d="M3 22v-2a9 9 0 0 1 18 0v2Z"/>',
 bell:'<path d="M5 9a7 7 0 0 1 14 0c0 8 3 8 3 9H2c0-1 3-1 3-9ZM10 22h4"/>',
 access:'<circle cx="12" cy="3" r="2"/><path d="m3 7 9 2 9-2M12 9v6m0-2-5 9m5-9 5 9"/>',
 camera:'<path d="M3 7h4l2-4h6l2 4h4v14H3Z"/><circle cx="12" cy="13" r="4"/>',
 chevron:'<path d="m9 4 8 8-8 8"/>',
 plus:'<path d="M12 3v18M3 12h18"/>',
 search:'<circle cx="10" cy="10" r="7"/><path d="m15 15 7 7"/>',
 lamp:'<path d="M4 22h10M8 22V8l10-5 3 3-9 5M18 12l1 3m3-6 2 1"/>',
 road:'<path d="M7 2h10l5 20H2L7 2Z"/><path d="M12 4v4m0 4v5"/>',
 bin:'<path d="M3 6h18M9 6V2h6v4M5 6l1 16h12l1-16M10 10v8m4-8v8"/>',
 tree:'<path d="m12 2 7 9h-3l5 7H3l5-7H5l7-9ZM12 18v5"/>',
 drop:'<path d="M12 2S4 11 4 16a8 8 0 0 0 16 0c0-5-8-14-8-14Z"/>',
 lock:'<rect x="4" y="10" width="16" height="12" rx="2"/><path d="M7 10V7a5 5 0 0 1 10 0v3m-5 5v3"/>',
 logout:'<path d="M10 3H3v18h7m5-15 6 6-6 6m-7-6h13"/>',
 edit:'<path d="m15 3 6 6-12 12H3v-6L15 3Zm-2 2 6 6"/>',
 info:'<circle cx="12" cy="12" r="10"/><path d="M12 11v7m0-12v1"/>',
 check:'<path d="m4 12 5 5L20 6"/>',
 target:'<circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2"/><path d="M12 1v4m0 14v4M1 12h4m14 0h4"/>',
 shield:'<path d="m12 2 9 4v6c0 6-9 10-9 10S3 18 3 12V6l9-4Z"/><path d="m8 12 3 3 5-6"/>',
 chart:'<path d="M3 3v19h19M8 17v-5m5 5V7m5 10V4"/>',
 team:'<circle cx="9" cy="7" r="4"/><path d="M2 22v-3a7 7 0 0 1 14 0v3m2-18a4 4 0 0 1 0 8m2 3a7 7 0 0 1 2 7"/>',
 help:'<circle cx="12" cy="12" r="10"/><path d="M9 8a3 3 0 0 1 6 1c0 3-3 2-3 6m0 3v1"/>',
 file:'<path d="M5 2h9l5 5v15H5V2Zm9 0v6h5M8 12h8m-8 4h8"/>'
};
export function icon(name, cls = '') {
  return `<svg class="icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.pin}</svg>`;
}
export function categoryIcon(code) {
  return ({ILUMINACAO:'lamp',INFRAESTRUTURA:'road',TRANSITO:'road',LIMPEZA_URBANA:'bin',ARBORIZACAO:'tree',DRENAGEM:'drop',SANEAMENTO:'drop'})[code] || 'pin';
}
export function statusBadge(code, label) {
  return `<span class="badge status-${esc(code)}">${esc(label || ({RESOLVIDA:'Concluída',RECEBIDA:'Recebida',EM_ANALISE:'Em análise',ENCAMINHADA:'Encaminhada',EM_ATENDIMENTO:'Em atendimento'})[code] || code)}</span>`;
}
export function notice(text, type = 'info') { return `<div class="notice ${type}">${icon(type === 'success' ? 'check' : 'info')}<p>${esc(text)}</p></div>`; }
export function empty(title, text, action = '') {
  return `<div class="empty">${icon('list')}<h2>${esc(title)}</h2><p>${esc(text)}</p>${action}</div>`;
}
let timer;
export function toast(message) {
  const box = document.querySelector('#toast');
  box.textContent = message; box.hidden = false;
  clearTimeout(timer); timer = setTimeout(() => { box.hidden = true; }, 6500);
}
export function formError(form, error) {
  const box = form.querySelector('.form-error');
  if (!box) { toast(error.message); return; }
  box.textContent = [error.message, ...(error.fields || []).map(item => `${item.campo.split('.').at(-1)}: ${item.mensagem}`)].join(' ');
  box.hidden = false; box.tabIndex = -1; box.focus();
}
export function formHandler(form, handler) {
  form?.addEventListener('submit', async event => {
    event.preventDefault();
    const button = form.querySelector('[type="submit"]');
    if (button?.disabled) return;
    const error = form.querySelector('.form-error'); if (error) error.hidden = true;
    const label = button?.innerHTML;
    if (button) { button.disabled = true; button.textContent = 'Salvando…'; }
    form.setAttribute('aria-busy', 'true');
    try { await handler(new FormData(form)); }
    catch (err) { if (err.name !== 'AbortError') formError(form, err); }
    finally { if (button) { button.disabled = false; button.innerHTML = label; } form.removeAttribute('aria-busy'); }
  });
}
