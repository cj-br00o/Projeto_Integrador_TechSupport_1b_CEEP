// Contrato HTTP único. Não registra senhas, tokens nem corpos privados em logs.
const SESSION_KEY = 'radar-urbano.session';
let token = null;

export class ApiError extends Error {
  constructor(message, status = 0, fields = []) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.fields = fields;
  }
}

function storage() {
  try { return window.sessionStorage; } catch { return null; }
}

export function setSession(value) {
  token = value || null;
  // Uma aba mantém sua sessão após recarregar. Nada é salvo no localStorage.
  try {
    if (token) storage()?.setItem(SESSION_KEY, token);
    else storage()?.removeItem(SESSION_KEY);
  } catch { /* Navegação segue com sessão somente em memória. */ }
}

export function restoreSession() {
  try { token = storage()?.getItem(SESSION_KEY) || null; } catch { token = null; }
  return Boolean(token);
}

export function hasSession() { return Boolean(token); }

async function send(path, {method = 'GET', body, signal, binary = false, auth = true} = {}) {
  if (!path.startsWith('/api/v1/') || path.startsWith('//')) {
    throw new ApiError('Endereço de API inválido.');
  }
  const headers = new Headers({Accept: binary ? 'image/*' : 'application/json'});
  if (token && auth) headers.set('Authorization', `Bearer ${token}`);
  if (body !== undefined && !(body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
    body = JSON.stringify(body);
  }
  let response;
  try {
    response = await fetch(path, {method, headers, body, signal, cache: 'no-store', credentials: 'omit'});
  } catch (error) {
    if (error.name === 'AbortError') throw error;
    throw new ApiError('Não foi possível conectar ao sistema. Confira a conexão e tente novamente.');
  }
  if (response.status === 204) return null;
  const json = response.headers.get('content-type')?.includes('application/json');
  const data = json ? await response.json() : null;
  if (!response.ok) {
    const detail = data?.erro;
    if (response.status === 401 && auth && token) {
      setSession(null);
      window.dispatchEvent(new Event('radar:session-expired'));
    }
    throw new ApiError(detail?.mensagem || 'Não foi possível concluir a operação.', response.status, detail?.campos || []);
  }
  return binary ? await response.blob() : data;
}

const route = path => '/api/v1' + path;
export const api = (path, options) => send(route(path), options);

export async function login(email, senha) {
  const response = await api('/auth/login', {method: 'POST', body: {email, senha}, auth: false});
  setSession(response.dados.access_token);
  return response.dados.usuario;
}

export async function logout() {
  // Se a rede falhar, manter o token permite repetir a revogação no servidor.
  if (token) await api('/auth/logout', {method: 'POST'});
  setSession(null);
}

export async function allPages(path, signal) {
  const separator = path.includes('?') ? '&' : '?';
  const rows = [];
  let page = 1;
  while (true) {
    const response = await api(`${path}${separator}pagina=${page}&limite=100`, {signal});
    rows.push(...response.dados);
    if (!response.paginacao || rows.length >= response.paginacao.total || !response.dados.length) return rows;
    page += 1;
  }
}

export async function uploadPhoto(occurrenceId, file) {
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
    throw new ApiError('Selecione uma foto JPEG, PNG ou WebP.');
  }
  if (file.size > 6 * 1024 * 1024) throw new ApiError('Cada foto deve ter até 6 MiB.');
  const body = new FormData();
  body.append('arquivo', file);
  return api(`/ocorrencias/${occurrenceId}/fotos`, {method: 'POST', body});
}

export async function photoObjectURL(path, signal) {
  if (!/^\/api\/v1\/fotos\/\d+\/arquivo(?:\?|$)/.test(path)) throw new ApiError('Referência de foto inválida.');
  return URL.createObjectURL(await send(path, {binary: true, signal}));
}
