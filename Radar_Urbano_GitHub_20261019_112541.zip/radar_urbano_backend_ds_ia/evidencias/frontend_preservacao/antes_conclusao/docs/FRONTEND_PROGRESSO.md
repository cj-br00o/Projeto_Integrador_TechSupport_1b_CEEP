# Preparação funcional do frontend

A implementação visual aguarda as imagens de referência por instrução do usuário.
Nenhuma paleta, composição ou aparência das telas foi definida nesta etapa.

Foram preservadas as interfaces anteriores em Radar_Urbano_Pacote_Definitivo/frontend.
Os arquivos existentes envolvidos na integração foram copiados, com SHA256, em evidencias/frontend_preservacao.

O cliente novo em frontend/js contém:

- api.js: requisições HTTP, validação de erro, sessão da aba, paginação de catálogos e fotos privadas;
- store.js: cadastro/login, perfil/preferências, solicitações, fotos, histórico e atendimentos;
- domain.js: datas no fuso de São Paulo, indicadores operacionais, coordenadas e limites de fotos.

main.py entrega os módulos em /assets e está preparado para servir frontend/index.html na raiz,
assim que a interface for implementada. Enquanto esse arquivo não existe, a raiz continua com o diagnóstico JSON anterior.
Não há uma interface utilizável entregue nesta etapa.

O comando da raiz `bash iniciar_radar.sh` prepara PostgreSQL e reinicia somente a API deste projeto;
o frontend será servido pelo mesmo Uvicorn, na mesma origem, sem segundo servidor ou npm em produção.
O comando foi executado com sucesso neste notebook; a interface final ainda aguarda as telas.

## Validação realizada

Os módulos reais foram executados em Chrome headless isolado, usando PostgreSQL descartável:
cadastro, login, criação e consulta de ocorrência, categoria legível, histórico, edição de nome,
preferências persistidas, restauração da sessão após recarregar e logout com revogação.
Evidências reais em evidencias/frontend_cliente_*; nenhuma senha, token, vídeo ou trace foi salvo.
O banco de teste foi removido. O banco operacional e os dados pessoais não foram usados para esses cadastros.

Os 44 testes anteriores do backend passaram após montar os estáticos.
Os dois testes adicionais de entrega de JavaScript e bloqueio de acesso a .env e diretórios privados também passaram.
Os testes de navegador não representam validação visual, acessibilidade ou navegação das telas ainda ausentes.

Para repetir o teste de integração do cliente neste notebook:

```bash
npm ci --cache /tmp/radar-npm-cache
.venv/bin/python scripts/testar_cliente_web.py
```

As dependências de desenvolvimento são locais ao projeto e ficam fixadas em package-lock.json.
Não houve alteração no GitHub, Classroom ou Supabase.
