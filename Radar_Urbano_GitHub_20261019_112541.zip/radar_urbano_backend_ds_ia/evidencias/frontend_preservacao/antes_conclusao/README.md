# Radar Urbano — backend local

**Frontend em preparação:** cliente JavaScript e integração com PostgreSQL foram preparados e testados.
A composição visual e as telas aguardam as imagens de referência, conforme solicitado.
O teste do cliente em Chrome isolado está em `scripts/testar_cliente_web.py`; ainda não substitui o teste do fluxo pelas telas.

Backend revisado neste notebook em 19/10/2026, com FastAPI, SQLAlchemy, Pydantic, Uvicorn e Pandas.
Uma aplicação principal em main.py; banco operacional PostgreSQL local exclusivo e análise de CSV acadêmico independente.
As versões antigas do projeto foram preservadas. Detalhes e evidências em [docs/REVISAO_NOTEBOOK.md](docs/REVISAO_NOTEBOOK.md).

## Iniciar e retomar neste Linux

Abra um terminal nesta pasta:

```bash
bash iniciar.sh
```

Esse comando inicia o PostgreSQL privado se necessário e executa Uvicorn em primeiro plano.
Abra http://127.0.0.1:8000/docs. **Ctrl+C** encerra a API; o PostgreSQL e os dados permanecem.
Para retomar, repita `bash iniciar.sh`. Não reinstale as dependências a cada execução.

A API foi deixada em segundo plano ao concluir a preparação. Use, nesse caso:

```bash
.venv/bin/python scripts/api_local.py status
.venv/bin/python scripts/api_local.py parar
.venv/bin/python scripts/api_local.py iniciar
.venv/bin/python scripts/api_local.py reiniciar
```

Não execute dois servidores na porta 8000. Para trocar ao modo de primeiro plano, use `api_local.py parar` antes de `bash iniciar.sh`.
O controle de processo verifica PID, diretório e comando antes de encerrar o Uvicorn deste projeto.
O log da API principal fica em instance/uvicorn.log, fora do versionamento e do pacote.

```bash
bash postgres.sh status
bash postgres.sh parar
bash postgres.sh iniciar
```

Pare a API antes de parar o banco. O cluster é privado, em instance/pgdata, porta 55432;
nenhum serviço PostgreSQL antigo ou banco pessoal é utilizado.

Para trabalhar no terminal com ambiente ativado:

```bash
source .venv/bin/activate
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
# Ctrl+C para encerrar o servidor; depois:
deactivate
```

`deactivate` afeta somente o terminal e não apaga .venv nem dados.
Os scripts usam diretamente .venv/bin/python, sem necessidade de ativação manual.
No VS Code, abra Radar_Urbano.code-workspace; ele configura o interpretador desta pasta e o depurador.
O workspace antigo da pasta superior apontava para outra .venv e foi preservado.

## Testar e revisar evidências

```bash
bash testar.sh
```

A suíte pytest usa SQLite temporário. O segundo comando do script usa PostgreSQL em banco descartável
radar_test_* criado no cluster privado; não grava os cadastros de teste no banco operacional.
Verifica PK, FK, nomes relacionados, cadastro/login, permissões, validações, duplicações, fotos privadas,
fluxo administrativo, CORS, requisições simultâneas e persistência após reiniciar Uvicorn.
Gera uma pasta nova evidencias/notebook_http_* a cada execução, com respostas JSON sem senhas ou tokens.
O banco descartável é removido ao final. Os registros são fictícios.

44 testes automatizados em SQLite e 63 requisições HTTP em PostgreSQL passaram, além das verificações de concorrência e CORS.
O erro SMALLINT encontrado na primeira execução HTTP foi corrigido e a execução falha permanece registrada.
A documentação Swagger respondeu por HTTP; Postman e a interface visual do navegador não foram executados.
A coleção Postman está pronta para importar, com variáveis de senha e token vazias.
As evidências herdadas do ZIP, fora das pastas notebook*, pertencem a execuções anteriores.

## Conta e uso da API

O banco operacional inicia somente com categorias e status. Não existem contas nem senhas padrão.
Cadastre um cidadão em POST /api/v1/auth/cadastro; login em POST /api/v1/auth/login retorna dados.access_token.
Use Authorize no Swagger para rotas privadas. O servidor determina dono, status e prioridade da ocorrência.
O cidadão não escolhe perfil administrativo e só acessa seus registros privados.
Para criar um gestor local com senha escolhida por você, em terminal:

```bash
.venv/bin/python gerenciar.py criar-gestor
```

Esse comando é interativo e não imprime a senha. Só o gestor pode cadastrar categorias/equipes e administrar atendimentos/status.
POST e GET /api/v1/categorias demonstram PK; POST/GET /api/v1/ocorrencias demonstram FK e nomes legíveis.
Categorias, ocorrências, equipes, usuários, histórico, análises registradas e atendimentos têm paginação.
Fotos privadas validam conteúdo e limites e removem metadados EXIF. O mapa público usa localização aproximada.

## Ciência de dados e integração futura

GET /api/v1/analise/resumo, /categorias, /datas e /qualidade leem exclusivamente database/ocorrencias.csv.
São 20 ocorrências sintéticas acadêmicas, não dados reais da prefeitura. Não há modelo Ollama em execução.
Amostra: 5 urgentes (25%); soma dos intervalos até análise 20 minutos, média e mediana 1 minuto.
Fotos referenciadas não significam fotos totais; eventos de histórico não estão na fonte.
Não se calcula custo nem tempo de resolução sem os campos necessários.

[docs/ANALISE.md](docs/ANALISE.md) contém dicionário, unidades, denominadores e limitações.
[docs/FRONTEND.md](docs/FRONTEND.md) mapeia Início, Mapa, Solicitações e Perfil às rotas e fornece fetch, erros e upload.
As telas desenhadas são referências; frontend e envio de notificações não foram implementados aqui.
Indicadores do banco operacional ficam em /api/v1/indicadores e /painel/cidadao e são separados da amostra CSV.
[docs/openapi.json](docs/openapi.json) é o contrato exportado da aplicação.

## Reproduzir em outra pasta limpa

```bash
python3 preparar.py
bash iniciar.sh
```

preparar.py cria .venv, instala requirements-lock.txt sem alterar Python global e preserva .env existente.
Em uma pasta nova, usa SQLite por padrão com FKs ativas; registrações persistem em instance/radar.db.
PostgreSQL no notebook foi preparado em cluster novo com os binários oficiais Ubuntu já instalados;
para outra máquina, veja docs/REVISAO_NOTEBOOK.md ou configure um banco PostgreSQL local novo.
Nunca copie o .env antigo nem credenciais de terceiros. O código bloqueia bancos remotos.
SQLite não aplica todos os tipos/bloqueios do PostgreSQL: use os testes PostgreSQL para validar concorrência.

requirements-lock.txt fixa todas as versões efetivamente instaladas; `python -m pip check` valida compatibilidade.
Para um novo pacote sem .env/.venv/bancos/contas privadas:

```bash
.venv/bin/python scripts/empacotar.py
```

O ZIP fica em ../entrega_local, com manifesto SHA256. Não inclui histórico Git antigo nem bancos.
As nove tabelas originais e seus campos/códigos foram preservados. As extensões credencial_local,
sessao_local e preferencia_local são justificadas em docs/REVISAO_NOTEBOOK.md e DICIONARIO_BANCO.md.
Não foram alterados GitHub, Classroom ou Supabase; não há push ou nova configuração remota.

## Pendências concretas

Capturas visuais de /docs e execução manual da coleção Postman permanecem pendentes:
a ferramenta de interface não disponibilizou navegador ou aplicativos neste ambiente.
O Google Docs de referência exigiu login; os dois guias DOCX e o exemplo público da biblioteca foram lidos.
Os guias DS e IA não foram preenchidos. Para produção ainda seriam necessários migrações,
HTTPS, política de acesso por equipe e revisão dos limites distribuídos de autenticação.
