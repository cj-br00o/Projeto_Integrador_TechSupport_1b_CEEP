# Backend local ativo do Radar Urbano

A versão revisada está em [radar_urbano_backend_ds_ia](radar_urbano_backend_ds_ia/README.md).
As demais pastas foram preservadas como versões anteriores.

```bash
cd radar_urbano_backend_ds_ia
bash iniciar.sh
```

Documentação: http://127.0.0.1:8000/docs.
Se a API já estiver em segundo plano, veja os comandos iniciar/parar/reiniciar no README da versão revisada.
