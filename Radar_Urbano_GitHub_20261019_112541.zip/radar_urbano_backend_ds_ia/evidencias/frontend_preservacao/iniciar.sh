#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [ -d instance/pgdata ]; then bash postgres.sh iniciar; fi
exec .venv/bin/python -m uvicorn main:app --host 127.0.0.1 --port 8000 "$@"
