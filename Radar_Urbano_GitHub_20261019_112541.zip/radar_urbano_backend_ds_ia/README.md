# Radar Urbano — sistema local

Frontend e backend integrados para cidadãos e gestão, com dados persistidos no PostgreSQL exclusivo deste notebook.
A interface segue as quatro referências fornecidas: verde, azul escuro, cartões claros, mapa e navegação inferior no celular.
A gestão utiliza a mesma identidade com filtros, indicadores operacionais e tabelas.

## Abrir o sistema

Na pasta superior do projeto:

```bash
bash iniciar_radar.sh
```

Ou, nesta pasta:

```bash
bash iniciar_sistema.sh
```

Abra **http://127.0.0.1:8000/**. A documentação da API continua em http://127.0.0.1:8000/docs.
O comando inicia o PostgreSQL privado, confere o banco e reinicia somente o Uvicorn deste projeto.
Frontend e API são servidos juntos, na mesma origem. Não é necessário npm para usar o sistema.
Os arquivos Leaflet são locais; somente a base de ruas OpenStreetMap requer internet.

O servidor fica em segundo plano. Para parar ou consultar:

```bash
.venv/bin/python scripts/api_local.py parar
.venv/bin/python scripts/api_local.py status
```

Para retomar, use novamente `bash iniciar_sistema.sh`. Não reinstale as dependências a cada uso.
Para trabalhar em primeiro plano, pare antes o processo em segundo plano e execute `bash iniciar.sh`.
Nesse modo, **Ctrl+C** encerra o servidor; se ativou a .venv manualmente, `deactivate` desativa o ambiente no terminal.
Nenhuma dessas ações apaga os dados. `bash postgres.sh parar` encerra o banco privado; pare a API antes.

## Conta do cidadão

Na entrada, use **Criar minha conta**, depois faça login. Não há conta nem senha padrão.
Você pode usar Início, Mapa, Solicitações e Perfil, registrar problemas com fotos, consultar o histórico e editar seu relato enquanto estiver Recebida.
A sessão da aba é restaurada ao recarregar e validada no servidor. Sair da conta revoga o token.
Nome, preferências, credenciais protegidas, solicitações e fotos usam o banco/armazenamento local.
Não há registros fictícios pré-carregados na interface: estados vazios correspondem ao banco real.

O mapa público tem filtro por categoria e situação, zoom, localização e lista acessível alternativa.
Ele não mostra descrições nem fotos de outros cidadãos; coordenadas públicas são aproximadas.
A busca não geocodifica ruas/bairros: esses campos não existem no contrato atual.
O botão de localização solicita autorização ao navegador. O formulário também funciona com coordenadas digitadas, sem GPS.

## Gestão municipal

Para criar seu administrador local com nome, e-mail e senha escolhidos por você:

```bash
.venv/bin/python gerenciar.py criar-gestor
```

Entre pela mesma tela de login. Contas ADMINISTRADOR/PREFEITURA acessam a **Central de gestão**.
Nela é possível consultar a operação, filtrar solicitações, cadastrar categorias/equipes, definir prioridade,
alterar status, atribuir equipes e concluir atendimentos. As permissões continuam sendo verificadas pelo backend.
A criação pública de conta continua restrita a CIDADAO; não há botão para escolher perfil administrativo.

## Acessibilidade e privacidade

Há labels de formulários, foco visível, link para pular ao conteúdo, navegação por teclado, mensagens de erro,
contraste ajustado, tamanho de texto e modo de alto contraste persistidos em preferencia_local.
A aplicação se adapta a celular e desktop, incluindo largura de 320 px.
Fotos privadas são obtidas com autorização e exibidas por URLs Blob, revogadas ao trocar de tela.
Conteúdo de relatos e nomes é escapado antes de entrar no HTML; scripts externos são bloqueados por CSP.
A preferência de notificações é salva, mas não existe envio de e-mail ou push nesta versão.
O sino leva às solicitações; não inventa alertas ou contagens de notificações não lidas.

## Testar

```bash
npm ci --cache /tmp/radar-npm-cache
npm run test:unit
.venv/bin/python -m pytest -q
.venv/bin/python scripts/testar_cliente_web.py
```

Node/npm são necessários apenas para testes/desenvolvimento; as versões ficam em package-lock.json.
O roteiro de navegador usa Chrome headless isolado e banco PostgreSQL descartável radar_test_web_*.
Não usa seu perfil pessoal do Chrome nem grava cadastros de teste no banco operacional.
Testa as telas, fotos, filtros, gestão, permissões, senha, teclado, acessibilidade, reflow e restauração da sessão.
Também registra pela interface, reinicia a API e consulta novamente conta, ocorrência, histórico e foto.
Senhas e tokens não são gravados nas capturas, vídeos ou traces. As contas de teste são fictícias.
As evidências de cada execução ficam em evidencias/frontend_cliente_*, sem sobrescrever as anteriores.
A avaliação automática de acessibilidade cobre as telas indicadas nos arquivos axe-*.json; ela não substitui a avaliação humana.

O roteiro anterior de 63 requisições HTTP e concorrência continua em scripts/validar_notebook.py.
As evidências copiadas do ZIP original são históricas; as pastas notebook* e frontend_cliente_* identificam execuções neste notebook.

## Estrutura e reprodução

- frontend/index.html, styles.css e js/: telas, cliente HTTP, estado, mapa, gestão e utilitários.
- main.py: uma aplicação FastAPI com API /api/v1 e arquivos estáticos /assets.
- database.py, models.py, schemas.py, routes/: backend autoral preservado.
- analise.py e database/ocorrencias.csv: análise independente da amostra acadêmica, sem consulta ao banco.
- docs/FRONTEND.md e docs/FRONTEND_PROGRESSO.md: contratos, telas, decisões e validação.

A amostra CSV contém 20 ocorrências sintéticas acadêmicas, separadas dos indicadores do banco operacional.
Não há Ollama em execução e a interface não apresenta a amostra como ocorrências reais da cidade.
As nove tabelas originais e seus campos/códigos foram preservados; não houve nova tabela nesta etapa.

Para reproduzir o ambiente Python em uma pasta nova, use `python3 preparar.py`.
Esse preparo preserva .env existente e usa requirements-lock.txt; em uma pasta limpa, adota SQLite com FKs ativas.
O PostgreSQL privado deste notebook fica em instance/pgdata, porta 55432, sem alterar o cluster anterior na porta 5432.
Credenciais novas ficam somente no .env local, com permissão 600. Não copie credenciais antigas ou de terceiros.
O backend bloqueia conexões remotas. SQLite continua disponível para desenvolvimento, com diferenças documentadas de tipos e concorrência.

Para gerar uma entrega sem .env, .venv, node_modules ou bancos:

```bash
.venv/bin/python scripts/empacotar.py
```

Os arquivos anteriores e os originais fornecidos foram preservados; comparações ficam em evidencias/frontend_preservacao.
Não houve push, configuração de remote, alteração no GitHub, Classroom ou Supabase.

## Limites atuais

Não há encaminhamento a órgãos públicos, recuperação de senha por e-mail, geocodificação de endereços, push ou IA generativa.
O perfil EQUIPE ainda precisa de uma política de associação usuário/equipe antes de receber acesso próprio.
O Google Docs de referência exigiu login; os guias DOCX foram consultados sem serem preenchidos.
Este é um ambiente acadêmico local, não um canal oficial da prefeitura.
