"""Schemas Pydantic: contrato e validação de entrada/saída para o frontend."""
from datetime import datetime
from typing import Annotated, Literal
import re
from pydantic import BaseModel, ConfigDict, Field, StringConstraints, field_validator

Name = Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=120)]
Description = Annotated[str, StringConstraints(strip_whitespace=True, min_length=10, max_length=2000)]
Priority = Literal['BAIXA', 'MEDIA', 'ALTA', 'CRITICA']
StatusCode = Literal['RECEBIDA', 'EM_ANALISE', 'ENCAMINHADA', 'EM_ATENDIMENTO', 'RESOLVIDA']
PositiveID = Annotated[int, Field(strict=True, gt=0)]


class Schema(BaseModel):
    model_config = ConfigDict(extra='forbid', from_attributes=True, allow_inf_nan=False)


class ErroDetalhes(Schema):
    mensagem: str
    campos: list[dict[str, str]] | None = None


class ErroResponse(Schema):
    erro: ErroDetalhes


class EmailSchema(Schema):
    email: str = Field(min_length=5, max_length=160)

    @field_validator('email')
    @classmethod
    def validate_email(cls, value):
        value = value.strip().lower()
        if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', value):
            raise ValueError('E-mail inválido.')
        return value


class Cadastro(EmailSchema):
    nome: Name
    senha: str = Field(min_length=10, max_length=128)


class Login(EmailSchema):
    senha: str = Field(min_length=1, max_length=128)


class UsuarioResponse(Schema):
    id_usuario: int
    nome: str
    email: str
    perfil: str
    ativo: bool
    criado_em: datetime


class PerfilUpdate(Schema):
    nome: Name | None = None


class SenhaUpdate(Schema):
    senha_atual: str = Field(min_length=1, max_length=128)
    nova_senha: str = Field(min_length=10, max_length=128)


class PreferenciasUpdate(Schema):
    notificacoes: Annotated[bool, Field(strict=True)] | None = None
    alto_contraste: Annotated[bool, Field(strict=True)] | None = None
    tamanho_texto: Literal['PADRAO', 'GRANDE'] | None = None


class CategoriaCreate(Schema):
    codigo: str = Field(pattern=r'^[A-Z][A-Z0-9_]*$', max_length=40)
    nome: Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=80)]
    descricao: str | None = Field(default=None, max_length=255)


class CategoriaResponse(Schema):
    id_categoria: int
    codigo: str
    nome: str
    descricao: str | None
    ativo: bool


class CategoriaUpdate(Schema):
    nome: Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=80)] | None = None
    descricao: str | None = Field(default=None, max_length=255)
    ativo: Annotated[bool, Field(strict=True)] | None = None


class OcorrenciaCreate(Schema):
    id_categoria: PositiveID
    descricao: Description
    latitude: Annotated[float, Field(strict=True, ge=-90, le=90)]
    longitude: Annotated[float, Field(strict=True, ge=-180, le=180)]


class OcorrenciaUpdate(Schema):
    descricao: Description | None = None
    id_categoria: PositiveID | None = None
    latitude: Annotated[float, Field(strict=True, ge=-90, le=90)] | None = None
    longitude: Annotated[float, Field(strict=True, ge=-180, le=180)] | None = None


class OcorrenciaResponse(Schema):
    id_ocorrencia: int
    protocolo: str
    id_usuario: int
    id_categoria: int | None
    id_status: int
    descricao: str
    latitude: float
    longitude: float
    prioridade: Priority
    criado_em: datetime
    atualizado_em: datetime
    categoria: str | None
    status: str
    status_codigo: StatusCode


class StatusUpdate(Schema):
    codigo: StatusCode
    observacao: str | None = Field(default=None, min_length=1, max_length=2000)


class PrioridadeUpdate(Schema):
    prioridade: Priority


class EquipeCreate(Schema):
    nome: Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=100)]
    especialidade: Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=100)]


class EquipeUpdate(Schema):
    nome: Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=100)] | None = None
    especialidade: Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=100)] | None = None
    ativa: Annotated[bool, Field(strict=True)] | None = None


class AtendimentoCreate(Schema):
    id_equipe: PositiveID
    observacao: str | None = Field(default=None, max_length=2000)


class AtendimentoEnd(Schema):
    observacao: str | None = Field(default=None, max_length=2000)


class DadosCategoria(Schema):
    dados: CategoriaResponse


class Paginacao(Schema):
    pagina: int
    limite: int
    total: int


class ListaCategorias(Schema):
    dados: list[CategoriaResponse]
    paginacao: Paginacao


class ListaOcorrencias(Schema):
    dados: list[OcorrenciaResponse]
    paginacao: Paginacao


class DadosOcorrencia(Schema):
    dados: OcorrenciaResponse


class DadosUsuario(Schema):
    dados: UsuarioResponse


class LoginDados(Schema):
    access_token: str
    token_type: Literal['Bearer']
    expira_em: datetime
    usuario: UsuarioResponse


class LoginResponse(Schema):
    dados: LoginDados


class ResumoAnalise(Schema):
    linhas_csv: int
    total_ocorrencias: int
    ocorrencias_com_foto_referenciada: int
    referencias_foto_distintas: int
    total_fotos: None = None
    eventos_historico: None = None
    total_analisadas: int
    sem_analise: int
    tempo_analise_soma_min: float
    tempo_analise_media_min: float | None
    tempo_analise_mediana_min: float | None
    ocorrencias_urgentes: int
    percentual_urgentes: float
    possiveis_duplicidades: int
    relatos_validos: int
    relatos_invalidos: int
    data_inicial: str
    data_final: str
    fuso_agregacao: str
    fonte: str


class CategoriaAnalise(Schema):
    categoria_codigo: str
    categoria_nome: str
    total_ocorrencias: int
    urgentes: int
    total_analisadas: int
    tempo_analise_soma_min: float
    tempo_analise_media_min: float | None


class DataAnalise(Schema):
    data: str
    total_ocorrencias: int
    urgentes: int
    total_analisadas: int
    tempo_analise_soma_min: float


def updates(data: Schema):
    # NULL explícito não pode apagar campos obrigatórios de uma atualização.
    return data.model_dump(exclude_unset=True, exclude_none=True)
