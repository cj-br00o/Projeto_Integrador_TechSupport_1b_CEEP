#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
.venv/bin/python -m pytest -q
.venv/bin/python scripts/validar_notebook.py
