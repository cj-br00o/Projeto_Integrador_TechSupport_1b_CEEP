# Radar Urbano backend de gestão e ciência de dados

Aplicação local em FastAPI, SQLAlchemy, Pydantic e Pandas, adaptada aos dois guias de avaliação.
A gestão registra e consulta ocorrências no banco. A análise lê o CSV acadêmico e devolve indicadores JSON para o futuro dashboard.
Há uma única aplicação em `main.py`. O servidor não cria tabelas automaticamente e as rotas de IA não consultam banco.
Os cadernos são instruções; não foram preenchidos nem anexados a serviços externos.

## Preparar o notebook

Esta versão foi construída e testada em ambiente Linux remoto. Não houve acesso aos programas ou arquivos pessoais do notebook.
Python e VS Code precisam estar instalados no notebook. O pacote não executa instaladores de sistema.

1. Instale Python **3.11, 3.12 ou 3.13** pelo site oficial https://www.python.org/downloads/ . Marque Python Launcher/PATH no Windows.
2. Use VS Code https://code.visualstudio.com/ e as extensões Python e Python Debugger da Microsoft.
3. Extraia o ZIP e abra a pasta `radar_urbano_backend_ds_ia` no VS Code. Não execute dentro do ZIP.
4. Execute `preparar.bat`. Ele cria `.venv`, instala dependências do projeto, preserva `.env` existente, inicializa banco local e executa a análise do CSV.
5. Execute `iniciar.bat`. Abra `http://127.0.0.1:8000/docs`.
6. Execute `testar.bat` para os testes automatizados e requisições HTTP em banco temporário.

Se `python`/`py` não for encontrado, instale uma versão compatível e reabra o terminal.
Se for escolhida uma versão 3.14 ou superior pelo Launcher, execute explicitamente `py -3.12 preparar.py` usando uma versão compatível instalada.
No VS Code, use Python Select Interpreter e selecione `.venv\Scripts\python.exe`.
Diagnóstico sem ler senhas ou contas: `python verificar_ambiente.py`.
Não é preciso Node.js, MySQL, Docker ou Supabase para iniciar com SQLite.

## Terminal e reinício conforme o guia

Windows Prompt de Comando:

```bat
python -m venv .venv
.venv\Scripts\activate.bat
python -m pip install -r requirements-dev.txt
copy .env.example .env
python gerenciar.py init-db
python analise.py
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

O comando `copy` acima é somente para a primeira configuração; não sobrescreva um `.env` que você já configurou.
PowerShell: a ativação seria `.\.venv\Scripts\Activate.ps1`. Se bloqueada, use Prompt de Comando ou execute diretamente o Python da `.venv`.
Não precisa alterar a política de segurança do PowerShell.
Linux/macOS: `python3 -m venv .venv`, `source .venv/bin/activate`, depois os mesmos comandos Python.

Ao finalizar: **Ctrl+C** no terminal do Uvicorn; aguarde o prompt retornar; depois execute **deactivate** no terminal em que ativou o ambiente.
Para retomar, ative a mesma `.venv` e execute Uvicorn novamente. Não é necessário reinstalar tudo a cada reinício.
Os scripts `.bat` usam o interpretador diretamente e não deixam um ambiente ativado no terminal original; nesse caso não é necessário executar deactivate.
Parar a API não apaga o banco. `--reload` é para desenvolvimento local, não produção.

## Responsabilidades dos arquivos

| Arquivo ou pasta | Responsabilidade |
|---|---|
| config.py | .env, banco local permitido, CSV_PATH e origens CORS |
| database.py | Base, engine e sessão SQL por requisição |
| models.py | Nove tabelas do negócio e três extensões locais |
| schemas.py | Entradas e respostas Pydantic; validação e contrato OpenAPI |
| main.py | Uma aplicação FastAPI, middleware, tratamento de erros e registro de rotas |
| routes/ | Conta, categorias, ocorrências, equipes, fotos, mapa e IA |
| analise.py | Leitura e validação Pandas, estatísticas e agrupamentos do CSV |
| gerenciar.py | Inicialização explícita do banco e criação de administrador local |
| database/ocorrencias.csv | Fonte sintética de 20 ocorrências, separada do banco de gestão |
| docs/ | Contrato frontend, dicionários, critérios DS/IA e roteiro de demonstração |
| tests/ | Testes isolados dos fluxos e das inconsistências |
| scripts/ | Conferência independente, exportação de contrato e HTTP real |
| postman/ | Coleção preparada, com etapas de cidadão, gestão e IA |
| evidencias/ | Logs executados, JSON das rotas e reconciliação de cálculos |

## Primeiro cadastro e relacionamento

No `/docs`, cadastre um cidadão em `POST /api/v1/auth/cadastro` e faça login em `POST /api/v1/auth/login`.
O login retorna `dados.access_token`. Clique Authorize e informe somente o token, sem expô-lo em imagens públicas.
`GET /api/v1/categorias` devolve os IDs reais; use um deles em `POST /api/v1/ocorrencias`.
O servidor atribui id_usuario, protocolo, status RECEBIDA e prioridade MEDIA. O cidadão não pode se promover a gestor.
O POST e o GET de ocorrência devolvem o nome da categoria, além do ID armazenado como FK.
`id_categoria=999999` retorna 404 sem gravar ocorrência ou histórico parcial.

Para testar também POST de categoria e os fluxos administrativos, execute no terminal ativado:

```text
python gerenciar.py criar-gestor
```

Informe nome, e-mail e senha local com confirmação. Não há conta administrativa ou senha padrão.
Use o login desse gestor em Authorize para cadastrar categoria, equipe e atualizar o atendimento.
O fluxo preserva os códigos originais: RECEBIDA → EM_ANALISE → ENCAMINHADA → EM_ATENDIMENTO → RESOLVIDA.

## Banco e conexões

Padrão: SQLite em `instance/radar.db`. FK habilitada. Não é um banco Supabase disfarçado.
Para PostgreSQL, instale uma instância **local**, crie um banco novo e configure no `.env`:

```text
DATABASE_URL=postgresql+psycopg://USUARIO:SENHA@127.0.0.1:5432/radar_urbano_local
```

Use senha escapada para URL. Execute `python gerenciar.py init-db` e `python gerenciar.py conferir-banco`.
O driver psycopg 3 substitui psycopg2 do exemplo, mantendo SQLAlchemy/PostgreSQL. Não configure Supabase nesta entrega.
Hosts remotos e parâmetros que trocam o host são recusados. Importar a aplicação não abre conexão ou altera schema.
`database/schema_postgresql_local.sql` documenta o DDL gerado dos models para banco local novo; não é migração de um banco antigo.
Testes automatizados desta entrega foram executados em SQLite; execução contra PostgreSQL permanece pendente até haver uma instância local acessível.
As três extensões novas são credencial_local, sessao_local e preferencia_local. Os nomes das nove tabelas e colunas do negócio foram preservados.

## Ciência de dados

Rotas públicas sobre **CSV sintético**, sem acessar PostgreSQL/SQLite:

```text
GET /api/v1/analise/resumo
GET /api/v1/analise/categorias
GET /api/v1/analise/datas
GET /api/v1/analise/qualidade
```

A fonte continua tendo 20 linhas e 20 ocorrências distintas. Não foi substituída pelo exemplo de compras.
Soma dos intervalos até análise: 20 minutos; média 1; mediana 1. Cinco registros ALTA/CRITICA resultam em 25% urgentes pela regra didática.
O único dia presente é 01/09/2026. Não permite inferir tendência ou desempenho real da prefeitura.
Veja `docs/ANALISE.md` para perguntas, unidades, limitações e conferência independente.
`python scripts/conferir_calculos.py` verifica um registro, um grupo inteiro e totais usando csv/datetime/statistics, sem repetir os cálculos Pandas.
Arquivos ausentes retornam 503; CSV inválido retorna 422; linhas inconsistentes não são apagadas silenciosamente.

## Critérios e evidências

`docs/ATENDIMENTO_GUIAS.md` mapeia todos os objetivos ao código/evidência e identifica o que depende do notebook ou de autorização futura.
`evidencias/testes.txt`, `evidencias/testes.xml`, `evidencias/http_local.json` e `evidencias/json/` registram execuções reais.
Não há captura fabricada do Swagger, do Postman ou do Supabase. Prints do `/docs` ainda devem ser capturados na máquina em que a API estiver aberta.
O navegador remoto disponível não alcançou esta instância de API, embora as requisições locais tenham sido verificadas por HTTP real.

## Referências e versionamento

Os dois DOCX enviados foram integralmente lidos como guias de DS e IA. A tecnologia principal segue a exigência FastAPI dos cadernos.
O projeto `ClauAndradeDev/projeto_biblioteca1` foi lido anteriormente como referência de cadastros, conexão, JOIN e transações; usa Flask/MySQL.
Esta versão adapta o raciocínio do exemplo e usa FastAPI/Pydantic, conforme os guias completos, sem copiar dependências do sistema operacional do requirements da biblioteca.
O documento Google adicional exigiu login e não foi lido; não se afirma conformidade com conteúdo que permaneceu inacessível.

Foi criado histórico Git **local**, em repositório novo e sem remote. `historico_local.bundle` no pacote permite restaurá-lo se desejar.
Não foram feitos push, alterações em repositórios existentes ou ações no Classroom/Supabase.
GitHub permanece pendente por sua instrução. Para revisar no futuro: conferir `.gitignore`, executar os testes e só então definir o remote/autorização de publicação.

## Próxima etapa de frontend

Use `docs/FRONTEND.md` e `docs/openapi.json`. As telas desenhadas ainda não foram implementadas nem conectadas.
Mapa devolve GeoJSON com coordenadas aproximadas, sem nome/e-mail/descrição livre de outras pessoas. Fotos exigem autenticação e autorização.
Tokens opacos são guardados como hash; senha usa scrypt. Alterar senha revoga sessões. O limite de tentativas em memória serve apenas ao processo local.
Notificações são preferências salvas; não há push/e-mail externo. Não há Ollama ou modelo generativo em execução; IA nesta avaliação significa backend de Ciência de Dados.
Antes de produção serão necessários migrações versionadas, HTTPS, política de acesso de equipes, limitação distribuída e revisão de privacidade.
