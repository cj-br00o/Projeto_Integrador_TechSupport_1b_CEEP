# Contrato do frontend local

API local: `http://127.0.0.1:8000/api/v1`. Contrato completo gerado da aplicação: `docs/openapi.json` e `/docs`.
As telas de Entrada, Cadastro, Login, Início, Mapa, Solicitações e Perfil estão implementadas em frontend/. A central de gestão usa as mesmas rotas administrativas, com a identidade visual adaptada para operação técnica.

## Formatos

Gestão usa `{ "dados": ... }` e listagem paginada de ocorrências acrescenta `paginacao`.
Categorias, equipes, usuários, histórico, análises registradas e atendimentos também retornam
`paginacao: {pagina, limite, total}` e aceitam `pagina` (mínimo 1) e `limite` (1 a 100; padrão 20).
Status possui catálogo fixo de cinco etapas; fotos têm limite de cinco por ocorrência.
Ao montar o seletor de categorias, busque `?limite=100` e carregue as próximas páginas caso total ultrapasse esse limite.
Análise segue o guia de IA: resumo é um objeto JSON direto, categorias/datas são arrays diretos.
Erros usam `{ "erro": { "mensagem": "..." } }`; validação também traz campos sem repetir a entrada sensível.
Datas da gestão vêm em UTC ISO 8601; agregação diária de IA utiliza America/Sao_Paulo.
Médias ausentes são null, não zero nem NaN. Decimais são números JSON, com formatação deixada ao frontend.

## Fluxo do cidadão

1. POST /auth/cadastro recebe nome, email e senha. Cadastro público sempre CIDADAO.
2. POST /auth/login recebe email e senha; retorna dados.access_token, expira_em e usuario.
3. Use Authorization: Bearer TOKEN nas rotas privadas, inclusive fotos.
4. GET /categorias retorna os IDs reais. Não fixar id_categoria no código do frontend.
5. POST /ocorrencias recebe id_categoria, descricao, latitude e longitude. O servidor define dono, protocolo, status e prioridade.
6. GET /ocorrencias lista somente as próprias solicitações. Filtros: busca, id_categoria, id_status, pagina e limite.
7. GET /ocorrencias/{id} e /historico apresentam detalhes e transições permitidas ao dono ou gestão.
8. POST /ocorrencias/{id}/fotos recebe multipart com arquivo; máximo cinco fotos, cada uma até 6 MiB e 16 megapixels.
9. GET/PATCH /perfil consulta ou altera nome. PUT /perfil/senha exige senha_atual e nova_senha, revogando sessões.
10. GET/PATCH /perfil/preferencias salva notificacoes, tamanho_texto PADRAO/GRANDE e alto_contraste.
11. POST /auth/logout revoga o token atual.

O token é opaco e expira em 12 horas. O cliente preparado em frontend/js/api.js usa memória
e sessionStorage da aba para restaurar a sessão ao recarregar, validando-a novamente em /perfil.
Não utiliza localStorage para tokens, URLs ou logs. Logout revoga a sessão no servidor e limpa a aba.
Não há recuperação de senha por e-mail, login Google/GitHub ou serviço de push nesta entrega.
O perfil EQUIPE ainda exige definição de associação conta/equipe; só PREFEITURA/ADMINISTRADOR têm rotas de gestão liberadas.

## Telas e rotas

| Tela | Fonte |
|---|---|
| Início cidadão | GET /painel/cidadao; GET /ocorrencias?limite=1 |
| Informar problema | GET /categorias; POST /ocorrencias; POST /ocorrencias/{id}/fotos |
| Mapa público | GET /mapa?bbox=oeste,sul,leste,norte&id_categoria=ID |
| Solicitações | GET /ocorrencias com filtros e paginação |
| Detalhes | GET /ocorrencias/{id}; /historico; /atendimentos; /fotos |
| Perfil | /perfil, /perfil/senha, /perfil/preferencias |
| Dashboard acadêmico | GET /analise/resumo, /analise/categorias, /analise/datas, /analise/qualidade |
| Indicadores operacionais | GET /indicadores, restrito à gestão; fonte banco local |

GeoJSON retorna [longitude, latitude], categoria/status e localização aproximada a três casas decimais.
Não contém nome, e-mail ou descrição livre dos outros cidadãos. `meta.truncado=true` sinaliza limite de 500 pontos; aproximar ou filtrar o mapa.
No mockup, o rótulo Concluída pode representar o código técnico RESOLVIDA, preservando o banco.
Trocas de status e de prioridade pertencem à gestão e retornam 403 para cidadão.

## Exemplo de integração

```javascript
const API = 'http://127.0.0.1:8000/api/v1';
let token = null;
async function api(path, options = {}) {
  const headers = new Headers(options.headers);
  if (token) headers.set('Authorization', `Bearer ${token}`);
  if (options.body && !(options.body instanceof FormData)) headers.set('Content-Type', 'application/json');
  const response = await fetch(API + path, { ...options, headers });
  if (response.status === 204) return null;
  const data = await response.json();
  if (!response.ok) throw new Error(data.erro?.mensagem || 'Falha na API');
  return data;
}
const login = await api('/auth/login', { method: 'POST', body: JSON.stringify({ email, senha }) });
token = login.dados.access_token;
const solicitacoes = await api('/ocorrencias');
const resumoAcademico = await api('/analise/resumo');
// Multipart: não definir Content-Type, pois o navegador fornece o boundary.
const form = new FormData(); form.append('arquivo', arquivoSelecionado);
await api(`/ocorrencias/${idOcorrencia}/fotos`, { method: 'POST', body: form });
```

Uma foto privada precisa ser buscada com Authorization, convertida em Blob e exibida por ObjectURL; revogar a URL ao desmontar a tela.
```javascript
const resposta = await fetch('http://127.0.0.1:8000' + foto.url_arquivo, {
  headers: {Authorization: `Bearer ${token}`}
});
if (!resposta.ok) throw new Error('Foto indisponível ou sessão expirada');
const url = URL.createObjectURL(await resposta.blob());
imagem.src = url;
// Ao sair da tela: URL.revokeObjectURL(url).
```
Não é possível enviar o header Bearer diretamente pelo atributo src de uma tag img.
CORS libera portas locais 5173 e 5500. Para outra porta, ajuste CORS_ORIGINS no .env e reinicie a API.
Não abra o frontend via file://. Use servidor local.

## Separar o banco da amostra acadêmica

Os indicadores do CSV não são contagens ao vivo do banco de gestão. O cliente deve rotular a origem e o período.
Quando novos cidadãos registram ocorrências, o CSV não é atualizado automaticamente.
Gráfico de datas desta amostra tem só um dia; não apresentar tendência. Não há métrica de custo ou tempo de conserto.
