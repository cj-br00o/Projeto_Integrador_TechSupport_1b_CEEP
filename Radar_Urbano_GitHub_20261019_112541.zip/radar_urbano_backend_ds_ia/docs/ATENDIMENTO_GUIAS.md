# Registro histórico do pacote original

Este arquivo descreve a execução anterior incluída no ZIP. Para o estado atual validado neste notebook, consulte [REVISAO_NOTEBOOK.md](REVISAO_NOTEBOOK.md). As pendências antigas de instalação e PostgreSQL foram resolvidas nesta revisão.

# Atendimento dos objetivos da avaliação

Os guias fornecidos são roteiros genéricos; os exemplos de Produto/Categoria e compras foram adaptados ao domínio urbano.
Este documento distingue trabalho executado de ações que dependem do notebook ou de publicação futura.

## Desenvolvimento de Sistemas

| Objetivo | Implementação e evidência | Situação |
|---|---|---|
| Arquivos e ambiente virtual | main.py, database.py, models.py, schemas.py, requirements; preparar.py e .venv isolada no ambiente de execução | Executado no ambiente remoto; instalação no notebook pendente |
| Responsabilidades das camadas | README e docs/FRONTEND.md; rotas separadas dos models e schemas | Implementado |
| POST e GET de tabela com PK | categoria.id_categoria; rotas /api/v1/categorias | Executado em testes e coleção preparada |
| Segunda entidade com FK | ocorrencia.id_categoria → categoria.id_categoria, além das referências de usuário/status | Executado |
| Validar referência | POST com id_categoria inexistente retorna 404 sem persistência parcial | Teste automatizado e HTTP real |
| Consulta compreensível | respostas de ocorrência trazem categoria e status legíveis | Executado |
| Adaptação autoral | nove entidades físicas e códigos do projeto original preservados; novas tabelas de autenticação explicitadas | Conferido contra modelo canônico |
| Erros e evidências | testes de permissão, dados inválidos, duplicação, FK, propriedade e transições; evidencias/ | Executado localmente |
| Swagger e Postman | /docs e openapi.json reais da aplicação; coleção Postman importável | Documentação responde por HTTP; execução manual no Postman e prints pendentes |
| PostgreSQL | driver psycopg, URL local validada e schema SQL gerado | Configurado; execução em servidor PostgreSQL local pendente |
| Iniciar e encerrar | iniciar.bat, Uvicorn --reload, Ctrl+C e deactivate no README | Servidor temporário iniciado e encerrado nos testes; demonstração no notebook pendente |
| Versionamento | repositório novo somente local e bundle restaurável | Git local; nenhum remote/push |

O POST de categoria é restrito à gestão. Isso adiciona uma permissão ao exemplo didático e não elimina o fluxo avaliado.
Crie o administrador pelo comando gerenciar.py criar-gestor para demonstrá-lo no /docs.
O cadastro público de usuário fornece outro exemplo de PK gerada, sem permitir autopromoção de perfil.

## Ciência de Dados

| Objetivo | Implementação e evidência | Situação |
|---|---|---|
| Pasta, .venv e requisitos | mesma aplicação FastAPI e dependências isoladas; analise.py e database/ocorrencias.csv | Executado |
| Significado das linhas/colunas | uma ocorrência por linha; dicionário e unidades em docs/ANALISE.md | Documentado |
| Leitura Pandas | read_csv, tipos, ausências, duplicações e domínios validados | Executado |
| Inconsistências | testes para ausência obrigatória, ID repetido, data, infinito e referência inválida | Executado; sem excluir linhas silenciosamente |
| Perguntas de negócio | volume/urgência, categoria, intervalo de análise, datas e duplicidade | Documentado com visualização futura |
| Contagens, soma, média, mediana | ocorrências distintas e intervalos por ocorrência; nenhuma métrica de compras inventada | Executado |
| Agrupamentos | por categoria e por data de abertura no fuso America/Sao_Paulo | Executado |
| Rotas JSON | /api/v1/analise/resumo, categorias, datas e qualidade | HTTP real; arquivos em evidencias/json/ |
| Sem depender de banco | rotas IA não importam get_db; teste impede qualquer abertura de sessão SQL | Executado |
| Conferência individual e de operação/grupo | registro 1 e categoria INFRAESTRUTURA completa; biblioteca padrão comparada ao Pandas | Executado; evidencias/conferencia_calculos.json |
| Premissas e limitações | origem sintética, um dia de dados, tempo de análise não é tempo de solução | Documentado |
| Próximo dashboard | contratos tipados no OpenAPI, JSON e exemplos fetch | Preparado; frontend não implementado nesta etapa |
| GitHub e capturas | histórico local preservado; roteiro para capturas reais | Publicação e prints pendentes |

## Limites de autorização e do ambiente

Não foram alterados GitHub, Classroom ou Supabase. A instrução de versionar no GitHub do caderno será cumprida apenas quando a publicação for autorizada.
Não há declaração de que a máquina Windows do estudante já recebeu Python, extensões ou arquivos.
O ambiente acessível é remoto. A instalação no notebook exige executar os arquivos entregues nele.
O documento Google adicional não pôde ser lido por exigir login. Os dois DOCX anexados foram integralmente lidos.

Os arquivos de evidência não substituem prints de execução no notebook. Não foram produzidas imagens de interfaces que não puderam ser observadas.
