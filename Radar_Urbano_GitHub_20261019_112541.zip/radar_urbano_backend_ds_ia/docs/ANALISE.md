# Análise do CSV do Radar Urbano

## Fonte e unidade de análise

`database/ocorrencias.csv` é a mesma massa sintética de 20 ocorrências do pacote anterior, sem dados de cidadãos reais.
Cada linha representa **uma ocorrência**, com a primeira foto e a última análise registradas na exportação.
Os campos juntam informações que no banco ficam em ocorrência, categoria, status, foto e análise.
Fotos e nomes de categorias não devem multiplicar linhas na fonte; mais de uma linha por id_ocorrencia é rejeitada.
`ocorrencias_com_foto_referenciada` conta linhas com foto_url; `referencias_foto_distintas` conta textos diferentes nesse campo.
Isso não comprova a existência dos arquivos nem o número total de fotos por ocorrência. Por isso `total_fotos` é null.
O snapshot não contém eventos de historico_status; `eventos_historico` também é null, nunca a contagem de linhas.
O backend de gestão não importa esse CSV automaticamente. O número de ocorrências do banco pode diferir do número da amostra acadêmica.

## Dicionário da fonte

| Coluna | Tipo interpretado | Significado e unidade | Ausência |
|---|---|---|---|
| id_ocorrencia | inteiro positivo | Identificador único da ocorrência | Proibida |
| protocolo | texto até 20 caracteres | Identificador público único | Proibida |
| descricao | texto 10 a 2000 caracteres | Relato do problema | Proibida |
| latitude | número decimal entre -90 e 90 | Coordenada em graus | Proibida |
| longitude | número decimal entre -180 e 180 | Coordenada em graus | Proibida |
| prioridade | código BAIXA/MEDIA/ALTA/CRITICA | Prioridade registrada na fonte | Proibida |
| criado_em | data e hora com fuso | Instante de abertura | Proibida |
| categoria_codigo | código do catálogo | Categoria atribuída | Permitida; SEM_CATEGORIA nos grupos |
| status_codigo | código do catálogo | Estado no momento da exportação | Proibida |
| foto_url | texto | Referência da primeira foto | Permitida; caminhos são fictícios |
| resumo | texto | Resumo da análise registrada | Obrigatório se analisado_em preenchido |
| valido | true/false textual | Validade atribuída pela análise | Obrigatório se analisado_em preenchido |
| id_categoria_sugerida | inteiro positivo do catálogo | Identificador de categoria sugerida | Permitida |
| prioridade_sugerida | código de prioridade | Sugestão de prioridade | Permitida |
| id_ocorrencia_duplicada | inteiro positivo de outro registro | Referência a possível duplicidade | Permitida; vazio não é erro |
| analisado_em | data e hora com fuso | Instante da análise usada no snapshot | Permitida |

O código inclui validação de IDs inteiros, coordenadas, códigos de domínio, datas, infinitos e referências de duplicidade.
Uma referência não pode apontar para si mesma nem para um ID ausente da exportação.
Se não existir analisado_em, os campos derivados de análise também precisam estar vazios.
Ausência opcional não vira zero nem dado inventado. Média e mediana são null quando não existe nenhuma análise concluída na fonte.
`qualidade` mostra tipos interpretados e contagens de ausências por coluna.

## Perguntas de negócio e visualização futura

| Pergunta | Resultado e cálculo | Componente sugerido |
|---|---|---|
| Qual o volume e a participação dos relatos urgentes? | IDs distintos; ALTA/CRITICA ÷ total × 100 | Cartões total e percentual urgente |
| Quais categorias concentram solicitações? | groupby categoria_codigo e contagem distinta | Barras por categoria |
| Quanto tempo decorre até a análise registrada? | analisado_em − criado_em em minutos; soma, média e mediana | Cartões com unidade e denominador |
| Como os registros se distribuem nos dias presentes? | criado_em em America/Sao_Paulo; agrupamento diário | Tabela; gráfico só ganha leitura temporal com mais dias |
| Existem referências de possível duplicidade? | Quantidade de id_ocorrencia_duplicada preenchidos | Cartão de possíveis duplicidades, sem exclusão automática |

Regra didática de atenção: ALTA ou CRITICA → URGENTE; BAIXA ou MEDIA → ROTINA.
A regra usa o campo existente; não é inferência de IA, recomendação de segurança nem decisão automática para a prefeitura.

## Conferência de um registro e de um grupo inteiro

Registro 1: criado_em 01/09/2026 08:00 −03; analisado_em 08:01 −03.
Diferença de 60 segundos ÷ 60 = **1 minuto**. Isso mede o intervalo até a análise registrada, não o tempo de conserto.
O grupo INFRAESTRUTURA contém IDs 1, 10, 14 e 18: quatro registros, cada um com um minuto; total **4 minutos**.
A conferência executável em `evidencias/conferencia_calculos.json` verifica os IDs efetivamente lidos e os horários, sem depender desta transcrição.
As oito contagens por categoria somam 20; as contagens por data também somam 20; os tempos dos grupos somam 20 minutos.
A soma de minutos de várias ocorrências é uma soma de intervalos, não tempo total de trabalho da equipe ou tempo de relógio da cidade.

Média: soma dos intervalos válidos ÷ quantidade de ocorrências analisadas. Mediana: valor central dos mesmos intervalos ordenados.
Ambas são calculadas sobre ocorrências, não fotos, eventos de histórico ou linhas de uma junção multiplicada.
Os testes usam também intervalos 1, 2 e 9 minutos: soma 12, média 4, mediana 2.
O arredondamento de apresentação é de duas casas após os cálculos. Contagens continuam inteiras. Números JSON usam ponto decimal.

## Resultados da amostra

20 linhas; 20 ocorrências distintas; 20 analisadas; 0 sem análise.
Soma 20 minutos; média 1 minuto; mediana 1 minuto.
Cinco urgentes representam 25%; uma referência aponta para possível duplicidade.
Período de abertura em horário local: somente 01/09/2026.
As 19 ausências em id_ocorrencia_duplicada são opcionais, não 19 falhas de qualidade.

## Limitações

Dados sintéticos com horários uniformes não medem a eficiência da Ouvidoria 156 ou da Prefeitura de Maringá.
Somente um dia não permite estimar tendência, sazonalidade ou SLA real.
O CSV não contém encerrado_em/fim de manutenção por ocorrência; não calculamos tempo de resolução ou custo.
Não há produtos, compras, preço, desconto ou dinheiro: os números do exemplo da mercearia não foram reaproveitados como resultados do Radar Urbano.
Não se completam datas sem registros com zero. O snapshot traz a última análise disponível, sem representar todo o histórico de análises.
Resultados só são comparáveis quando a exportação mantém a mesma unidade e a mesma regra de seleção de foto/análise.
