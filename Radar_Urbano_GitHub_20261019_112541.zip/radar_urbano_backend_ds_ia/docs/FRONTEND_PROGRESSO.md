# Implementação do frontend local

As quatro referências visuais do cidadão foram recebidas e utilizadas. Seus hashes estão em REFERENCIAS_VISUAIS.json.
Os originais e as versões anteriores do frontend foram preservados. O logotipo foi reinterpretado em SVG local;
não se utilizou brasão oficial nem se declarou vínculo institucional com a prefeitura.

## Telas implementadas

Entrada, cadastro, login, início, mapa público, lista de solicitações, nova solicitação, detalhes,
perfil, dados pessoais, segurança, notificações, ajuda e privacidade.
A central de gestão compartilha a identidade visual e acrescenta indicadores do banco, tabelas,
filtros, cadastros de categorias/equipes, prioridade, transições, atribuição e conclusão de atendimentos.
O acesso administrativo depende do perfil validado no servidor.

## Implementação

HTML, CSS e módulos JavaScript, sem etapa de build ou servidor Node em produção.
Uma única aplicação FastAPI serve frontend e API na mesma origem.
Leaflet 1.9.4 está distribuído localmente com licença; a base de ruas é OpenStreetMap com atribuição visível.
Os controles e a lista de ocorrências continuam funcionando quando a base de ruas não está disponível.
A interface não simula nomes de ruas, bairros, alertas não lidos, resultados de IA ou dados inexistentes.

O cliente usa token opaco em memória e sessionStorage da aba. Não salva tokens no localStorage,
URLs ou logs. Preferências de acessibilidade sem credenciais podem ser guardadas localmente e são sincronizadas
com a conta. As imagens privadas usam Authorization e Blob URLs com liberação ao sair da tela.
A política CSP permite scripts somente locais e os blocos de mapa no domínio indicado.
Texto fornecido pelos cidadãos é escapado ao montar elementos HTML.

Uma ocorrência salva e uma foto enviada são operações diferentes: se a foto falha,
a interface confirma o protocolo salvo e permite reenviar a imagem nos detalhes, sem duplicar a ocorrência.
Formulários têm validação, proteção contra submissão dupla e mensagens de falha; nenhuma falha vira lista vazia ou sucesso silencioso.
Datas são apresentadas no fuso America/Sao_Paulo. Indicadores de início pertencem ao cidadão conectado.

## Testes e evidências

O roteiro scripts/testar_cliente_web.py executa as telas em Chrome headless separado do perfil pessoal,
com banco PostgreSQL descartável, contas fictícias e fotos geradas para o ensaio.
Os relatórios reais, capturas e verificações Axe ficam em evidencias/frontend_cliente_*.
As execuções anteriores, inclusive a falha de reflow em 320 px, permanecem preservadas.
O layout dos indicadores foi ajustado para corrigir a rolagem horizontal encontrada.
Também foi corrigido o link de pular para o conteúdo, preservando o foco sem alterar a rota do sistema.

São verificados cadastro/login, duplicidade, senha inválida, alteração de senha e revogação,
solicitações com fotos, histórico, consulta, perfil, acessibilidade, permissão entre cidadãos,
proteção contra execução de HTML, operação da gestão, funcionamento sem mapa de ruas e larguras de 320/390 px.
Uma etapa separada registra dados pela interface, reinicia Uvicorn e entra novamente para consultar
conta, ocorrência, histórico e foto persistidos no PostgreSQL.
Axe é uma verificação automatizada das páginas identificadas no relatório, não uma certificação completa de acessibilidade.

O banco operacional não recebe registros de demonstração nem senhas padrão.
Para utilizar a gestão, crie uma conta local com gerenciar.py criar-gestor.
GitHub, Classroom e Supabase não foram alterados.
