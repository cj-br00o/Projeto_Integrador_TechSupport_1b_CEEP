# Dicionário dos models locais

Nove entidades originais e três extensões de autenticação/preferência.

## categoria

| Campo | Tipo PostgreSQL | Permite nulo | Chave |
|---|---|---|---|
| id_categoria | SMALLINT | não | PK |
| codigo | VARCHAR(40) | não | UQ |
| nome | VARCHAR(80) | não | UQ |
| descricao | VARCHAR(255) | sim |  |
| ativo | BOOLEAN | não |  |

## equipe

| Campo | Tipo PostgreSQL | Permite nulo | Chave |
|---|---|---|---|
| id_equipe | BIGINT | não | PK |
| nome | VARCHAR(100) | não | UQ |
| especialidade | VARCHAR(100) | não |  |
| ativa | BOOLEAN | não |  |
| criado_em | TIMESTAMP WITH TIME ZONE | não |  |

## status_ocorrencia

| Campo | Tipo PostgreSQL | Permite nulo | Chave |
|---|---|---|---|
| id_status | SMALLINT | não | PK |
| codigo | VARCHAR(30) | não | UQ |
| nome | VARCHAR(50) | não | UQ |
| ordem | SMALLINT | não | UQ |
| status_final | BOOLEAN | não |  |

## usuario

| Campo | Tipo PostgreSQL | Permite nulo | Chave |
|---|---|---|---|
| id_usuario | BIGINT | não | PK |
| nome | VARCHAR(120) | não |  |
| email | VARCHAR(160) | não | UQ |
| perfil | VARCHAR(20) | não |  |
| ativo | BOOLEAN | não |  |
| criado_em | TIMESTAMP WITH TIME ZONE | não |  |

## credencial_local

| Campo | Tipo PostgreSQL | Permite nulo | Chave |
|---|---|---|---|
| id_usuario | BIGINT | não | PK FK → usuario.id_usuario |
| senha_hash | VARCHAR(255) | não |  |

## ocorrencia

| Campo | Tipo PostgreSQL | Permite nulo | Chave |
|---|---|---|---|
| id_ocorrencia | BIGINT | não | PK |
| protocolo | VARCHAR(20) | não | UQ |
| id_usuario | BIGINT | não | FK → usuario.id_usuario |
| id_categoria | SMALLINT | sim | FK → categoria.id_categoria |
| id_status | SMALLINT | não | FK → status_ocorrencia.id_status |
| descricao | TEXT | não |  |
| latitude | NUMERIC(9, 6) | não |  |
| longitude | NUMERIC(9, 6) | não |  |
| prioridade | VARCHAR(10) | não |  |
| criado_em | TIMESTAMP WITH TIME ZONE | não |  |
| atualizado_em | TIMESTAMP WITH TIME ZONE | não |  |

## preferencia_local

| Campo | Tipo PostgreSQL | Permite nulo | Chave |
|---|---|---|---|
| id_usuario | BIGINT | não | PK FK → usuario.id_usuario |
| notificacoes | BOOLEAN | não |  |
| tamanho_texto | VARCHAR(10) | não |  |
| alto_contraste | BOOLEAN | não |  |

## sessao_local

| Campo | Tipo PostgreSQL | Permite nulo | Chave |
|---|---|---|---|
| token_hash | VARCHAR(64) | não | PK |
| id_usuario | BIGINT | não | FK → usuario.id_usuario |
| expira_em | TIMESTAMP WITH TIME ZONE | não |  |

## analise_ia

| Campo | Tipo PostgreSQL | Permite nulo | Chave |
|---|---|---|---|
| id_analise | BIGINT | não | PK |
| id_ocorrencia | BIGINT | não | FK → ocorrencia.id_ocorrencia |
| resumo | TEXT | não |  |
| valido | BOOLEAN | não |  |
| id_categoria_sugerida | SMALLINT | sim | FK → categoria.id_categoria |
| prioridade_sugerida | VARCHAR(10) | sim |  |
| id_ocorrencia_duplicada | BIGINT | sim | FK → ocorrencia.id_ocorrencia |
| analisado_em | TIMESTAMP WITH TIME ZONE | não |  |

## atendimento

| Campo | Tipo PostgreSQL | Permite nulo | Chave |
|---|---|---|---|
| id_atendimento | BIGINT | não | PK |
| id_ocorrencia | BIGINT | não | FK → ocorrencia.id_ocorrencia |
| id_equipe | BIGINT | não | FK → equipe.id_equipe |
| inicio_em | TIMESTAMP WITH TIME ZONE | sim |  |
| fim_em | TIMESTAMP WITH TIME ZONE | sim |  |
| observacao | TEXT | sim |  |

## foto_ocorrencia

| Campo | Tipo PostgreSQL | Permite nulo | Chave |
|---|---|---|---|
| id_foto | BIGINT | não | PK |
| id_ocorrencia | BIGINT | não | FK → ocorrencia.id_ocorrencia |
| url_arquivo | TEXT | não |  |
| criado_em | TIMESTAMP WITH TIME ZONE | não |  |

## historico_status

| Campo | Tipo PostgreSQL | Permite nulo | Chave |
|---|---|---|---|
| id_historico | BIGINT | não | PK |
| id_ocorrencia | BIGINT | não | FK → ocorrencia.id_ocorrencia |
| id_status | SMALLINT | não | FK → status_ocorrencia.id_status |
| id_usuario_responsavel | BIGINT | não | FK → usuario.id_usuario |
| observacao | TEXT | sim |  |
| alterado_em | TIMESTAMP WITH TIME ZONE | não |  |
