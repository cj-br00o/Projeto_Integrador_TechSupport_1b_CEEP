# Execução neste notebook em 19 de outubro de 2026

O ZIP original foi extraído em uma pasta nova dentro do repositório existente.
As pastas backend, Radar_Urbano_Modulo_7 e Radar_Urbano_Pacote_Definitivo, a .venv antiga,
o .env antigo e as alterações prévias de requirements.txt foram preservados.
Não se leu o conteúdo do .env antigo nem se usaram credenciais anteriores.
Não há AGENTS.md no projeto nem nos diretórios ancestrais examinados.

## Ambiente e referências

Linux Mint 22.1; Python 3.12.3; Git 2.43.0; VS Code 1.98.2; PostgreSQL 16.13.
A nova .venv pertence somente a esta pasta. `requirements-lock.txt` registra todas as versões
instaladas; pip check não encontrou dependências incompatíveis.
O cache do VS Code da pasta superior apontava para a .venv antiga.
O workspace Radar_Urbano.code-workspace e a configuração local agora indicam `.venv/bin/python` desta pasta.
O depurador especifica esse interpretador explicitamente. A seleção visual da nova janela não foi observada:
a ferramenta de interface não disponibilizou aplicativos ou navegadores.

Os dois DOCX de avaliação em Downloads foram lidos integralmente como guias, sem preenchimento ou alteração.
O app.py e README públicos da biblioteca foram consultados por HTTPS: Flask/MySQL, conexão,
INSERT parametrizado, commit, consulta com JOIN para nomes e fechamento de conexão.
O Radar Urbano mantém FastAPI, SQLAlchemy e Pydantic e acrescenta rollback e controle de permissão.
O Google Docs fornecido redirecionou para login; seu conteúdo não foi lido.

## Banco exclusivo

O cluster de sistema na porta 5432 estava parado. Foi criado um cluster **novo e privado** em instance/pgdata,
sem alterar esse serviço. Ele escuta somente 127.0.0.1:55432 e usa socket privado em /tmp/radar-pg-1001
(o caminho da pasta do projeto ultrapassava o limite de 107 bytes de sockets Unix).
O banco radar_urbano_local pertence à conta nova radar_app, sem privilégio de superusuário.
A senha foi gerada aleatoriamente e salva apenas em .env com permissão 600; não aparece nas evidências.
A autenticação TCP usa SCRAM-SHA-256. O socket Unix usa trust, limitado ao diretório 700 do usuário local.
Não se conectou ao Supabase nem a nenhum banco anterior. Não há cidadãos, senhas padrão ou ocorrências
de demonstração no banco operacional: os ensaios usam bancos separados, descartáveis.

SQLite permanece disponível para desenvolvimento portátil e para a suíte de testes.
Ele habilita FKs, mas não aplica SMALLINT nem bloqueios de linha como PostgreSQL.
A validação HTTP foi executada também em PostgreSQL para cobrir essa diferença.

## Revisão realizada

- Mantidas as nove tabelas físicas do domínio e seus campos/códigos; conferência executável contra o modelo canônico.
- Mantidas as extensões documentadas no ZIP: credencial_local separa hash de senha; sessao_local permite revogação;
  preferencia_local guarda opções de perfil. Nenhuma outra tabela ou coluna foi acrescentada nesta revisão.
- Corrigida consulta de PK fora do intervalo SMALLINT: categoria 999999 retorna 404, sem erro interno.
  Valores SQL fora do domínio recebem erro 422 genérico, sem detalhes internos.
- Verificação e criação de atendimento/foto usam bloqueio da ocorrência no PostgreSQL, evitando ultrapassar limites sob concorrência.
- Paginação completada nos catálogos e coleções privadas; contratos Pydantic de login e listagem de ocorrências.
- Indicadores CSV distinguem referências de fotos de fotos totais e de histórico indisponível.
- UPLOAD_DIR configurável permite testes com arquivos isolados; CORS recusa wildcard na configuração de ambiente.
- Acrescentados scripts Linux, workspace específico, controle de processo, prova de reinício e empacotamento por lista permitida.

## Evidências e limites

As evidências copiadas do ZIP em evidencias/ são históricas e não comprovam execução neste notebook.
As pastas notebook_2026_10_19 e notebook_http_* contêm as execuções desta revisão.
A primeira execução HTTP encontrou o erro SMALLINT e ficou preservada; a execução posterior de sucesso
contém resultado OK, respostas JSON sanitizadas, concorrência e persistência após reiniciar Uvicorn.
O erro foi corrigido e o mesmo cenário repetido com sucesso.
Senhas e tokens não são gravados nos relatórios; os cadastros são fictícios.

44 testes automatizados passaram em SQLite, com um aviso de depreciação da dependência Starlette/AnyIO.
63 requisições HTTP passaram em PostgreSQL, além de 8 requisições simultâneas para os limites de atendimento/fotos
e 2 preflights CORS. Registro, cinco eventos de histórico, fotos e sessão persistiram após reiniciar a API.
A conferência independente usa csv/datetime/statistics para comparar registro, grupo e totais com Pandas.
A amostra acadêmica mantém 20 ocorrências, 5 urgentes (25%) e intervalo médio/mediano até análise de 1 minuto.
Não representa dados reais da prefeitura nem execução de Ollama.

Swagger respondeu por HTTP e o OpenAPI foi salvo; a ferramenta de interface retornou lista vazia de navegadores
e recusou abrir o navegador integrado. Portanto não há captura visual de /docs nem execução no Postman.
A coleção Postman está preparada para importação, com senhas e tokens vazios.
Nenhuma instalação manual é necessária para iniciar o backend neste notebook.
Para usar visualmente o editor, abra Radar_Urbano.code-workspace no VS Code; para os prints opcionais, abra /docs no Chrome.

Não houve push, configuração de remote, alteração do Classroom ou do Supabase, nem restauração do bundle Git antigo.
O Git existente foi preservado; .gitignore da raiz passou a proteger configurações e bancos de todas as versões.
