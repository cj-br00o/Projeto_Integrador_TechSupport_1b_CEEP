# Demonstração e evidências no notebook

## Sequência para apresentar ao professor

1. Abrir a pasta no VS Code e selecionar o Python da .venv.
2. Executar `python analise.py` e mostrar resumo e qualidade da fonte.
3. Executar `python scripts/conferir_calculos.py` e abrir a conferência JSON.
4. Iniciar `python -m uvicorn main:app --reload` e abrir `/docs`.
5. Criar cidadão em POST /api/v1/auth/cadastro, depois entrar em /auth/login.
6. Usar Authorize com o token de cidadão; listar categorias; guardar um id_categoria real.
7. Registrar ocorrência com descrição e coordenadas; consultar a lista e mostrar o nome da categoria.
8. Repetir o POST com id_categoria 999999 e mostrar 404.
9. Criar o gestor em outro terminal com `python gerenciar.py criar-gestor`; fazer login e trocar Authorize para o token do gestor.
10. Cadastrar categoria nova e consultar GET /categorias, demonstrando entidade simples com PK.
11. Consultar as quatro rotas /api/v1/analise e conferir os totais dos JSON.
12. Parar Uvicorn com Ctrl+C; desativar a .venv com deactivate se ela foi ativada manualmente.

## Capturas reais que ainda precisam ser feitas

Na máquina em que o Swagger estiver aberto, capture rota, status e corpo da resposta de:

- POST e GET de categoria;
- POST e GET de ocorrência com nome da categoria;
- erro 404 de categoria inexistente;
- análise resumo, categorias e datas.

Não deixe token, senha, e-mail pessoal ou string de conexão aparecendo no print.
Os logs e JSON entregues são reais, mas não são imagens do Swagger ou do Postman.
O navegador remoto não conseguiu observar a instância local utilizada pelos testes; não foram produzidos prints substitutos.

## Postman

Importe a coleção entregue, use base_url http://127.0.0.1:8000/api/v1 e execute as etapas de cidadão em ordem.
Se já cadastrou o e-mail de demonstração antes, use outro e-mail fictício ou entre com a conta existente; repetir cadastro retorna 409.
Para gestão, informe email_gestor e senha_gestor criados por você. Nunca publique esses valores.
Selecione manualmente uma imagem no campo arquivo da requisição de foto.
Na pasta IA, as quatro requisições GET independem de token e de conexão SQL.

## Versão local e publicação futura

O histórico local pode ser revisado com `git log --oneline`.
Se você extraiu o ZIP sem .git e deseja restaurar o histórico: `git clone historico_local.bundle projeto_versionado` dentro da pasta extraída.
Isso é clone de arquivo local, não usa GitHub. Os scripts .bat não executam Git nem publicam arquivos.
Antes de uma futura publicação autorizada, confira o Source Control, rode os testes e confirme que .env, .venv e instance/ estão ignorados.
