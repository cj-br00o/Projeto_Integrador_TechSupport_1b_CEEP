"""Configuração local. Nunca lê credenciais de outros projetos."""
from dataclasses import dataclass, field
import os
from pathlib import Path
from dotenv import load_dotenv
from sqlalchemy.engine import make_url

ROOT = Path(__file__).resolve().parent


def validar_banco_local(value: str) -> str:
    url = make_url(value)
    if url.drivername == 'sqlite':
        if url.query:
            raise ValueError('SQLite local não aceita parâmetros de URI nesta entrega.')
        if url.database == ':memory:':
            return value
        path = Path(url.database or 'instance/radar.db')
        if not path.is_absolute():
            path = ROOT / path
        return 'sqlite:///' + str(path)
    if url.drivername not in ('postgresql', 'postgresql+psycopg'):
        raise ValueError('Use SQLite ou PostgreSQL local.')
    if url.host not in ('localhost', '127.0.0.1', '::1') or any(k in url.query for k in ('host', 'hostaddr', 'service')):
        raise ValueError('Banco remoto bloqueado nesta fase. Não use Supabase.')
    return url.set(drivername='postgresql+psycopg').render_as_string(hide_password=False)


@dataclass
class Settings:
    database_url: str = 'sqlite:///instance/radar.db'
    csv_path: Path = ROOT / 'database/ocorrencias.csv'
    upload_dir: Path = ROOT / 'instance/uploads'
    origins: list[str] = field(default_factory=lambda: ['http://localhost:5173', 'http://127.0.0.1:5173', 'http://localhost:5500', 'http://127.0.0.1:5500'])
    token_hours: int = 12
    auth_limit: int = 20

    @classmethod
    def from_env(cls):
        load_dotenv(ROOT / '.env')
        path = Path(os.getenv('CSV_PATH', 'database/ocorrencias.csv'))
        uploads = Path(os.getenv('UPLOAD_DIR', 'instance/uploads'))
        origins = [origin.strip() for origin in os.getenv('CORS_ORIGINS', ','.join(cls().origins)).split(',') if origin.strip()]
        if '*' in origins:
            raise ValueError('Informe origens específicas para CORS.')
        return cls(database_url=os.getenv('DATABASE_URL', 'sqlite:///instance/radar.db'),
                   csv_path=path if path.is_absolute() else ROOT / path,
                   upload_dir=uploads if uploads.is_absolute() else ROOT / uploads,
                   origins=origins)
