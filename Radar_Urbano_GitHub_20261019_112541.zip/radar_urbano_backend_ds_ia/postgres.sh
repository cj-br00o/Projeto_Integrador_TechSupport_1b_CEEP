#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
PG_BIN=/usr/lib/postgresql/16/bin
case "${1:-status}" in
  iniciar)
    mkdir -p /tmp/radar-pg-1001
    chmod 700 /tmp/radar-pg-1001
    if ! "$PG_BIN/pg_ctl" -D instance/pgdata status >/dev/null 2>&1; then
      "$PG_BIN/pg_ctl" -D instance/pgdata -l instance/postgres.log -o '-h 127.0.0.1 -p 55432 -k /tmp/radar-pg-1001' start
    fi ;;
  parar) "$PG_BIN/pg_ctl" -D instance/pgdata stop -m fast ;;
  status) "$PG_BIN/pg_ctl" -D instance/pgdata status ;;
  *) echo 'Uso: bash postgres.sh iniciar|parar|status'; exit 2 ;;
esac
