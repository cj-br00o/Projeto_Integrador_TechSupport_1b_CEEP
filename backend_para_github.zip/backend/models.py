from sqlalchemy import (
    BigInteger, Boolean, CheckConstraint, Column, DateTime, DDL, ForeignKey,
    Identity, Index, Numeric, SmallInteger, String, Text, UniqueConstraint,
    event, text
)
from sqlalchemy.orm import relationship

from database import Base


class Categoria(Base):
    __tablename__ = "categoria"
    __table_args__ = (
        UniqueConstraint("codigo", name="uq_categoria_codigo"),
        UniqueConstraint("nome", name="uq_categoria_nome"),
        CheckConstraint("codigo ~ '^[A-Z][A-Z0-9_]*$'", name="ck_categoria_codigo"),
    )

    id_categoria = Column(
        SmallInteger,
        Identity(always=True),
        primary_key=True,
        index=True
    )
    codigo = Column(String(40), nullable=False)
    nome = Column(String(80), nullable=False)
    descricao = Column(String(255))
    ativo = Column(Boolean, nullable=False, server_default=text("TRUE"))

    ocorrencias = relationship(
        "Ocorrencia",
        back_populates="categoria"
    )


class Usuario(Base):
    __tablename__ = "usuario"
    __table_args__ = (
        UniqueConstraint("email", name="uq_usuario_email"),
        CheckConstraint(
            "perfil IN ('CIDADAO', 'PREFEITURA', 'EQUIPE', 'ADMINISTRADOR')",
            name="ck_usuario_perfil"
        ),
    )

    id_usuario = Column(BigInteger, Identity(always=True), primary_key=True)
    nome = Column(String(120), nullable=False)
    email = Column(String(160), nullable=False)
    perfil = Column(String(20), nullable=False)
    ativo = Column(Boolean, nullable=False, server_default=text("TRUE"))
    criado_em = Column(
        DateTime(timezone=True), nullable=False,
        server_default=text("CURRENT_TIMESTAMP")
    )

    ocorrencias = relationship("Ocorrencia", back_populates="usuario")


class StatusOcorrencia(Base):
    __tablename__ = "status_ocorrencia"
    __table_args__ = (
        UniqueConstraint("codigo", name="uq_status_codigo"),
        UniqueConstraint("nome", name="uq_status_nome"),
        UniqueConstraint("ordem", name="uq_status_ordem"),
        CheckConstraint("codigo ~ '^[A-Z][A-Z0-9_]*$'", name="ck_status_codigo"),
        CheckConstraint("ordem > 0", name="ck_status_ordem"),
    )

    id_status = Column(SmallInteger, Identity(always=True), primary_key=True)
    codigo = Column(String(30), nullable=False)
    nome = Column(String(50), nullable=False)
    ordem = Column(SmallInteger, nullable=False)
    status_final = Column(Boolean, nullable=False, server_default=text("FALSE"))

    ocorrencias = relationship("Ocorrencia", back_populates="status")


class Ocorrencia(Base):
    __tablename__ = "ocorrencia"
    __table_args__ = (
        UniqueConstraint("protocolo", name="uq_ocorrencia_protocolo"),
        CheckConstraint(
            "char_length(btrim(descricao)) BETWEEN 10 AND 2000",
            name="ck_ocorrencia_descricao"
        ),
        CheckConstraint("latitude BETWEEN -90 AND 90", name="ck_ocorrencia_latitude"),
        CheckConstraint("longitude BETWEEN -180 AND 180", name="ck_ocorrencia_longitude"),
        CheckConstraint(
            "prioridade IN ('BAIXA', 'MEDIA', 'ALTA', 'CRITICA')",
            name="ck_ocorrencia_prioridade"
        ),
        CheckConstraint("atualizado_em >= criado_em", name="ck_ocorrencia_datas"),
        Index("idx_ocorrencia_categoria", "id_categoria"),
        Index("idx_ocorrencia_status", "id_status"),
        Index("idx_ocorrencia_prioridade", "prioridade"),
        Index("idx_ocorrencia_criado_em", "criado_em"),
        Index("idx_ocorrencia_localizacao", "latitude", "longitude"),
    )

    id_ocorrencia = Column(
        BigInteger,
        Identity(always=True),
        primary_key=True,
        index=True
    )
    protocolo = Column(String(20), nullable=False)
    id_usuario = Column(
        BigInteger,
        ForeignKey("usuario.id_usuario", name="fk_ocorrencia_usuario", ondelete="RESTRICT"),
        nullable=False
    )
    id_categoria = Column(
        SmallInteger,
        ForeignKey("categoria.id_categoria", name="fk_ocorrencia_categoria", ondelete="RESTRICT"),
        nullable=True
    )
    id_status = Column(
        SmallInteger,
        ForeignKey("status_ocorrencia.id_status", name="fk_ocorrencia_status", ondelete="RESTRICT"),
        nullable=False
    )
    descricao = Column(Text, nullable=False)
    latitude = Column(Numeric(9, 6), nullable=False)
    longitude = Column(Numeric(9, 6), nullable=False)
    prioridade = Column(String(10), nullable=False)
    criado_em = Column(
        DateTime(timezone=True), nullable=False,
        server_default=text("CURRENT_TIMESTAMP")
    )
    atualizado_em = Column(
        DateTime(timezone=True), nullable=False,
        server_default=text("CURRENT_TIMESTAMP")
    )

    categoria = relationship("Categoria", back_populates="ocorrencias")
    usuario = relationship("Usuario", back_populates="ocorrencias")
    status = relationship("StatusOcorrencia", back_populates="ocorrencias")


event.listen(
    Ocorrencia.__table__,
    "after_create",
    DDL("""
CREATE OR REPLACE FUNCTION fn_atualizar_ocorrencia_data()
RETURNS TRIGGER AS $$
BEGIN
    NEW.atualizado_em := CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER tg_ocorrencia_atualizado_em
BEFORE UPDATE ON ocorrencia
FOR EACH ROW EXECUTE FUNCTION fn_atualizar_ocorrencia_data();
""")
)
