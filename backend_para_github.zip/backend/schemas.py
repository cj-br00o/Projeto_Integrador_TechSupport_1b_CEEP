from datetime import datetime
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class CategoriaCreate(BaseModel):
    codigo: str = Field(max_length=40, pattern=r"^[A-Z][A-Z0-9_]*$")
    nome: str = Field(max_length=80)
    descricao: str | None = Field(default=None, max_length=255)
    ativo: bool = True


class CategoriaResponse(BaseModel):
    id_categoria: int
    codigo: str
    nome: str
    descricao: str | None
    ativo: bool

    model_config = ConfigDict(from_attributes=True)


class OcorrenciaCreate(BaseModel):
    protocolo: str = Field(max_length=20)
    id_usuario: int = Field(gt=0)
    id_categoria: int | None = Field(default=None, gt=0)
    id_status: int = Field(gt=0)
    descricao: str
    latitude: Decimal = Field(ge=-90, le=90, max_digits=9, decimal_places=6)
    longitude: Decimal = Field(ge=-180, le=180, max_digits=9, decimal_places=6)
    prioridade: Literal["BAIXA", "MEDIA", "ALTA", "CRITICA"]

    @field_validator("descricao")
    @classmethod
    def validar_descricao(cls, valor: str) -> str:
        if not 10 <= len(valor.strip(" ")) <= 2000:
            raise ValueError("Descrição deve conter entre 10 e 2000 caracteres")
        return valor


class OcorrenciaResponse(BaseModel):
    id_ocorrencia: int
    protocolo: str
    id_usuario: int
    id_categoria: int | None
    id_status: int
    descricao: str
    latitude: Decimal
    longitude: Decimal
    prioridade: str
    criado_em: datetime
    atualizado_em: datetime
    categoria: str | None
