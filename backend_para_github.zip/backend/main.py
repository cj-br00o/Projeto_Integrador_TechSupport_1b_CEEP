from fastapi import Depends, FastAPI, HTTPException
from sqlalchemy.orm import Session

import models
import schemas
from database import SessionLocal

# O banco já existe no Supabase; a API não cria nem altera suas tabelas.

app = FastAPI(
    title="API do Radar Urbano",
    version="1.0.0"
)


def get_db():
    db = SessionLocal()

    try:
        yield db
    finally:
        db.close()


@app.get("/")
def inicio():
    return {"mensagem": "API funcionando"}


@app.post(
    "/categorias",
    response_model=schemas.CategoriaResponse
)
def criar_categoria(
    categoria: schemas.CategoriaCreate,
    db: Session = Depends(get_db)
):
    nova_categoria = models.Categoria(
        codigo=categoria.codigo,
        nome=categoria.nome,
        descricao=categoria.descricao,
        ativo=categoria.ativo
    )

    db.add(nova_categoria)
    db.commit()
    db.refresh(nova_categoria)

    return nova_categoria


@app.get(
    "/categorias",
    response_model=list[schemas.CategoriaResponse]
)
def listar_categorias(
    db: Session = Depends(get_db)
):
    return db.query(models.Categoria).all()


@app.post(
    "/ocorrencias",
    response_model=schemas.OcorrenciaResponse
)
def criar_ocorrencia(
    ocorrencia: schemas.OcorrenciaCreate,
    db: Session = Depends(get_db)
):
    categoria = None
    if ocorrencia.id_categoria is not None:
        categoria = (
            db.query(models.Categoria)
            .filter(models.Categoria.id_categoria == ocorrencia.id_categoria)
            .first()
        )

        if categoria is None:
            raise HTTPException(
                status_code=404,
                detail="Categoria não encontrada"
            )

    usuario = (
        db.query(models.Usuario)
        .filter(models.Usuario.id_usuario == ocorrencia.id_usuario)
        .first()
    )
    if usuario is None:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")

    status = (
        db.query(models.StatusOcorrencia)
        .filter(models.StatusOcorrencia.id_status == ocorrencia.id_status)
        .first()
    )
    if status is None:
        raise HTTPException(status_code=404, detail="Status não encontrado")

    nova_ocorrencia = models.Ocorrencia(
        protocolo=ocorrencia.protocolo,
        id_usuario=ocorrencia.id_usuario,
        id_categoria=ocorrencia.id_categoria,
        id_status=ocorrencia.id_status,
        descricao=ocorrencia.descricao,
        latitude=ocorrencia.latitude,
        longitude=ocorrencia.longitude,
        prioridade=ocorrencia.prioridade
    )

    db.add(nova_ocorrencia)
    db.commit()
    db.refresh(nova_ocorrencia)

    return {
        "id_ocorrencia": nova_ocorrencia.id_ocorrencia,
        "protocolo": nova_ocorrencia.protocolo,
        "id_usuario": nova_ocorrencia.id_usuario,
        "id_categoria": nova_ocorrencia.id_categoria,
        "id_status": nova_ocorrencia.id_status,
        "descricao": nova_ocorrencia.descricao,
        "latitude": nova_ocorrencia.latitude,
        "longitude": nova_ocorrencia.longitude,
        "prioridade": nova_ocorrencia.prioridade,
        "criado_em": nova_ocorrencia.criado_em,
        "atualizado_em": nova_ocorrencia.atualizado_em,
        "categoria": categoria.nome if categoria is not None else None
    }


@app.get(
    "/ocorrencias",
    response_model=list[schemas.OcorrenciaResponse]
)
def listar_ocorrencias(
    db: Session = Depends(get_db)
):
    ocorrencias = db.query(models.Ocorrencia).all()

    return [
        {
            "id_ocorrencia": ocorrencia.id_ocorrencia,
            "protocolo": ocorrencia.protocolo,
            "id_usuario": ocorrencia.id_usuario,
            "id_categoria": ocorrencia.id_categoria,
            "id_status": ocorrencia.id_status,
            "descricao": ocorrencia.descricao,
            "latitude": ocorrencia.latitude,
            "longitude": ocorrencia.longitude,
            "prioridade": ocorrencia.prioridade,
            "criado_em": ocorrencia.criado_em,
            "atualizado_em": ocorrencia.atualizado_em,
            "categoria": ocorrencia.categoria.nome if ocorrencia.categoria is not None else None
        }
        for ocorrencia in ocorrencias
    ]
